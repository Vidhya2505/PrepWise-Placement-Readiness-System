# PrepWise — AI Interview Coach

A full-stack AI-powered mock interview and resume analysis platform.

## Quick Start

### 1. Backend
```bash
cd prepwise-backend
npm install
cp .env.example .env
# Edit .env — fill in MONGO_URI and GROQ_API_KEY
npm run dev
```

### 2. Frontend
```bash
cd prepwise-frontend
npm install
npm run dev
```

### 3. Open
- Frontend: http://localhost:5173
- Backend:  http://localhost:5000

---

## Tech Stack

| Layer     | Technology |
|-----------|------------|
| Frontend  | React 18 + TypeScript + Vite + React Router |
| Backend   | Node.js + Express 5 |
| Database  | MongoDB Atlas (Mongoose) |
| AI        | Groq API — llama-3.3-70b-versatile |
| Auth      | JWT (7-day tokens) |
| PDF parse | pdfjs-dist |
| Rate limit| express-rate-limit |

---

## Environment Variables

```env
PORT=5000
NODE_ENV=development
MONGO_URI=mongodb+srv://<user>:<pass>@cluster0.xxx.mongodb.net/prepwiseDB
JWT_SECRET=your_secret_here
GROQ_API_KEY=gsk_your_key_here

# Production: comma-separated allowed frontend origins
ALLOWED_ORIGINS=https://yourapp.vercel.app
```

---

## Features

- **Resume Analysis** — Upload PDF/TXT → ATS match score, keyword gaps, section scores, risk analysis, before/after rewrites
- **ATS History Tracking** — Every analysis is saved to your profile; trend data ready for dashboard charting
- **Mock Interviews** — 5 AI-generated questions per round (HR, Technical, Behavioural, Project, DSA), tailored to your resume
- **Answer Coaching** — Per-answer scoring, filler word detection, STAR method check, recruiter view, improved answer
- **Interview Analytics** — Dashboard with streak tracking, readiness score, round-wise breakdown
- **Skill Gap Report** — Computed from your interview performance history
- **Portfolio Generator** — Upload resume → AI extracts name, bio, skills, projects, experience, education → editable preview → export single-file HTML portfolio
- **Dark / Light Theme** — System-aware with manual toggle

---

## New in v3

| Feature | Details |
|---------|---------|
| Portfolio Generator | New `/portfolio` page — upload resume, pick theme, AI generates full portfolio data |
| Portfolio HTML Export | `/portfolio/export-html` backend endpoint generates a complete self-contained HTML site |
| Edit Mode | All portfolio fields (name, bio, projects, etc.) are editable before export |
| Sidebar | Portfolio link added to AppLayout navigation |
| API service | `portfolioApi.generate` and `portfolioApi.exportHtml` added to `api.ts` |

---

## What's Fixed (v2)

| Issue | Fix |
|-------|-----|
| CORS too broad | `NODE_ENV` check + `ALLOWED_ORIGINS` env var for production |
| No rate limiting | `express-rate-limit`: 10 req/min on `/ai/*`, 20 req/15min on `/auth` |
| No error boundary | `ErrorBoundary` wraps entire React app in `main.tsx` |
| ATS scores not persisted | `atsHistory[]` array on User model, pushed on every `/ai/analyze` |
| Feedbacks stored as strings | `Interview.feedbacks` is now an array of structured sub-documents |
| Resume text unchecked | Trimmed to 6,000 chars with console warning |
| Fetch calls scattered | All API calls centralized in `src/services/api.ts` with 401 auto-redirect |
| Global error handler missing | Added to Express after all routes |

---

## Folder Structure

```
prepwise/
├── prepwise-backend/
│   ├── server.js               # Express app, CORS, rate limiters, error handler
│   ├── config/db.js            # MongoDB connection
│   ├── models/
│   │   ├── User.js             # + atsHistory[] array
│   │   └── Interview.js        # Structured feedbacks sub-schema
│   ├── controllers/
│   │   ├── authController.js   # register, login, getMe, updateProfile
│   │   └── interviewController.js  # save, getStats, getHistory
│   ├── routes/
│   │   ├── authRoutes.js
│   │   ├── aiRoutes.js         # /analyze, /generate-questions, /feedback-answer, /analyze-interview
│   │   └── interviewRoutes.js
│   └── middleware/authMiddleware.js
└── prepwise-frontend/
    └── src/
        ├── main.tsx            # ErrorBoundary + all Providers
        ├── App.tsx             # Route definitions
        ├── pages/
        │   ├── HomePage.tsx
        │   ├── LoginPage.tsx
        │   ├── SignupPage.tsx
        │   ├── Dashboard.tsx
        │   ├── MockInterview.tsx
        │   ├── ResumeAnalyzer.tsx
        │   ├── SkillGap.tsx
        │   └── Profile.tsx
        ├── components/
        │   ├── ErrorBoundary.tsx   # NEW — catches runtime errors app-wide
        │   ├── Navbar.tsx
        │   └── layout/AppLayout.tsx
        ├── context/
        │   ├── AuthContext.tsx
        │   ├── ResumeContext.tsx
        │   └── ThemeContext.tsx
        └── services/
            └── api.ts             # NEW — centralized fetch with 401 handling
```

---

## Known Remaining Gaps (future work)

- PDF report generation (currently exports `.txt`) — integrate `jspdf`
- Skill Gap page wired to live AI data (currently uses heuristic from interview history)
- Career role suggestions endpoint
- Resume file storage (GridFS / S3) — currently only text is extracted and stored
- Camera emotion analysis is simulated — integrate `face-api.js` for real detection

---

## New in v3 — Portfolio Generator + ChatBot

### Portfolio Generator (`/portfolio`)

A full AI-powered portfolio pipeline:

1. User uploads resume (PDF/txt) OR uses data already saved from Resume Analyzer
2. Optional: paste a job description to tailor the portfolio
3. AI generates: hero headline, about paragraph, skills by category, project rewrites with impact bullets, education, achievements, contact section, SEO meta
4. Live preview across 5 tabs (Hero / About / Skills / Projects / Contact)
5. Dark/Light theme toggle for the exported site
6. Export as a single self-contained `portfolio.html` file — no framework required
7. One-click deploy to Netlify Drop, GitHub Pages, or any static host

**Backend routes:**
- `POST /portfolio/generate` — generates full portfolio JSON from resume + profile
- `POST /portfolio/export-html` — renders the JSON into a production-ready HTML file

**Rate limited** by the existing `aiLimiter` (10 req/min).

---

### PrepBot — AI Chatbot Assistant

A floating chat widget available on all authenticated pages.

Features:
- Personalized to the user's profile (target role, skills, experience level, projects from DB)
- Conversation history maintained in-session (last 10 messages sent as context)
- Context-aware quick suggestions on first open (different prompts for freshers vs experienced)
- Handles: DSA questions, system design, behavioral prep, STAR method, resume tips, career guidance
- Filler word / STAR coaching built into the system prompt
- Unread badge on the FAB when a reply arrives while chat is closed
- Minimize/expand without losing history
- Clear chat button to start fresh

**Backend routes:**
- `POST /chat/message` — sends message + history, returns AI reply
- `GET /chat/suggestions` — returns 6 personalized quick-start prompts

**Rate limited** by `chatLimiter` (20 messages/min — higher than AI routes since chat is lower latency).

---

## Updated Folder Structure (v3)

```
prepwise/
├── prepwise-backend/
│   ├── routes/
│   │   ├── portfolioRoutes.js   # NEW — /portfolio/generate + /portfolio/export-html
│   │   └── chatRoutes.js        # NEW — /chat/message + /chat/suggestions
│   └── server.js                # Updated — registers portfolio + chat routes with limiters
└── prepwise-frontend/
    └── src/
        ├── App.tsx               # Updated — /portfolio route + ChatBot mounted globally
        ├── pages/
        │   └── Portfolio.tsx     # NEW — full portfolio generator UI
        └── components/
            └── ChatBot.tsx       # NEW — floating chatbot widget
```
