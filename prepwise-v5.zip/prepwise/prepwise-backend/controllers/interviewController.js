import Interview from "../models/Interview.js";

export const saveInterview = async (req, res) => {
  try {
    const { round, questions, answers, scores, avgScore, feedbacks } = req.body;
    if (!round || avgScore === undefined) return res.status(400).json({ error: "round and avgScore required" });

    const interview = await Interview.create({
      userId:    req.user.id,
      round,
      questions: questions || [],
      answers:   answers   || [],
      scores:    scores    || [],
      avgScore:  Math.round(avgScore),
      feedbacks: feedbacks || [],
    });

    res.status(201).json({ message: "Saved", interview });
  } catch (err) {
    console.error("saveInterview:", err.message);
    res.status(500).json({ error: "Server error" });
  }
};

export const getStats = async (req, res) => {
  try {
    const all = await Interview.find({ userId: req.user.id }).sort({ createdAt: -1 });

    const total      = all.length;
    const avgScore   = total ? Math.round(all.reduce((s, i) => s + i.avgScore, 0) / total) : 0;
    const now        = new Date();
    const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);
    const thisMonth  = all.filter(i => new Date(i.createdAt) >= monthStart).length;

    // Streak
    const uniqueDays = [...new Set(all.map(i => {
      const d = new Date(i.createdAt); d.setHours(0,0,0,0); return d.getTime();
    }))].sort((a, b) => b - a);

    let streak = 0;
    const today = new Date(); today.setHours(0,0,0,0);
    let expected = today.getTime();
    for (const d of uniqueDays) {
      if (d === expected || d === expected - 86400000) { streak++; expected = d - 86400000; }
      else break;
    }

    // Readiness: weighted formula
    const readiness = total === 0 ? 0
      : Math.min(100, Math.round(avgScore * 0.55 + Math.min(total, 15) * 2 + Math.min(streak, 10) * 1.5));

    // Recent 5
    const recent = all.slice(0, 5).map(i => ({
      round:     i.round,
      score:     i.avgScore,
      createdAt: i.createdAt,
      color:     i.avgScore >= 75 ? "var(--accent-green)" : i.avgScore >= 55 ? "#f59e0b" : "#ef4444",
    }));

    // Round-wise breakdown
    const byRound = {};
    all.forEach(i => {
      if (!byRound[i.round]) byRound[i.round] = { total: 0, sum: 0 };
      byRound[i.round].total++;
      byRound[i.round].sum += i.avgScore;
    });
    const roundStats = Object.entries(byRound).map(([round, d]) => ({
      round,
      count:    d.total,
      avgScore: Math.round(d.sum / d.total),
    }));

    res.json({ total, thisMonth, avgScore, streak, readiness, recent, roundStats });
  } catch (err) {
    console.error("getStats:", err.message);
    res.status(500).json({ error: "Server error" });
  }
};

export const getHistory = async (req, res) => {
  try {
    const interviews = await Interview.find({ userId: req.user.id }).sort({ createdAt: -1 }).limit(50);
    res.json(interviews);
  } catch (err) {
    res.status(500).json({ error: "Server error" });
  }
};
