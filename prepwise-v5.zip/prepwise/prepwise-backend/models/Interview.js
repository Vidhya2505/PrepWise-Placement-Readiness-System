import mongoose from "mongoose";

const feedbackSchema = new mongoose.Schema({
  score:           { type: Number },
  label:           { type: String },
  strengths:       [{ type: String }],
  improvements:    [{ type: String }],
  improvedAnswer:  { type: String, default: "" },
  insight:         { type: String, default: "" },
  weakestMetric:   { type: String, default: "" },
  hireDecision:    { type: String, default: "" },
}, { _id: false });

const interviewSchema = new mongoose.Schema({
  userId:    { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
  round:     { type: String, required: true },
  questions: [{ type: String }],
  answers:   [{ type: String }],
  scores:    [{ type: Number }],
  avgScore:  { type: Number, required: true },
  // Structured feedbacks instead of plain strings
  feedbacks: [feedbackSchema],
}, { timestamps: true });

export default mongoose.model("Interview", interviewSchema);
