import mongoose from "mongoose";

const userSchema = new mongoose.Schema({
  name:           { type: String, required: true, trim: true },
  email:          { type: String, required: true, unique: true, lowercase: true },
  password:       { type: String, required: true },
  targetRole:     { type: String, default: "" },
  experience:     { type: String, default: "" },
  companyType:    { type: String, default: "" },
  college:        { type: String, default: "" },
  graduationYear: { type: String, default: "" },
  skills:         [{ type: String }],
  resumeData: {
    skills:          [{ type: String }],
    projects:        [{ name: String, tech: [String], description: String }],
    experienceLevel: { type: String, default: "fresher" },
    education:       { type: String, default: "" },
  },
  // ATS score history — pushed on every resume analysis
  atsHistory: [{
    score:     { type: Number, required: true },
    jobRole:   { type: String, default: "" },
    createdAt: { type: Date, default: Date.now },
  }],
}, { timestamps: true });

export default mongoose.model("User", userSchema);
