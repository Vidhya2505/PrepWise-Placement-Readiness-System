import express from "express";
import Groq from "groq-sdk";
import authMiddleware from "../middleware/authMiddleware.js";
import multer from "multer";
import User from "../models/User.js";

const router = express.Router();
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 5 * 1024 * 1024 } });

// ── Groq helper ──────────────────────────────────────────────────────────────
async function groqJSON(system, user, maxTokens = 2000) {
  const groq = new Groq({ apiKey: process.env.GROQ_API_KEY });
  const res = await groq.chat.completions.create({
    model: "llama-3.3-70b-versatile",
    max_tokens: maxTokens,
    messages: [{ role: "system", content: system }, { role: "user", content: user }],
  });
  const raw = res.choices[0]?.message?.content || "{}";
  const clean = raw.replace(/```json|```/g, "").trim();
  try { return JSON.parse(clean); }
  catch { return { raw }; }
}

// ── POST /ai/analyze  (Resume Analyzer page) ─────────────────────────────────
router.post("/analyze", authMiddleware, async (req, res) => {
  try {
    const { resumeText, jobDescription } = req.body;
    if (!resumeText || !jobDescription) return res.status(400).json({ error: "resumeText and jobDescription required" });

    // Guard: trim to ~6000 chars to stay well within token budget
    const RESUME_MAX = 6000;
    const JD_MAX = 2500;
    if (resumeText.length > RESUME_MAX) {
      console.warn(`/ai/analyze: resume truncated from ${resumeText.length} to ${RESUME_MAX} chars`);
    }
    const safeResume = resumeText.slice(0, RESUME_MAX);
    const safeJD     = jobDescription.slice(0, JD_MAX);

    const system = `You are a senior AI career coach and ATS expert.
Analyze the resume against the job description deeply.
Return ONLY valid JSON — no markdown, no text outside the JSON.`;

    const prompt = `RESUME:\n${safeResume}\n\nJOB DESCRIPTION:\n${safeJD}\n\nReturn JSON:
{
  "matchScore": 72,
  "alignmentScore": 65,
  "matchedSkills": ["React","Node.js"],
  "missingSkills": ["Python","SQL"],
  "summary": "2-3 sentence summary.",
  "scoreBreakdown": {
    "skillsMatch":        { "score": 65, "reason": "Has React and Node.js but missing cloud skills." },
    "experienceStrength": { "score": 58, "reason": "Projects show work but no metrics." },
    "keywordCoverage":    { "score": 70, "reason": "Most keywords present but REST API appears once." }
  },
  "keywordOptimization": [
    { "skill": "REST APIs", "placement": "Projects", "howToWrite": "Built REST APIs using Node.js for PrepWise backend" }
  ],
  "resumeRewrites": [
    { "section": "Projects", "original": "Worked on a chat app", "improved": "Developed real-time chat app supporting 100+ users using WebSocket and Node.js" }
  ],
  "impactAnalysis": {
    "hasMetrics": false,
    "metricsFound": [],
    "missingSections": ["Projects","Experience"],
    "suggestion": "Add at least 3 measurable results — numbers improve ATS rank significantly."
  },
  "roleOptimization": {
    "detectedRole": "Full Stack Developer",
    "tailoredTips": [
      "Emphasize React performance optimization for frontend credibility",
      "Add deployment experience (Docker, cloud) as mentioned in JD"
    ]
  },
  "interviewLinkage": {
    "likelyTopics": ["project architecture","REST API design","database choice"],
    "projectsToHighlight": ["your main project","CI/CD setup"],
    "skillsToEmphasise": ["React","Node.js"],
    "tip": "Be ready to explain why you chose your database technology — common follow-up."
  },
  "riskAnalysis": [
    { "level": "high",   "risk": "Missing cloud experience — commonly required for this role" },
    { "level": "high",   "risk": "No quantified achievements — ATS ranks without metrics lower" },
    { "level": "medium", "risk": "Experience section too generic — needs specific contributions" }
  ],
  "benchmarkComparison": {
    "skills":     { "rating": "average",       "note": "Core stack covered but missing cloud/DevOps" },
    "projects":   { "rating": "strong",        "note": "Good variety — above average for fresher" },
    "experience": { "rating": "below average", "note": "Lacks measurable impact statements" },
    "overall":    { "rating": "average",       "note": "Competitive for junior but needs polish for mid-level" }
  },
  "priorityActionPlan": [
    { "priority": "high",   "action": "Add missing keywords: REST APIs, CI/CD, cloud to skills" },
    { "priority": "high",   "action": "Add metrics to at least 3 bullets — boosts ATS score 15-20 pts" },
    { "priority": "medium", "action": "Rewrite project bullets using improved versions above" },
    { "priority": "low",    "action": "Add relevant coursework to education section" }
  ],
  "keywordDensity": [
    { "keyword": "REST API", "count": 1, "recommended": 3, "status": "low" },
    { "keyword": "React",    "count": 3, "recommended": 3, "status": "good" }
  ],
  "contextAwareSuggestions": {
    "experienceLevel": "fresher",
    "suggestions": [
      "As a fresher, prioritize projects over experience — make each project tell a strong technical story",
      "Add GitHub links to all projects — recruiters validate skill claims by clicking them"
    ]
  },
  "sections": {
    "skills":     { "score": 70, "status": "moderate", "feedback": "Covers core stack but missing cloud.",   "suggestions": ["Add cloud platform","List testing frameworks"] },
    "projects":   { "score": 80, "status": "strong",   "feedback": "Good variety with real-world relevance.", "suggestions": ["Add metrics","Add live demo links"] },
    "experience": { "score": 55, "status": "moderate", "feedback": "Needs stronger action verbs.",           "suggestions": ["Start with strong verbs","Add numbers"] },
    "education":  { "score": 85, "status": "strong",   "feedback": "Education aligns well.",                 "suggestions": ["Add relevant coursework"] }
  },
  "suggestions": ["Add 3 missing keywords from JD","Quantify at least 3 achievements","Reorder skills to match JD priority"],
  "resumeData": {
    "skills": ["React","Node.js","MongoDB"],
    "projects": [{ "name": "PrepWise", "tech": ["React","Node.js"], "description": "AI placement platform" }],
    "experienceLevel": "fresher",
    "education": "B.Tech CSE, University Name"
  }
}`;

    const result = await groqJSON(system, prompt, 3000);

    // Persist resumeData + ATS score history to user profile
    if (req.user?.id) {
      const update = {};
      if (result.resumeData) update.resumeData = result.resumeData;
      const atsScore = typeof result.matchScore === "number" ? result.matchScore : 50;
      await User.findByIdAndUpdate(req.user.id, {
        ...update,
        $push: { atsHistory: { $each: [{ score: atsScore, jobRole: result.roleOptimization?.detectedRole || "" }], $slice: -50 } },
      }).catch(() => {});
    }

    const safe = {
      matchScore:     typeof result.matchScore === "number"     ? result.matchScore     : 50,
      alignmentScore: typeof result.alignmentScore === "number" ? result.alignmentScore : 45,
      matchedSkills:  Array.isArray(result.matchedSkills)       ? result.matchedSkills  : [],
      missingSkills:  Array.isArray(result.missingSkills)       ? result.missingSkills  : [],
      summary:        result.summary || "Analysis complete.",
      suggestions:    Array.isArray(result.suggestions)         ? result.suggestions    : [],
      scoreBreakdown: result.scoreBreakdown || {
        skillsMatch:        { score: 50, reason: "Could not analyse." },
        experienceStrength: { score: 50, reason: "Could not analyse." },
        keywordCoverage:    { score: 50, reason: "Could not analyse." },
      },
      keywordOptimization:    Array.isArray(result.keywordOptimization)    ? result.keywordOptimization    : [],
      resumeRewrites:         Array.isArray(result.resumeRewrites)         ? result.resumeRewrites         : [],
      impactAnalysis:         result.impactAnalysis         || { hasMetrics: false, metricsFound: [], missingSections: [], suggestion: "Add measurable results." },
      roleOptimization:       result.roleOptimization       || { detectedRole: "Software Developer", tailoredTips: [] },
      interviewLinkage:       result.interviewLinkage       || { likelyTopics: [], projectsToHighlight: [], skillsToEmphasise: [], tip: "" },
      riskAnalysis:           Array.isArray(result.riskAnalysis)           ? result.riskAnalysis           : [],
      benchmarkComparison:    result.benchmarkComparison    || {},
      priorityActionPlan:     Array.isArray(result.priorityActionPlan)     ? result.priorityActionPlan     : [],
      keywordDensity:         Array.isArray(result.keywordDensity)         ? result.keywordDensity         : [],
      contextAwareSuggestions: result.contextAwareSuggestions || { experienceLevel: "fresher", suggestions: [] },
      sections: {
        skills:     result.sections?.skills     || { score: 50, status: "moderate", feedback: "", suggestions: [] },
        projects:   result.sections?.projects   || { score: 50, status: "moderate", feedback: "", suggestions: [] },
        experience: result.sections?.experience || { score: 50, status: "moderate", feedback: "", suggestions: [] },
        education:  result.sections?.education  || { score: 75, status: "strong",   feedback: "", suggestions: [] },
      },
      resumeData: result.resumeData || { skills: [], projects: [], experienceLevel: "fresher", education: "" },
    };

    res.json(safe);
  } catch (err) {
    console.error("/ai/analyze:", err.message);
    res.status(500).json({ error: "Analysis failed", detail: err.message });
  }
});

// ── POST /ai/generate-questions ──────────────────────────────────────────────
router.post("/generate-questions", authMiddleware, async (req, res) => {
  try {
    const { interviewType, resumeData } = req.body;
    if (!interviewType) return res.status(400).json({ error: "interviewType required" });

    const context = resumeData
      ? `Candidate: ${resumeData.experienceLevel || "fresher"} level.
Skills: ${(resumeData.skills || []).join(", ") || "not provided"}.
Projects: ${(resumeData.projects || []).map(p => p.name).join(", ") || "not provided"}.
Education: ${resumeData.education || "not provided"}.`
      : "No resume provided — generate strong general questions.";

    const rules = {
      HR:          "Generate 5 behavioral/HR questions about motivation, goals, teamwork, strengths, and why this company.",
      Technical:   "Generate 5 technical questions covering DSA, OS, DBMS, Computer Networks, and system design fundamentals.",
      Behavioural: "Generate 5 STAR-format behavioural questions about leadership, initiative, conflict, failure, and learning.",
      Project:     "Generate 5 deep questions probing the candidate's listed projects — architecture decisions, challenges, scale, tech choices.",
      DSA:         "Generate 5 DSA-focused questions on arrays, graphs, dynamic programming, trees, and time/space complexity.",
    };

    const system = `You are a senior interviewer at a top product company.
Generate exactly 5 interview questions tailored to the candidate profile.
Return ONLY a valid JSON array of 5 strings — no markdown, no numbering, no explanation.
Example: ["Question 1?","Question 2?","Question 3?","Question 4?","Question 5?"]`;

    const result = await groqJSON(system, `${rules[interviewType] || rules.HR}\n\n${context}`, 600);

    let questions = Array.isArray(result) ? result
      : Array.isArray(result.questions) ? result.questions
      : result.raw ? (() => { const m = result.raw.match(/\[[\s\S]*\]/); return m ? JSON.parse(m[0]) : []; })()
      : [];

    if (!questions.length) questions = getFallback(interviewType);

    res.json({ questions: questions.slice(0, 5) });
  } catch (err) {
    console.error("/ai/generate-questions:", err.message);
    res.json({ questions: getFallback(req.body.interviewType) });
  }
});

// ── POST /ai/feedback-answer ─────────────────────────────────────────────────
router.post("/feedback-answer", authMiddleware, async (req, res) => {
  try {
    const { question, answer, round, resumeData } = req.body;
    if (!question || !answer) return res.status(400).json({ error: "question and answer required" });

    const wordCount = answer.trim().split(/\s+/).filter(Boolean).length;
    const estSec    = Math.round((wordCount / 130) * 60);

    const system = `You are a strict, honest AI interview coach at a top product company.
Analyse the candidate's answer and ALWAYS provide a helpful model answer for "improvedAnswer".
RULES FOR improvedAnswer:
- If the answer is too short (under 10 words): write a complete model answer for that question showing what a good answer looks like
- If the answer has content: rewrite it with better structure, clarity, and confidence — keep their ideas but improve phrasing
- NEVER return "None", "", or null for improvedAnswer — always give something useful
- The model answer should be 3-6 sentences, structured and specific
Return ONLY valid JSON — no markdown.`;

    const prompt = `ROUND: ${round}
QUESTION: ${question}
ANSWER: ${answer}
WORDS: ${wordCount}
${resumeData ? `CANDIDATE: ${resumeData.experienceLevel || "fresher"}, skills: ${(resumeData.skills || []).slice(0, 5).join(", ")}` : ""}

Return JSON:
{
  "score": 65,
  "interpretation": "Above average — shows understanding but lacks depth",
  "scoreBreakdown": { "content": 26, "clarity": 13, "structure": 13, "confidence": 13 },
  "breakdown": { "depth": 65, "clarity": 65, "structure": 65, "confidence": 65 },
  "weakestMetric": "confidence",
  "weakestVal": 55,
  "whyThisScore": ["Answer is too brief","No specific example provided"],
  "topFixes": ["Add a concrete example","Include a measurable result","Use assertive language"],
  "strengths": ["Clear explanation","Good use of own words"],
  "improvements": ["Add real-world example","Quantify the impact"],
  "improvedAnswer": "Rewrite using ONLY candidate content — same story, better structure. Never invent.",
  "suggestedStructure": ["1. Define concept","2. Your example","3. Why it matters"],
  "insight": "One specific coaching tip for this exact answer.",
  "nextSteps": ["Practice STAR method","Prepare 2 examples with metrics"],
  "recruiterView": { "communication": "Average", "problemSolving": "Average", "technicalDepth": "Basic", "hireDecision": "Maybe", "hireReason": "Shows awareness but needs more depth" },
  "confidenceContentGap": { "hasGap": false, "insight": "" },
  "realInterviewRisk": { "level": "medium", "verdict": "Borderline", "reason": "Would probe further in real interview" },
  "questionDifficulty": { "level": "Medium", "expectedDuration": "60-90 seconds", "expectedDepth": "Definition + real example" },
  "deliveryAnalysis": { "estimatedSeconds": ${estSec}, "idealSeconds": "60-90", "verdict": "${estSec < 30 ? "Too short" : estSec <= 90 ? "Good" : "Too long"}", "wordsPerMinute": ${Math.round((wordCount / Math.max(estSec, 1)) * 60)} },
  "weakAreaPractice": { "area": "confidence", "tip": "Replace vague phrases with ownership language.", "practicePrompt": "Describe a specific decision you made in 3 sentences." }
}

RULES:
- score = content(40%) + clarity(20%) + structure(20%) + confidence(20%).
- 1-5 word answer (like "hi", "yes", "idk") = score 10-20. Structured 80-word answer with example = 65-80.
- hireDecision: "Strong Yes"|"Yes"|"Maybe"|"No". risk level: "low"|"medium"|"high".
- improvedAnswer is MANDATORY. Never return "None". If answer is too brief, write a complete model answer.
- For a 1-word answer like "hi": improvedAnswer = full model answer for the question showing ideal response.
- recruiterView communication/problemSolving/technicalDepth values: "Excellent"|"Strong"|"Average"|"Poor"|"None".`;

    const result = await groqJSON(system, prompt, 1500);

    const score = typeof result.score === "number" ? Math.max(10, Math.min(97, result.score)) : 50;
    const label = score >= 85 ? "Excellent" : score >= 70 ? "Strong" : score >= 55 ? "Good" : score >= 40 ? "Needs Work" : "Too Brief";
    const color = score >= 85 ? "var(--accent-green)" : score >= 70 ? "var(--accent-blue)" : score >= 55 ? "var(--accent-cyan)" : score >= 40 ? "#f59e0b" : "#ef4444";

    res.json({
      feedback: {
        score, label, color,
        interpretation:       result.interpretation       || (score >= 70 ? "Good candidate" : "Needs improvement"),
        scoreBreakdown:       result.scoreBreakdown       || { content: Math.round(score * 0.4), clarity: Math.round(score * 0.2), structure: Math.round(score * 0.2), confidence: Math.round(score * 0.2) },
        breakdown:            result.breakdown            || { depth: score, clarity: score, structure: score, confidence: score },
        weakestMetric:        result.weakestMetric        || "depth",
        weakestVal:           result.weakestVal           || score,
        whyThisScore:         Array.isArray(result.whyThisScore)       ? result.whyThisScore       : [],
        topFixes:             Array.isArray(result.topFixes)           ? result.topFixes           : [],
        strengths:            Array.isArray(result.strengths)          ? result.strengths          : ["Keep practising."],
        improvements:         Array.isArray(result.improvements)       ? result.improvements       : [],
        improvedAnswer: (() => {
          const ia = result.improvedAnswer || "";
          // Never show literal "None", "null", "N/A" etc — replace with empty so frontend shows nothing
          if (!ia || ia.trim().toLowerCase() === "none" || ia.trim().toLowerCase() === "n/a" || ia.trim() === "null" || ia.length < 5) return "";
          return ia;
        })(),
        suggestedStructure:   Array.isArray(result.suggestedStructure) ? result.suggestedStructure : [],
        insight:              result.insight              || "",
        nextSteps:            Array.isArray(result.nextSteps)          ? result.nextSteps          : [],
        recruiterView:        result.recruiterView        || { communication: "Average", problemSolving: "Average", technicalDepth: "Average", hireDecision: score >= 70 ? "Maybe" : "No", hireReason: "Needs more depth." },
        confidenceContentGap: result.confidenceContentGap || { hasGap: false, insight: "" },
        realInterviewRisk:    result.realInterviewRisk    || { level: score >= 70 ? "low" : "medium", verdict: score >= 70 ? "Good chance" : "Borderline", reason: "Based on answer quality." },
        questionDifficulty:   result.questionDifficulty   || { level: "Medium", expectedDuration: "60-90 seconds", expectedDepth: "Definition + example" },
        deliveryAnalysis:     result.deliveryAnalysis     || { estimatedSeconds: estSec, idealSeconds: "60-90", verdict: estSec < 30 ? "Too short" : "Good", wordsPerMinute: Math.round((wordCount / Math.max(estSec, 1)) * 60) },
        weakAreaPractice:     result.weakAreaPractice     || { area: "depth", tip: "", practicePrompt: "" },
      }
    });
  } catch (err) {
    console.error("/ai/feedback-answer:", err.message);
    res.status(500).json({ error: "Failed to analyse answer", detail: err.message });
  }
});

// ── POST /ai/analyze-interview ───────────────────────────────────────────────
router.post("/analyze-interview", authMiddleware, async (req, res) => {
  try {
    const { answers, resumeData } = req.body;
    if (!answers?.length) return res.status(400).json({ error: "answers array required" });

    const answersText = answers.map((a, i) => `Q${i + 1}: ${a.question}\nA${i + 1}: ${a.answer || "(no answer)"}`).join("\n\n");

    const prompt = `Candidate: ${resumeData?.experienceLevel || "fresher"}, skills: ${(resumeData?.skills || []).join(", ") || "N/A"}

${answersText}

Analyse all answers and return JSON:
{
  "overallScore": 72,
  "breakdown": { "contentQuality": 28, "clarity": 15, "structure": 15, "confidence": 14 },
  "strengths": ["strength 1","strength 2","strength 3"],
  "weaknesses": ["weakness 1","weakness 2"],
  "improvements": ["tip 1","tip 2","tip 3"],
  "improvedAnswers": [{ "question": "Q text", "original": "their answer", "improved": "model answer using only their content" }],
  "resumeAlignment": {
    "skillsMentioned": ["skill1"],
    "skillsMissed": ["skill2"],
    "projectsMentioned": [],
    "alignmentScore": 65,
    "suggestions": ["Mention your React experience","Add specific metrics"]
  }
}`;

    const result = await groqJSON("You are a professional AI interview coach. Return only valid JSON.", prompt, 2000);

    res.json({
      analysis: {
        overallScore:    result.overallScore    || 50,
        breakdown:       result.breakdown       || { contentQuality: 20, clarity: 10, structure: 10, confidence: 10 },
        strengths:       Array.isArray(result.strengths)    ? result.strengths    : ["Attempted all questions"],
        weaknesses:      Array.isArray(result.weaknesses)   ? result.weaknesses   : ["Needs more examples"],
        improvements:    Array.isArray(result.improvements) ? result.improvements : ["Practice STAR method"],
        improvedAnswers: Array.isArray(result.improvedAnswers) ? result.improvedAnswers : [],
        resumeAlignment: result.resumeAlignment || {
          skillsMentioned: [], skillsMissed: (resumeData?.skills || []).slice(0, 3),
          projectsMentioned: [], alignmentScore: 40,
          suggestions: ["Mention key skills explicitly in answers"],
        },
      }
    });
  } catch (err) {
    console.error("/ai/analyze-interview:", err.message);
    res.status(500).json({ error: "Failed to analyse interview", detail: err.message });
  }
});

// ── Fallback questions ───────────────────────────────────────────────────────
function getFallback(type) {
  const bank = {
    HR:          ["Tell me about yourself and what makes you a strong candidate.", "Where do you see yourself in 5 years?", "Why do you want to work at a product company?", "Describe a time you handled conflict in a team.", "What are your greatest strengths and one weakness?"],
    Technical:   ["Explain the difference between a process and a thread.", "What are ACID properties in databases?", "Explain BFS vs DFS with use cases.", "What is a REST API and how does it differ from GraphQL?", "Explain memory management in operating systems."],
    Behavioural: ["Describe a time you took initiative without being asked.", "Tell me about a project where you learned under pressure.", "Give an example of when you disagreed with a teammate.", "Describe your biggest professional failure and what you learned.", "How do you prioritize when multiple tasks are urgent?"],
    Project:     ["Walk me through your main project's architecture.", "What was the hardest technical decision you made in this project?", "How would your project handle 10x more users?", "What would you build differently if you started over?", "How did you validate your project solves a real problem?"],
    DSA:         ["Explain dynamic programming and when to use it.", "What is the two-pointer technique? Give an example.", "How does quicksort work and what is its average complexity?", "Explain graph cycle detection using DFS.", "What is the difference between BFS and Dijkstra's algorithm?"],
  };
  return bank[type] || bank.HR;
}

export default router;
