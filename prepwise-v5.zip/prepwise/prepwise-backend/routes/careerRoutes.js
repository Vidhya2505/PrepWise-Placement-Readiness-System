import express from "express";
import Groq from "groq-sdk";
import authMiddleware from "../middleware/authMiddleware.js";
import User from "../models/User.js";
import Interview from "../models/Interview.js";

const router = express.Router();

async function groqJSON(system, user, maxTokens = 3000) {
  const groq = new Groq({ apiKey: process.env.GROQ_API_KEY });
  const res = await groq.chat.completions.create({
    model: "llama-3.3-70b-versatile",
    max_tokens: maxTokens,
    messages: [{ role: "system", content: system }, { role: "user", content: user }],
  });
  const raw = res.choices[0]?.message?.content || "{}";
  const clean = raw.replace(/```json|```/g, "").trim();
  try { return JSON.parse(clean); } catch { return { raw }; }
}

// POST /career/report — generate full career intelligence report
router.post("/report", authMiddleware, async (req, res) => {
  try {
    const { resumeData, stats, targetRole, experience, skills } = req.body;

    // Pull richer context from DB
    const dbUser = await User.findById(req.user.id).select("-password").lean().catch(() => null);
    const interviews = await Interview.find({ userId: req.user.id }).sort({ createdAt: -1 }).limit(20).lean().catch(() => []);

    const avgInterviewScore = interviews.length
      ? Math.round(interviews.reduce((a, b) => a + (b.avgScore || 0), 0) / interviews.length) : 0;

    const roundBreakdown = {};
    interviews.forEach(i => {
      if (!roundBreakdown[i.round]) roundBreakdown[i.round] = { sum: 0, count: 0 };
      roundBreakdown[i.round].sum += i.avgScore || 0;
      roundBreakdown[i.round].count++;
    });
    const roundSummary = Object.entries(roundBreakdown)
      .map(([r, d]) => `${r}: ${Math.round(d.sum / d.count)}/100 (${d.count} sessions)`)
      .join(", ");

    const name = dbUser?.name || "Candidate";
    const role = dbUser?.targetRole || targetRole || "Software Developer";
    const expLevel = dbUser?.resumeData?.experienceLevel || experience || "fresher";
    const allSkills = [...new Set([
      ...(dbUser?.resumeData?.skills || []),
      ...(dbUser?.skills || []),
      ...(skills || []),
    ])].slice(0, 15).join(", ") || "not specified";
    const projects = (dbUser?.resumeData?.projects || []).map(p => `${p.name} (${(p.tech||[]).join(",")})`).join("; ") || "not listed";
    const education = dbUser?.resumeData?.education || "not specified";

    const system = `You are a senior career strategist and AI career coach.
Generate a comprehensive, personalized career intelligence report.
Base ALL recommendations on the actual candidate data provided.
Return ONLY valid JSON — no markdown, no text outside JSON.`;

    const prompt = `CANDIDATE PROFILE:
Name: ${name}
Target Role: ${role}
Experience Level: ${expLevel}
Skills: ${allSkills}
Projects: ${projects}
Education: ${education}
Interview Sessions: ${interviews.length}
Avg Interview Score: ${avgInterviewScore}/100
Round Performance: ${roundSummary || "no sessions yet"}

Generate a complete career intelligence report as JSON:
{
  "overallScore": <weighted score 0-100 based on all data>,
  "atsScore": <estimated 0-100 based on skills/projects>,
  "interviewAvg": ${avgInterviewScore || 50},
  "readiness": <0-100 placement readiness>,
  "strengths": ["specific strength 1", "specific strength 2", "specific strength 3", "specific strength 4"],
  "weaknesses": ["specific gap 1", "specific gap 2", "specific gap 3", "specific gap 4"],
  "actionPlan": [
    { "priority": "high", "action": "specific action based on their profile", "timeframe": "This week" },
    { "priority": "high", "action": "second high priority action", "timeframe": "2 weeks" },
    { "priority": "medium", "action": "medium action", "timeframe": "1 month" },
    { "priority": "medium", "action": "second medium action", "timeframe": "1 month" },
    { "priority": "low", "action": "low priority action", "timeframe": "2-3 months" }
  ],
  "careerRoles": [
    { "role": "Best matching role", "match": 85, "reason": "specific reason based on their skills", "salaryRange": "₹X–Y LPA" },
    { "role": "Second role", "match": 75, "reason": "reason", "salaryRange": "₹X–Y LPA" },
    { "role": "Third role", "match": 65, "reason": "reason", "salaryRange": "₹X–Y LPA" },
    { "role": "Stretch role", "match": 55, "reason": "reason", "salaryRange": "₹X–Y LPA" }
  ],
  "learningRoadmap": [
    { "phase": 1, "title": "Foundation (based on their weakest areas)", "duration": "3 weeks", "topics": ["topic1", "topic2", "topic3"], "resources": ["resource1", "resource2", "resource3"] },
    { "phase": 2, "title": "Intermediate skills", "duration": "2 weeks", "topics": ["topic1", "topic2"], "resources": ["resource1", "resource2"] },
    { "phase": 3, "title": "Advanced / Interview prep", "duration": "2 weeks", "topics": ["topic1", "topic2"], "resources": ["resource1", "resource2"] }
  ],
  "certifications": [
    { "name": "Most relevant cert for their role", "provider": "provider", "priority": "high", "relevance": "why relevant" },
    { "name": "Second cert", "provider": "provider", "priority": "medium", "relevance": "why" },
    { "name": "Third cert", "provider": "provider", "priority": "medium", "relevance": "why" }
  ],
  "projectIdeas": [
    { "title": "Project idea matching their stack", "tech": ["tech1","tech2","tech3"], "impact": "what this demonstrates and why it helps", "complexity": "intermediate" },
    { "title": "Beginner project", "tech": ["tech1","tech2"], "impact": "impact description", "complexity": "beginner" },
    { "title": "Advanced project", "tech": ["tech1","tech2","tech3"], "impact": "impact", "complexity": "advanced" },
    { "title": "Fourth project idea", "tech": ["tech1","tech2"], "impact": "impact", "complexity": "beginner" }
  ],
  "portfolioContent": [
    { "section": "Hero / About", "content": "A compelling 2-3 sentence about paragraph for ${name} targeting ${role}" },
    { "section": "Skills Summary", "content": "Formatted skills list based on their actual skills: ${allSkills}" },
    { "section": "Project Highlight", "content": "A polished project description based on their best project" },
    { "section": "GitHub README", "content": "A complete GitHub profile README template for them" }
  ],
  "weeklyPlan": [
    { "day": "Monday", "tasks": ["task1 based on their gaps", "task2", "task3"] },
    { "day": "Tuesday", "tasks": ["task1", "task2", "task3"] },
    { "day": "Wednesday", "tasks": ["task1", "task2", "task3"] },
    { "day": "Thursday", "tasks": ["task1", "task2", "task3"] },
    { "day": "Friday", "tasks": ["task1", "task2", "task3"] },
    { "day": "Saturday", "tasks": ["task1", "task2", "task3"] },
    { "day": "Sunday", "tasks": ["task1", "task2"] }
  ],
  "nextSteps": ["step1 specific to their situation", "step2", "step3", "step4", "step5"]
}

RULES:
- All content MUST be specific to this candidate — no generic responses
- Salary ranges should be realistic for Indian market and their experience level
- Project ideas should use their actual tech stack
- Weekly plan should target their weakest round performance
- certifications must be relevant to their target role: ${role}`;

    const result = await groqJSON(system, prompt, 3500);

    const safe = {
      overallScore:      typeof result.overallScore === "number"  ? Math.max(1, Math.min(100, result.overallScore)) : 60,
      atsScore:          typeof result.atsScore === "number"       ? Math.max(1, Math.min(100, result.atsScore))      : 65,
      interviewAvg:      typeof result.interviewAvg === "number"  ? result.interviewAvg                               : avgInterviewScore || 50,
      readiness:         typeof result.readiness === "number"     ? Math.max(1, Math.min(100, result.readiness))      : 55,
      strengths:         Array.isArray(result.strengths)          ? result.strengths.slice(0, 6)   : ["Profile shows relevant skills"],
      weaknesses:        Array.isArray(result.weaknesses)         ? result.weaknesses.slice(0, 6)  : ["Complete more interviews for detailed analysis"],
      actionPlan:        Array.isArray(result.actionPlan)         ? result.actionPlan              : [],
      careerRoles:       Array.isArray(result.careerRoles)        ? result.careerRoles             : [],
      learningRoadmap:   Array.isArray(result.learningRoadmap)    ? result.learningRoadmap         : [],
      certifications:    Array.isArray(result.certifications)     ? result.certifications          : [],
      projectIdeas:      Array.isArray(result.projectIdeas)       ? result.projectIdeas            : [],
      portfolioContent:  Array.isArray(result.portfolioContent)   ? result.portfolioContent        : [],
      weeklyPlan:        Array.isArray(result.weeklyPlan)         ? result.weeklyPlan              : [],
      nextSteps:         Array.isArray(result.nextSteps)          ? result.nextSteps               : [],
      generatedAt:       new Date().toISOString(),
      candidateName:     name,
      targetRole:        role,
    };

    res.json(safe);
  } catch (err) {
    console.error("/career/report:", err.message);
    res.status(500).json({ error: "Career report generation failed", detail: err.message });
  }
});

export default router;
