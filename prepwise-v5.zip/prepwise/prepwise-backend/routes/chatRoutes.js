import express from "express";
import Groq from "groq-sdk";
import authMiddleware from "../middleware/authMiddleware.js";
import User from "../models/User.js";

const router = express.Router();

// POST /chat/message — streaming-compatible chat endpoint
router.post("/message", authMiddleware, async (req, res) => {
  try {
    const { message, history = [] } = req.body;
    if (!message?.trim()) return res.status(400).json({ error: "message required" });

    // Pull user context for personalization
    const dbUser = await User.findById(req.user.id).select("-password").lean().catch(() => null);
    const skills = (dbUser?.resumeData?.skills || dbUser?.skills || []).slice(0, 10).join(", ");
    const role   = dbUser?.targetRole || "Software Developer";
    const level  = dbUser?.resumeData?.experienceLevel || "fresher";
    const projects = (dbUser?.resumeData?.projects || []).slice(0, 3).map(p => p.name).join(", ");

    const system = `You are PrepBot, an expert AI career coach inside the PrepWise placement platform.
You help students and developers prepare for tech placements and job interviews.

USER PROFILE:
- Name: ${dbUser?.name || "User"}
- Target Role: ${role}
- Experience Level: ${level}
- Key Skills: ${skills || "not yet set — suggest they run Resume Analyzer"}
- Projects: ${projects || "not yet extracted — suggest they upload resume"}

YOUR EXPERTISE:
- DSA problems, patterns, complexity analysis
- System design (for relevant experience levels)
- Core CS: OS, DBMS, Computer Networks
- Resume feedback and ATS optimization
- Behavioral questions and STAR method
- Mock interview tips and salary negotiation
- Career advice specific to Indian tech placements (FAANG, product companies, service companies, startups)

RESPONSE RULES:
- Be concise but complete. No fluff.
- Use bullet points or numbered lists for structured content.
- For DSA, always include time and space complexity.
- For behavioral questions, always use STAR format as example.
- Personalize to the user's profile when relevant.
- If a question is outside career/tech scope, gently redirect.
- Keep responses under 400 words unless the user asks for a deep dive.
- Use friendly, coaching tone — not robotic.
- If asked about PrepWise features: Resume Analyzer (upload PDF), Mock Interview (5 rounds), Skill Gap, Dashboard, Portfolio Generator.`;

    const groq = new Groq({ apiKey: process.env.GROQ_API_KEY });

    // Build conversation history (last 10 messages for context)
    const messages = [
      { role: "system", content: system },
      ...history.slice(-10).map(h => ({ role: h.role, content: h.content })),
      { role: "user", content: message.trim() },
    ];

    const completion = await groq.chat.completions.create({
      model: "llama-3.3-70b-versatile",
      max_tokens: 800,
      messages,
    });

    const reply = completion.choices[0]?.message?.content || "I couldn't generate a response. Please try again.";

    res.json({
      reply,
      tokens: completion.usage?.total_tokens || 0,
    });
  } catch (err) {
    console.error("/chat/message:", err.message);
    res.status(500).json({ error: "Chat failed", detail: err.message });
  }
});

// GET /chat/suggestions — context-aware quick prompts for the user
router.get("/suggestions", authMiddleware, async (req, res) => {
  try {
    const dbUser = await User.findById(req.user.id).select("-password").lean().catch(() => null);
    const role   = dbUser?.targetRole || "SDE";
    const level  = dbUser?.resumeData?.experienceLevel || "fresher";

    const fresherSuggestions = [
      `What DSA topics are most important for ${role} interviews?`,
      "Explain the difference between BFS and DFS with examples",
      "How do I answer 'Tell me about yourself' for a fresher?",
      "What are ACID properties in DBMS?",
      "Review my project and suggest improvements",
      "What's the STAR method for behavioral interviews?",
      "How to crack the HR round as a fresher?",
      "Explain time and space complexity with examples",
    ];

    const midSuggestions = [
      `What system design topics should I know for ${role}?`,
      "How to negotiate salary for a 2-year experienced developer?",
      "Explain microservices vs monolith architecture",
      "What are the most common React interview questions?",
      "How to prepare for a Staff Engineer interview?",
      "Explain CAP theorem with real-world examples",
    ];

    const suggestions = level === "fresher" || level === "junior" ? fresherSuggestions : midSuggestions;
    res.json({ suggestions: suggestions.slice(0, 6) });
  } catch (err) {
    res.json({ suggestions: ["What should I prepare for interviews?", "Explain DSA basics", "How to write a strong resume?"] });
  }
});

export default router;
