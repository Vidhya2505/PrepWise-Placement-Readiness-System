import express from "express";
import { saveInterview, getStats, getHistory } from "../controllers/interviewController.js";
import authMiddleware from "../middleware/authMiddleware.js";

const router = express.Router();
router.post("/save",    authMiddleware, saveInterview);
router.get ("/stats",   authMiddleware, getStats);
router.get ("/history", authMiddleware, getHistory);
export default router;
