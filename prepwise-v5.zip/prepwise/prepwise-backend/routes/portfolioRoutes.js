import express from "express";
import Groq from "groq-sdk";
import authMiddleware from "../middleware/authMiddleware.js";
import User from "../models/User.js";

const router = express.Router();

async function groqJSON(system, user, maxTokens = 2500) {
  const groq = new Groq({ apiKey: process.env.GROQ_API_KEY });
  const res = await groq.chat.completions.create({
    model: "llama-3.3-70b-versatile",
    max_tokens: maxTokens,
    messages: [{ role: "system", content: system }, { role: "user", content: user }],
  });
  const raw = res.choices[0]?.message?.content || "{}";
  const clean = raw.replace(/```json|```/g, "").trim();
  try { return JSON.parse(clean); }
  catch { return { raw }; }
}

// POST /portfolio/generate — generate full portfolio content from resume data
router.post("/generate", authMiddleware, async (req, res) => {
  try {
    const { resumeText, jobDescription, userProfile } = req.body;
    if (!resumeText) return res.status(400).json({ error: "resumeText required" });

    // Also pull saved profile from DB for richer context
    const dbUser = await User.findById(req.user.id).select("-password").lean().catch(() => null);

    const context = `
NAME: ${dbUser?.name || userProfile?.name || "Developer"}
TARGET ROLE: ${dbUser?.targetRole || userProfile?.targetRole || "Software Developer"}
EXPERIENCE LEVEL: ${dbUser?.resumeData?.experienceLevel || "fresher"}
SKILLS: ${(dbUser?.resumeData?.skills || dbUser?.skills || []).join(", ") || "Not specified"}
EDUCATION: ${dbUser?.resumeData?.education || ""}
PROJECTS: ${(dbUser?.resumeData?.projects || []).map(p => `${p.name} (${(p.tech || []).join(", ")}): ${p.description}`).join(" | ") || "From resume below"}
JOB DESCRIPTION HINT: ${(jobDescription || "").slice(0, 500)}
RESUME TEXT: ${resumeText.slice(0, 4000)}`;

    const system = `You are an expert portfolio copywriter and personal branding specialist.
Transform a developer's resume into compelling portfolio content.
Return ONLY valid JSON — no markdown, no text outside the JSON.`;

    const prompt = `${context}

Generate a complete, compelling portfolio in JSON:
{
  "hero": {
    "headline": "3-6 word punchy tagline (e.g. 'Building Products People Actually Use')",
    "subheadline": "1-2 sentence description of who they are and what they build",
    "badge": "Short role label e.g. 'Full Stack Developer'",
    "ctaText": "Hire Me"
  },
  "about": {
    "summary": "3-4 sentence compelling about paragraph in first person. Enthusiastic, specific, not generic.",
    "highlights": [
      { "label": "Focus Area",    "value": "e.g. Full Stack Web Dev" },
      { "label": "Experience",    "value": "e.g. Fresher / 2 years" },
      { "label": "Education",     "value": "e.g. B.Tech CSE, 2025" },
      { "label": "Open To",       "value": "e.g. SDE roles, Remote" }
    ]
  },
  "skills": {
    "categories": [
      { "name": "Frontend",      "items": [] },
      { "name": "Backend",       "items": [] },
      { "name": "Tools & DevOps","items": [] },
      { "name": "CS Fundamentals","items": [] }
    ]
  },
  "projects": [
    {
      "name": "Project Name",
      "tagline": "One punchy sentence on what it does",
      "description": "2-3 sentence description highlighting technical decisions and impact",
      "tech": ["React","Node.js"],
      "highlights": ["Built X that achieved Y","Implemented Z reducing time by N%"],
      "githubUrl": "",
      "liveUrl": "",
      "featured": true
    }
  ],
  "experience": [
    {
      "role": "Role Title",
      "org": "Organization",
      "duration": "Duration",
      "bullets": ["Achievement 1","Achievement 2"]
    }
  ],
  "education": [
    {
      "degree": "B.Tech Computer Science",
      "institution": "University Name",
      "year": "2025",
      "gpa": "",
      "highlights": ["Relevant coursework or achievements"]
    }
  ],
  "achievements": [
    { "title": "Achievement", "description": "Brief context", "icon": "trophy" }
  ],
  "contactSuggestions": {
    "tagline": "Short 'let's connect' message",
    "email": "",
    "linkedin": "",
    "github": ""
  },
  "seoMeta": {
    "title": "Name | Role",
    "description": "160-char meta description"
  }
}`;

    const result = await groqJSON(system, prompt, 3000);

    // Safe defaults
    const safe = {
      hero: result.hero || { headline: "Building Great Software", subheadline: "A passionate developer.", badge: "Developer", ctaText: "Hire Me" },
      about: result.about || { summary: "", highlights: [] },
      skills: result.skills || { categories: [] },
      projects: Array.isArray(result.projects) ? result.projects : [],
      experience: Array.isArray(result.experience) ? result.experience : [],
      education: Array.isArray(result.education) ? result.education : [],
      achievements: Array.isArray(result.achievements) ? result.achievements : [],
      contactSuggestions: result.contactSuggestions || { tagline: "Let's build something great together." },
      seoMeta: result.seoMeta || { title: "Portfolio", description: "" },
      generatedAt: new Date().toISOString(),
    };

    res.json(safe);
  } catch (err) {
    console.error("/portfolio/generate:", err.message);
    res.status(500).json({ error: "Portfolio generation failed", detail: err.message });
  }
});

// POST /portfolio/export-html — generate a standalone HTML portfolio file
router.post("/export-html", authMiddleware, async (req, res) => {
  try {
    const { portfolioData, theme = "dark" } = req.body;
    if (!portfolioData) return res.status(400).json({ error: "portfolioData required" });

    const { hero, about, skills, projects, experience, education, achievements, contactSuggestions } = portfolioData;
    const isDark = theme === "dark";

    const skillsHTML = (skills?.categories || []).map(cat => `
      <div class="skill-category">
        <h4 class="skill-cat-name">${cat.name}</h4>
        <div class="skill-items">${(cat.items || []).map(s => `<span class="skill-chip">${s}</span>`).join("")}</div>
      </div>`).join("");

    const projectsHTML = (projects || []).map(p => `
      <div class="project-card ${p.featured ? "featured" : ""}">
        ${p.featured ? '<div class="featured-badge">Featured</div>' : ""}
        <h3 class="project-name">${p.name}</h3>
        <p class="project-tagline">${p.tagline || ""}</p>
        <p class="project-desc">${p.description || ""}</p>
        <div class="project-tech">${(p.tech || []).map(t => `<span class="tech-chip">${t}</span>`).join("")}</div>
        ${p.highlights?.length ? `<ul class="project-highlights">${p.highlights.map(h => `<li>${h}</li>`).join("")}</ul>` : ""}
        <div class="project-links">
          ${p.githubUrl ? `<a href="${p.githubUrl}" target="_blank" rel="noopener">GitHub →</a>` : ""}
          ${p.liveUrl ? `<a href="${p.liveUrl}" target="_blank" rel="noopener" class="live-link">Live Demo →</a>` : ""}
        </div>
      </div>`).join("");

    const expHTML = (experience || []).map(e => `
      <div class="exp-item">
        <div class="exp-header">
          <div><div class="exp-role">${e.role}</div><div class="exp-org">${e.org}</div></div>
          <div class="exp-duration">${e.duration || ""}</div>
        </div>
        <ul class="exp-bullets">${(e.bullets || []).map(b => `<li>${b}</li>`).join("")}</ul>
      </div>`).join("");

    const eduHTML = (education || []).map(e => `
      <div class="edu-item">
        <div class="edu-degree">${e.degree}</div>
        <div class="edu-inst">${e.institution}${e.year ? ` · ${e.year}` : ""}${e.gpa ? ` · GPA ${e.gpa}` : ""}</div>
        ${e.highlights?.length ? `<ul class="edu-highlights">${e.highlights.map(h => `<li>${h}</li>`).join("")}</ul>` : ""}
      </div>`).join("");

    const html = `<!DOCTYPE html>
<html lang="en" data-theme="${theme}">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>${portfolioData.seoMeta?.title || "Portfolio"}</title>
<meta name="description" content="${portfolioData.seoMeta?.description || ""}"/>
<link rel="preconnect" href="https://fonts.googleapis.com"/>
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:opsz,wght@9..40,400;9..40,500;9..40,600&display=swap" rel="stylesheet"/>
<style>
*{margin:0;padding:0;box-sizing:border-box}
:root{
  --bg:#080C14;--bg2:#0D1420;--card:#111827;
  --border:rgba(99,179,237,0.12);--border-s:rgba(99,179,237,0.25);
  --t1:#F0F4FF;--t2:#94A3B8;--t3:#4A5568;
  --blue:#3B8EFF;--cyan:#00D4FF;--green:#00E5A0;--purple:#8B5CF6;
  --glow:rgba(59,142,255,0.1);
}
[data-theme="light"]{
  --bg:#F0F4FF;--bg2:#E8EEFB;--card:#FFFFFF;
  --border:rgba(59,142,255,0.14);--border-s:rgba(59,142,255,0.28);
  --t1:#0A0F1E;--t2:#475569;--t3:#94A3B8;
  --blue:#2563EB;--cyan:#0891B2;--green:#059669;--purple:#7C3AED;
  --glow:rgba(37,99,235,0.07);
}
html{scroll-behavior:smooth}
body{font-family:'DM Sans',sans-serif;background:var(--bg);color:var(--t1);line-height:1.7}
h1,h2,h3,h4{font-family:'Syne',sans-serif}
a{color:var(--blue);text-decoration:none}
nav{position:fixed;top:0;left:0;right:0;z-index:100;background:rgba(8,12,20,0.9);backdrop-filter:blur(12px);border-bottom:1px solid var(--border);padding:0 5%;height:60px;display:flex;align-items:center;justify-content:space-between}
[data-theme="light"] nav{background:rgba(240,244,255,0.92)}
.nav-brand{font-family:'Syne',sans-serif;font-weight:800;font-size:1.1rem;color:var(--t1)}
.nav-brand span{color:var(--blue)}
.nav-links{display:flex;gap:24px}
.nav-links a{color:var(--t2);font-size:0.875rem;font-weight:500;transition:color 0.2s}
.nav-links a:hover{color:var(--t1)}
section{padding:100px 5%}
.section-tag{display:inline-flex;align-items:center;gap:6px;background:var(--glow);border:1px solid var(--border-s);color:var(--blue);font-size:0.72rem;font-weight:700;letter-spacing:0.06em;text-transform:uppercase;border-radius:100px;padding:4px 12px;margin-bottom:14px}
.section-title{font-weight:800;font-size:clamp(1.8rem,4vw,2.8rem);letter-spacing:-0.03em;line-height:1.1;margin-bottom:16px}
.gradient{background:linear-gradient(135deg,var(--blue),var(--cyan));-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text}
/* Hero */
#hero{min-height:100vh;display:flex;align-items:center;justify-content:center;text-align:center;position:relative;overflow:hidden;padding-top:60px}
.hero-badge{display:inline-flex;align-items:center;gap:7px;background:var(--glow);border:1px solid var(--border-s);color:var(--blue);font-size:0.78rem;font-weight:700;border-radius:100px;padding:5px 16px;margin-bottom:24px}
.hero-h1{font-weight:800;font-size:clamp(2.8rem,7vw,5.5rem);letter-spacing:-0.05em;line-height:1.05;margin-bottom:20px}
.hero-sub{color:var(--t2);font-size:clamp(1rem,2vw,1.2rem);max-width:540px;margin:0 auto 36px;line-height:1.75}
.hero-cta{display:inline-flex;align-items:center;gap:8px;padding:13px 32px;border-radius:10px;background:linear-gradient(135deg,var(--blue),var(--cyan));color:#fff;font-weight:700;font-size:0.95rem;border:none;cursor:pointer;text-decoration:none;transition:opacity 0.2s}
.hero-cta:hover{opacity:0.88}
/* About */
#about{background:var(--bg2)}
.about-grid{display:grid;grid-template-columns:1fr 1fr;gap:60px;align-items:start;margin-top:40px}
.about-text{color:var(--t2);font-size:1rem;line-height:1.85}
.highlights{display:grid;gap:12px;margin-top:24px}
.highlight-item{display:flex;align-items:center;gap:12px;padding:12px 16px;background:var(--card);border:1px solid var(--border);border-radius:10px}
.hl-label{font-size:0.72rem;font-weight:700;color:var(--t3);text-transform:uppercase;letter-spacing:0.06em;margin-bottom:2px}
.hl-value{font-size:0.9rem;font-weight:600;color:var(--t1)}
/* Skills */
#skills .skill-category{margin-bottom:28px}
.skill-cat-name{font-size:0.78rem;font-weight:700;color:var(--t3);text-transform:uppercase;letter-spacing:0.06em;margin-bottom:10px}
.skill-items{display:flex;flex-wrap:wrap;gap:8px}
.skill-chip{padding:5px 14px;border-radius:100px;background:var(--card);border:1px solid var(--border);font-size:0.82rem;color:var(--t2);font-weight:500;transition:all 0.2s}
.skill-chip:hover{border-color:var(--blue);color:var(--blue)}
.skills-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:24px;margin-top:32px}
/* Projects */
#projects{background:var(--bg2)}
.projects-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(320px,1fr));gap:20px;margin-top:36px}
.project-card{background:var(--card);border:1px solid var(--border);border-radius:14px;padding:24px;position:relative;transition:border-color 0.2s}
.project-card:hover{border-color:var(--border-s)}
.project-card.featured{border-color:rgba(59,142,255,0.3)}
.featured-badge{position:absolute;top:14px;right:14px;font-size:0.62rem;font-weight:800;padding:2px 8px;border-radius:100px;background:var(--glow);border:1px solid var(--border-s);color:var(--blue);text-transform:uppercase;letter-spacing:0.06em}
.project-name{font-size:1.05rem;font-weight:700;margin-bottom:6px;color:var(--t1)}
.project-tagline{font-size:0.82rem;color:var(--blue);font-weight:600;margin-bottom:10px}
.project-desc{font-size:0.875rem;color:var(--t2);line-height:1.65;margin-bottom:14px}
.project-tech{display:flex;flex-wrap:wrap;gap:5px;margin-bottom:12px}
.tech-chip{padding:2px 9px;border-radius:6px;background:var(--glow);border:1px solid var(--border-s);font-size:0.72rem;color:var(--blue);font-weight:600}
.project-highlights{margin:0 0 12px 18px;font-size:0.8rem;color:var(--t2);line-height:1.6}
.project-links{display:flex;gap:14px;font-size:0.82rem;font-weight:600}
.project-links a{color:var(--t3);transition:color 0.2s}
.project-links a:hover{color:var(--blue)}
.project-links .live-link{color:var(--green)}
/* Experience */
.exp-item{border-left:2px solid var(--border-s);padding-left:20px;margin-bottom:28px;position:relative}
.exp-item::before{content:'';position:absolute;left:-5px;top:6px;width:8px;height:8px;border-radius:50%;background:var(--blue)}
.exp-header{display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:10px;flex-wrap:wrap;gap:8px}
.exp-role{font-weight:700;font-size:1rem;color:var(--t1)}
.exp-org{font-size:0.85rem;color:var(--blue);font-weight:600}
.exp-duration{font-size:0.78rem;color:var(--t3);background:var(--card);border:1px solid var(--border);padding:3px 10px;border-radius:6px}
.exp-bullets{margin-left:18px;font-size:0.875rem;color:var(--t2);line-height:1.7}
/* Education */
#education{background:var(--bg2)}
.edu-item{background:var(--card);border:1px solid var(--border);border-radius:12px;padding:20px 22px;margin-bottom:14px}
.edu-degree{font-weight:700;font-size:1rem;color:var(--t1);margin-bottom:4px}
.edu-inst{font-size:0.85rem;color:var(--blue);font-weight:600;margin-bottom:8px}
.edu-highlights{margin-left:18px;font-size:0.82rem;color:var(--t2);line-height:1.6}
/* Contact */
#contact{text-align:center}
.contact-tagline{color:var(--t2);font-size:1.05rem;max-width:480px;margin:18px auto 36px;line-height:1.75}
.contact-links{display:flex;gap:12px;justify-content:center;flex-wrap:wrap}
.contact-btn{display:inline-flex;align-items:center;gap:7px;padding:11px 22px;border-radius:10px;border:1px solid var(--border-s);color:var(--t2);font-size:0.875rem;font-weight:600;transition:all 0.2s;background:var(--card)}
.contact-btn:hover{border-color:var(--blue);color:var(--blue)}
/* Footer */
footer{border-top:1px solid var(--border);padding:22px 5%;display:flex;justify-content:space-between;align-items:center;font-size:0.82rem;color:var(--t3);flex-wrap:wrap;gap:10px;background:var(--bg2)}
/* Orb effects */
.orb{position:absolute;border-radius:50%;filter:blur(80px);opacity:0.25;pointer-events:none}
.orb-blue{background:radial-gradient(circle,#3B8EFF,transparent)}
.orb-green{background:radial-gradient(circle,#00E5A0,transparent)}
@media(max-width:768px){
  .about-grid{grid-template-columns:1fr}
  .projects-grid{grid-template-columns:1fr}
  .nav-links{display:none}
}
</style>
</head>
<body>
<nav>
  <div class="nav-brand">Port<span>folio</span></div>
  <div class="nav-links">
    <a href="#about">About</a>
    <a href="#skills">Skills</a>
    <a href="#projects">Projects</a>
    ${experience?.length ? '<a href="#experience">Experience</a>' : ""}
    <a href="#education">Education</a>
    <a href="#contact">Contact</a>
  </div>
</nav>

<section id="hero">
  <div class="orb orb-blue" style="width:600px;height:600px;top:-100px;left:60%"></div>
  <div class="orb orb-green" style="width:300px;height:300px;bottom:10%;left:5%"></div>
  <div style="position:relative;z-index:1;max-width:780px;margin:0 auto;padding:0 24px">
    <div class="hero-badge">✦ ${hero?.badge || "Developer"}</div>
    <h1 class="hero-h1"><span class="gradient">${hero?.headline || "Building Great Software"}</span></h1>
    <p class="hero-sub">${hero?.subheadline || ""}</p>
    <a href="#contact" class="hero-cta">${hero?.ctaText || "Hire Me"} →</a>
  </div>
</section>

<section id="about">
  <div class="section-tag">✦ About Me</div>
  <h2 class="section-title">Who I Am &amp; <span class="gradient">What I Build</span></h2>
  <div class="about-grid">
    <div>
      <p class="about-text">${about?.summary || ""}</p>
    </div>
    <div class="highlights">
      ${(about?.highlights || []).map(h => `<div class="highlight-item"><div><div class="hl-label">${h.label}</div><div class="hl-value">${h.value}</div></div></div>`).join("")}
    </div>
  </div>
</section>

<section id="skills">
  <div class="section-tag">✦ Technical Skills</div>
  <h2 class="section-title">My <span class="gradient">Tech Stack</span></h2>
  <div class="skills-grid">${skillsHTML}</div>
</section>

<section id="projects">
  <div class="section-tag">✦ Projects</div>
  <h2 class="section-title">Things I've <span class="gradient">Built</span></h2>
  <div class="projects-grid">${projectsHTML}</div>
</section>

${experience?.length ? `
<section id="experience">
  <div class="section-tag">✦ Experience</div>
  <h2 class="section-title">Where I've <span class="gradient">Worked</span></h2>
  <div style="max-width:720px;margin-top:36px">${expHTML}</div>
</section>` : ""}

<section id="education">
  <div class="section-tag">✦ Education</div>
  <h2 class="section-title">My <span class="gradient">Background</span></h2>
  <div style="max-width:680px;margin-top:32px">${eduHTML}</div>
</section>

<section id="contact">
  <div class="section-tag">✦ Contact</div>
  <h2 class="section-title">Let's <span class="gradient">Work Together</span></h2>
  <p class="contact-tagline">${contactSuggestions?.tagline || "Open to new opportunities."}</p>
  <div class="contact-links">
    ${contactSuggestions?.email ? `<a href="mailto:${contactSuggestions.email}" class="contact-btn">✉ ${contactSuggestions.email}</a>` : ""}
    ${contactSuggestions?.linkedin ? `<a href="${contactSuggestions.linkedin}" target="_blank" rel="noopener" class="contact-btn">in LinkedIn</a>` : ""}
    ${contactSuggestions?.github ? `<a href="${contactSuggestions.github}" target="_blank" rel="noopener" class="contact-btn">⌥ GitHub</a>` : ""}
  </div>
</section>

<footer>
  <span>Built with PrepWise Portfolio Generator</span>
  <span>© ${new Date().getFullYear()}</span>
</footer>
</body>
</html>`;

    res.json({ html });
  } catch (err) {
    console.error("/portfolio/export-html:", err.message);
    res.status(500).json({ error: "Export failed", detail: err.message });
  }
});

export default router;
