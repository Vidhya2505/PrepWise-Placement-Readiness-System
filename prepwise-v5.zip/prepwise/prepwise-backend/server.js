import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import rateLimit from "express-rate-limit";
import connectDB from "./config/db.js";
import authRoutes from "./routes/authRoutes.js";
import aiRoutes from "./routes/aiRoutes.js";
import interviewRoutes from "./routes/interviewRoutes.js";
import portfolioRoutes from "./routes/portfolioRoutes.js";
import chatRoutes from "./routes/chatRoutes.js";
import careerRoutes from "./routes/careerRoutes.js";

dotenv.config();

const app = express();

const allowedOrigins = process.env.ALLOWED_ORIGINS
  ? process.env.ALLOWED_ORIGINS.split(",").map(o => o.trim()) : [];

app.use(cors({
  origin: (origin, cb) => {
    if (!origin) return cb(null, true);
    if (process.env.NODE_ENV !== "production" && origin.startsWith("http://localhost")) return cb(null, true);
    if (allowedOrigins.includes(origin)) return cb(null, true);
    cb(new Error("Not allowed by CORS"));
  },
  credentials: true,
}));

app.use(express.json({ limit: "5mb" }));

const authLimiter  = rateLimit({ windowMs: 15*60*1000, max: 20, message: { error: "Too many auth requests." }, standardHeaders: true, legacyHeaders: false });
const aiLimiter    = rateLimit({ windowMs: 60*1000,    max: 10, message: { error: "Too many AI requests — max 10/min." }, standardHeaders: true, legacyHeaders: false });
const chatLimiter  = rateLimit({ windowMs: 60*1000,    max: 20, message: { error: "Too many chat messages — max 20/min." }, standardHeaders: true, legacyHeaders: false });

connectDB();

app.get("/",       (_, res) => res.json({ status: "PrepWise API running 🚀" }));
app.get("/health", (_, res) => res.json({ ok: true }));

app.use("/auth",      authLimiter, authRoutes);
app.use("/ai",        aiLimiter,   aiRoutes);
app.use("/interview", interviewRoutes);
app.use("/portfolio", aiLimiter,   portfolioRoutes);
app.use("/chat",      chatLimiter, chatRoutes);
app.use("/career",    aiLimiter,   careerRoutes);

app.use((err, _req, res, _next) => {
  console.error("Unhandled error:", err.message);
  res.status(500).json({ error: "Internal server error" });
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`🚀 Server on http://localhost:${PORT}`));
