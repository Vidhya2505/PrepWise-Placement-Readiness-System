import { Routes, Route, Navigate } from "react-router-dom";
import { useAuth } from "./context/AuthContext";
import AppLayout from "./components/layout/AppLayout";
import Navbar from "./components/Navbar";
import ChatBot from "./components/ChatBot";

import HomePage       from "./pages/HomePage";
import LoginPage      from "./pages/LoginPage";
import SignupPage     from "./pages/SignupPage";
import Dashboard      from "./pages/Dashboard";
import MockInterview  from "./pages/MockInterview";
import ResumeAnalyzer from "./pages/ResumeAnalyzer";
import SkillGap       from "./pages/SkillGap";
import Profile        from "./pages/Profile";
import Portfolio      from "./pages/Portfolio";
import CareerReport   from "./pages/CareerReport";

function PrivateRoute({ children }: { children: React.ReactNode }) {
  const { user, loading } = useAuth();
  if (loading) return (
    <div style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", background: "var(--bg-primary)" }}>
      <div style={{ width: 40, height: 40, borderRadius: "50%", border: "3px solid var(--border)", borderTopColor: "var(--accent-blue)", animation: "spin 0.8s linear infinite" }} />
    </div>
  );
  return user ? <>{children}</> : <Navigate to="/login" replace />;
}

export default function App() {
  const { user } = useAuth();
  return (
    <>
      <Routes>
        <Route path="/"       element={<><Navbar /><HomePage /></>} />
        <Route path="/login"  element={<><Navbar /><LoginPage /></>} />
        <Route path="/signup" element={<><Navbar /><SignupPage /></>} />
        <Route path="/dashboard"     element={<PrivateRoute><AppLayout><Dashboard /></AppLayout></PrivateRoute>} />
        <Route path="/mock"          element={<PrivateRoute><AppLayout><MockInterview /></AppLayout></PrivateRoute>} />
        <Route path="/resume"        element={<PrivateRoute><AppLayout><ResumeAnalyzer /></AppLayout></PrivateRoute>} />
        <Route path="/skill"         element={<PrivateRoute><AppLayout><SkillGap /></AppLayout></PrivateRoute>} />
        <Route path="/profile"       element={<PrivateRoute><AppLayout><Profile /></AppLayout></PrivateRoute>} />
        <Route path="/portfolio"     element={<PrivateRoute><AppLayout><Portfolio /></AppLayout></PrivateRoute>} />
        <Route path="/career-report" element={<PrivateRoute><AppLayout><CareerReport /></AppLayout></PrivateRoute>} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
      {user && <ChatBot />}
    </>
  );
}
