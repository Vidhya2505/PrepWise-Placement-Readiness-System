import { useState, useRef, useEffect, useCallback } from "react";
import {
  MessageSquare, X, Send, Minimize2, Maximize2,
  Brain, User, RefreshCw, Zap, ChevronDown
} from "lucide-react";

interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: Date;
}

function formatContent(text: string): string {
  return text
    .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
    .replace(/\*(.*?)\*/g, '<em>$1</em>')
    .replace(/`(.*?)`/g, '<code style="background:var(--bg-primary);padding:1px 5px;border-radius:4px;font-family:monospace;font-size:0.85em">$1</code>')
    .replace(/\n\n/g, '</p><p style="margin-top:8px">')
    .replace(/\n/g, '<br/>')
    .replace(/^(\d+)\.\s/gm, '<span style="color:var(--accent-blue);font-weight:700">$1.</span> ')
    .replace(/^[-•]\s/gm, '<span style="color:var(--accent-cyan)">▸</span> ');
}

export default function ChatBot() {
  const [open, setOpen]             = useState(false);
  const [minimized, setMinimized]   = useState(false);
  const [messages, setMessages]     = useState<Message[]>([]);
  const [input, setInput]           = useState("");
  const [loading, setLoading]       = useState(false);
  const [suggestions, setSuggestions] = useState<string[]>([]);
  const [showSugg, setShowSugg]     = useState(true);
  const [unread, setUnread]         = useState(0);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef       = useRef<HTMLTextAreaElement>(null);

  const token = () => localStorage.getItem("token") || "";

  // Load suggestions on first open
  useEffect(() => {
    if (open && suggestions.length === 0) {
      fetch("/chat/suggestions", { headers: { Authorization: `Bearer ${token()}` } })
        .then(r => r.json())
        .then(d => setSuggestions(d.suggestions || []))
        .catch(() => {});
    }
    if (open) setUnread(0);
  }, [open]);

  useEffect(() => {
    if (open && !minimized) {
      messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    }
  }, [messages, open, minimized]);

  // Welcome message on first open
  useEffect(() => {
    if (open && messages.length === 0) {
      setMessages([{
        id: "welcome",
        role: "assistant",
        content: "Hey! I'm PrepBot 👋\n\nI'm your AI career coach inside PrepWise. Ask me anything about:\n- DSA problems & algorithms\n- Interview prep & tips\n- Resume feedback\n- System design\n- Career guidance\n\nWhat can I help you with today?",
        timestamp: new Date(),
      }]);
    }
  }, [open]);

  const send = useCallback(async (text?: string) => {
    const msg = (text || input).trim();
    if (!msg || loading) return;
    setInput(""); setShowSugg(false);

    const userMsg: Message = { id: Date.now().toString(), role: "user", content: msg, timestamp: new Date() };
    setMessages(prev => [...prev, userMsg]);
    setLoading(true);

    try {
      const history = messages.slice(-10).map(m => ({ role: m.role, content: m.content }));
      const res = await fetch("/chat/message", {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${token()}` },
        body: JSON.stringify({ message: msg, history }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed");

      const botMsg: Message = { id: (Date.now() + 1).toString(), role: "assistant", content: data.reply, timestamp: new Date() };
      setMessages(prev => [...prev, botMsg]);
      if (!open) setUnread(u => u + 1);
    } catch (err) {
      setMessages(prev => [...prev, {
        id: (Date.now() + 1).toString(), role: "assistant",
        content: "Sorry, I hit a snag. Check your connection and try again.",
        timestamp: new Date(),
      }]);
    } finally { setLoading(false); }
  }, [input, loading, messages, open]);

  const handleKey = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(); }
  };

  const clear = () => { setMessages([]); setShowSugg(true); };

  const W = 360;
  const H = minimized ? 56 : 520;

  return (
    <>
      {/* FAB */}
      {!open && (
        <button
          onClick={() => setOpen(true)}
          style={{ position: "fixed", bottom: 24, right: 24, width: 54, height: 54, borderRadius: "50%", background: "linear-gradient(135deg, var(--accent-blue), var(--accent-cyan))", border: "none", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", boxShadow: "0 4px 20px rgba(59,142,255,0.4)", zIndex: 999, transition: "transform 0.2s" }}
          onMouseEnter={e => (e.currentTarget.style.transform = "scale(1.08)")}
          onMouseLeave={e => (e.currentTarget.style.transform = "scale(1)")}
        >
          <MessageSquare size={22} color="#fff" />
          {unread > 0 && (
            <div style={{ position: "absolute", top: 4, right: 4, width: 18, height: 18, borderRadius: "50%", background: "#ef4444", color: "#fff", fontSize: "0.65rem", fontWeight: 800, display: "flex", alignItems: "center", justifyContent: "center" }}>{unread}</div>
          )}
        </button>
      )}

      {/* Chat window */}
      {open && (
        <div style={{
          position: "fixed", bottom: 24, right: 24, width: W, height: H,
          background: "var(--bg-card)", border: "1px solid var(--border-strong)",
          borderRadius: 16, display: "flex", flexDirection: "column",
          boxShadow: "0 12px 48px rgba(0,0,0,0.45)", zIndex: 999,
          transition: "height 0.25s ease", overflow: "hidden",
        }}>
          {/* Header */}
          <div style={{ padding: "12px 14px", borderBottom: "1px solid var(--border)", display: "flex", alignItems: "center", gap: 10, background: "var(--bg-secondary)", flexShrink: 0 }}>
            <div style={{ width: 34, height: 34, borderRadius: 9, background: "linear-gradient(135deg,var(--accent-blue),var(--accent-cyan))", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
              <Brain size={16} color="#fff" />
            </div>
            <div style={{ flex: 1 }}>
              <div style={{ fontFamily: "Syne,sans-serif", fontWeight: 800, fontSize: "0.875rem", color: "var(--text-primary)" }}>PrepBot</div>
              <div style={{ fontSize: "0.65rem", color: "var(--accent-green)", display: "flex", alignItems: "center", gap: 4 }}>
                <div style={{ width: 5, height: 5, borderRadius: "50%", background: "var(--accent-green)" }} /> AI Career Coach
              </div>
            </div>
            <div style={{ display: "flex", gap: 4 }}>
              <button onClick={clear} title="Clear chat" style={{ background: "none", border: "none", cursor: "pointer", color: "var(--text-muted)", padding: 4, borderRadius: 6, display: "flex" }}>
                <RefreshCw size={13} />
              </button>
              <button onClick={() => setMinimized(m => !m)} style={{ background: "none", border: "none", cursor: "pointer", color: "var(--text-muted)", padding: 4, borderRadius: 6, display: "flex" }}>
                {minimized ? <Maximize2 size={13} /> : <Minimize2 size={13} />}
              </button>
              <button onClick={() => setOpen(false)} style={{ background: "none", border: "none", cursor: "pointer", color: "var(--text-muted)", padding: 4, borderRadius: 6, display: "flex" }}>
                <X size={14} />
              </button>
            </div>
          </div>

          {!minimized && (
            <>
              {/* Messages */}
              <div style={{ flex: 1, overflowY: "auto", padding: "12px", display: "flex", flexDirection: "column", gap: 10 }}>
                {messages.map(msg => (
                  <div key={msg.id} style={{ display: "flex", gap: 8, alignItems: "flex-start", flexDirection: msg.role === "user" ? "row-reverse" : "row" }}>
                    <div style={{ width: 28, height: 28, borderRadius: "50%", flexShrink: 0, display: "flex", alignItems: "center", justifyContent: "center", background: msg.role === "user" ? "linear-gradient(135deg,var(--accent-blue),var(--accent-cyan))" : "var(--bg-primary)", border: "1px solid var(--border)" }}>
                      {msg.role === "user" ? <User size={13} color="#fff" /> : <Brain size={13} color="var(--accent-blue)" />}
                    </div>
                    <div style={{ maxWidth: "82%", padding: "9px 12px", borderRadius: msg.role === "user" ? "12px 12px 4px 12px" : "12px 12px 12px 4px", background: msg.role === "user" ? "linear-gradient(135deg,var(--accent-blue),var(--accent-cyan))" : "var(--bg-primary)", border: msg.role === "user" ? "none" : "1px solid var(--border)" }}>
                      <div
                        style={{ fontSize: "0.82rem", color: msg.role === "user" ? "#fff" : "var(--text-secondary)", lineHeight: 1.65, whiteSpace: "pre-wrap" }}
                        dangerouslySetInnerHTML={{ __html: `<p>${formatContent(msg.content)}</p>` }}
                      />
                      <div style={{ fontSize: "0.6rem", color: msg.role === "user" ? "rgba(255,255,255,0.6)" : "var(--text-muted)", marginTop: 4, textAlign: msg.role === "user" ? "right" : "left" }}>
                        {msg.timestamp.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                      </div>
                    </div>
                  </div>
                ))}

                {loading && (
                  <div style={{ display: "flex", gap: 8, alignItems: "flex-start" }}>
                    <div style={{ width: 28, height: 28, borderRadius: "50%", flexShrink: 0, display: "flex", alignItems: "center", justifyContent: "center", background: "var(--bg-primary)", border: "1px solid var(--border)" }}>
                      <Brain size={13} color="var(--accent-blue)" />
                    </div>
                    <div style={{ padding: "10px 14px", borderRadius: "12px 12px 12px 4px", background: "var(--bg-primary)", border: "1px solid var(--border)", display: "flex", gap: 5, alignItems: "center" }}>
                      {[0, 1, 2].map(i => (
                        <div key={i} style={{ width: 6, height: 6, borderRadius: "50%", background: "var(--accent-blue)", animation: "pulse 1.2s ease-in-out infinite", animationDelay: `${i * 0.2}s` }} />
                      ))}
                    </div>
                  </div>
                )}

                {/* Quick suggestions */}
                {showSugg && suggestions.length > 0 && messages.length <= 1 && (
                  <div style={{ marginTop: 4 }}>
                    <div style={{ fontSize: "0.65rem", color: "var(--text-muted)", marginBottom: 7, display: "flex", alignItems: "center", gap: 4 }}><Zap size={9} color="var(--accent-cyan)"/> Quick questions</div>
                    <div style={{ display: "flex", flexDirection: "column", gap: 5 }}>
                      {suggestions.slice(0, 4).map((s, i) => (
                        <button key={i} onClick={() => send(s)} style={{ textAlign: "left", padding: "7px 10px", borderRadius: 8, background: "var(--bg-primary)", border: "1px solid var(--border)", cursor: "pointer", fontSize: "0.75rem", color: "var(--text-secondary)", transition: "all 0.15s" }}
                          onMouseEnter={e => { (e.currentTarget as HTMLElement).style.borderColor = "var(--accent-blue)"; (e.currentTarget as HTMLElement).style.color = "var(--text-primary)"; }}
                          onMouseLeave={e => { (e.currentTarget as HTMLElement).style.borderColor = "var(--border)"; (e.currentTarget as HTMLElement).style.color = "var(--text-secondary)"; }}>
                          {s}
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                <div ref={messagesEndRef} />
              </div>

              {/* Input */}
              <div style={{ padding: "10px 12px", borderTop: "1px solid var(--border)", flexShrink: 0, background: "var(--bg-secondary)" }}>
                <div style={{ display: "flex", gap: 7, alignItems: "flex-end" }}>
                  <textarea
                    ref={inputRef}
                    value={input}
                    onChange={e => setInput(e.target.value)}
                    onKeyDown={handleKey}
                    placeholder="Ask anything about interviews, DSA, career…"
                    rows={1}
                    style={{ flex: 1, padding: "9px 12px", borderRadius: 9, fontSize: "0.83rem", fontFamily: "inherit", background: "var(--input-bg)", border: "1px solid var(--border)", color: "var(--text-primary)", outline: "none", resize: "none", maxHeight: 80, lineHeight: 1.5 }}
                    onInput={e => { const el = e.currentTarget; el.style.height = "auto"; el.style.height = Math.min(el.scrollHeight, 80) + "px"; }}
                  />
                  <button
                    onClick={() => send()}
                    disabled={!input.trim() || loading}
                    style={{ width: 36, height: 36, borderRadius: 9, border: "none", cursor: input.trim() && !loading ? "pointer" : "not-allowed", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0, background: input.trim() && !loading ? "linear-gradient(135deg,var(--accent-blue),var(--accent-cyan))" : "var(--border)", transition: "all 0.18s" }}
                  >
                    <Send size={14} color={input.trim() && !loading ? "#fff" : "var(--text-muted)"} />
                  </button>
                </div>
                <div style={{ fontSize: "0.6rem", color: "var(--text-muted)", marginTop: 5, textAlign: "center" }}>Enter to send · Shift+Enter for new line</div>
              </div>
            </>
          )}
        </div>
      )}
    </>
  );
}
