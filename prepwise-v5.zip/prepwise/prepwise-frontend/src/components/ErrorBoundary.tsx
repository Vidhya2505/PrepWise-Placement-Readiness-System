import { Component, type ReactNode } from "react";

interface Props  { children: ReactNode; }
interface State  { hasError: boolean; error: string; }

export default class ErrorBoundary extends Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = { hasError: false, error: "" };
  }

  static getDerivedStateFromError(err: Error): State {
    return { hasError: true, error: err?.message || "Unknown error" };
  }

  componentDidCatch(err: Error, info: { componentStack: string }) {
    console.error("ErrorBoundary caught:", err, info.componentStack);
  }

  render() {
    if (!this.state.hasError) return this.props.children;

    return (
      <div style={{
        minHeight: "100vh", display: "flex", flexDirection: "column",
        alignItems: "center", justifyContent: "center", padding: "2rem",
        background: "var(--bg-primary)",
      }}>
        <div style={{
          maxWidth: 460, width: "100%", padding: "32px 36px",
          background: "var(--bg-card)", border: "1px solid rgba(239,68,68,0.25)",
          borderRadius: 16, textAlign: "center",
        }}>
          <div style={{ fontSize: "2rem", marginBottom: 16 }}>⚠️</div>
          <h2 style={{ fontFamily: "Syne, sans-serif", fontWeight: 800, fontSize: "1.2rem",
            color: "var(--text-primary)", marginBottom: 10 }}>
            Something went wrong
          </h2>
          <p style={{ color: "var(--text-secondary)", fontSize: "0.85rem",
            marginBottom: 6, lineHeight: 1.65 }}>
            {this.state.error}
          </p>
          <p style={{ color: "var(--text-muted)", fontSize: "0.78rem", marginBottom: 22 }}>
            This error has been logged. You can try refreshing the page.
          </p>
          <button
            onClick={() => { this.setState({ hasError: false, error: "" }); window.location.href = "/dashboard"; }}
            style={{ padding: "10px 24px", borderRadius: 10, cursor: "pointer",
              background: "linear-gradient(135deg, var(--accent-blue), var(--accent-cyan))",
              border: "none", color: "#fff", fontWeight: 700, fontSize: "0.87rem" }}
          >
            Back to Dashboard
          </button>
        </div>
      </div>
    );
  }
}
