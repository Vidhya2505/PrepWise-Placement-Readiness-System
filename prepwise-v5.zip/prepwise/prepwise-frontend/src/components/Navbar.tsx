import { Link, useNavigate } from "react-router-dom";
import { Brain, LogOut, User } from "lucide-react";
import { useAuth } from "../context/AuthContext";
import { useTheme } from "../context/ThemeContext";

export default function Navbar() {
  const { user, logout } = useAuth();
  const { theme, toggle } = useTheme();
  const navigate = useNavigate();

  const handleLogout = () => { logout(); navigate("/"); };

  return (
    <nav style={{ position: "fixed", top: 0, left: 0, right: 0, zIndex: 100, padding: "0 24px", height: 64, display: "flex", alignItems: "center", justifyContent: "space-between" }}>
      <Link to="/" style={{ display: "flex", alignItems: "center", gap: 10, textDecoration: "none" }}>
        <div style={{ width: 34, height: 34, borderRadius: 9, background: "linear-gradient(135deg,var(--accent-blue),var(--accent-cyan))", display: "flex", alignItems: "center", justifyContent: "center" }}>
          <Brain size={18} color="white" />
        </div>
        <span style={{ fontFamily: "Syne,sans-serif", fontWeight: 800, fontSize: "1.15rem", color: "var(--text-primary)" }}>
          Prep<span style={{ color: "var(--accent-blue)" }}>Wise</span>
        </span>
      </Link>

      <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
        <button onClick={toggle} style={{ width: 48, height: 26, borderRadius: 13, background: theme === "dark" ? "var(--accent-blue)" : "var(--border)", border: "none", cursor: "pointer", position: "relative", transition: "background 0.25s" }}>
          <span style={{ position: "absolute", top: 3, width: 20, height: 20, borderRadius: "50%", background: "#fff", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 11, transition: "left 0.25s", left: theme === "dark" ? 25 : 3 }}>
            {theme === "dark" ? "🌙" : "☀️"}
          </span>
        </button>

        {user ? (
          <>
            <Link to="/dashboard" className="btn-ghost" style={{ padding: "7px 14px", borderRadius: 8, textDecoration: "none", fontSize: "0.85rem", display: "flex", alignItems: "center", gap: 6 }}>
              <User size={14} /> Dashboard
            </Link>
            <button onClick={handleLogout} className="btn-ghost" style={{ padding: "7px 14px", borderRadius: 8, fontSize: "0.85rem", display: "flex", alignItems: "center", gap: 6 }}>
              <LogOut size={14} /> Sign Out
            </button>
          </>
        ) : (
          <>
            <Link to="/login" className="btn-ghost" style={{ padding: "8px 18px", borderRadius: 9, textDecoration: "none", fontSize: "0.875rem" }}>Login</Link>
            <Link to="/signup" className="btn-primary" style={{ padding: "8px 20px", borderRadius: 9, textDecoration: "none", fontSize: "0.875rem" }}>
              <span style={{ position: "relative", zIndex: 1 }}>Get Started</span>
            </Link>
          </>
        )}
      </div>
    </nav>
  );
}
