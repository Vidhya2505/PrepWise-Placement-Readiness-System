import { useState, type ReactNode } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import {
  LayoutDashboard, Mic, FileText, Target, User,
  Brain, ChevronLeft, LogOut, Sun, Moon, Menu, Sparkles, Award
} from "lucide-react";
import { useAuth } from "../../context/AuthContext";
import { useTheme } from "../../context/ThemeContext";

const NAV = [
  { path: "/dashboard", icon: LayoutDashboard, label: "Dashboard" },
  { path: "/mock",      icon: Mic,             label: "Mock Interview" },
  { path: "/resume",    icon: FileText,         label: "Resume Analyzer" },
  { path: "/skill",     icon: Target,           label: "Skill Gap" },
  { path: "/profile",   icon: User,             label: "Profile" },
  { path: "/portfolio",     icon: Sparkles,   label: "Portfolio" },
  { path: "/career-report", icon: Award,      label: "Career Report" },
];

export default function AppLayout({ children }: { children: ReactNode }) {
  const [collapsed, setCollapsed] = useState(false);
  const { pathname } = useLocation();
  const { user, logout } = useAuth();
  const { theme, toggle } = useTheme();
  const navigate = useNavigate();

  const W = collapsed ? 64 : 200;

  return (
    <div style={{ display: "flex", minHeight: "100vh", background: "var(--bg-primary)" }}>
      {/* Sidebar */}
      <aside style={{ width: W, flexShrink: 0, background: "var(--bg-secondary)", borderRight: "1px solid var(--border)", display: "flex", flexDirection: "column", transition: "width 0.22s ease", position: "sticky", top: 0, height: "100vh", overflow: "hidden" }}>
        {/* Logo */}
        <div style={{ padding: collapsed ? "18px 16px" : "18px 16px", borderBottom: "1px solid var(--border)", display: "flex", alignItems: "center", gap: 9, justifyContent: collapsed ? "center" : "space-between" }}>
          {!collapsed && (
            <Link to="/" style={{ display: "flex", alignItems: "center", gap: 8, textDecoration: "none", overflow: "hidden" }}>
              <div style={{ width: 30, height: 30, borderRadius: 8, background: "linear-gradient(135deg,var(--accent-blue),var(--accent-cyan))", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
                <Brain size={15} color="white" />
              </div>
              <span style={{ fontFamily: "Syne,sans-serif", fontWeight: 800, fontSize: "0.95rem", color: "var(--text-primary)", whiteSpace: "nowrap" }}>
                Prep<span style={{ color: "var(--accent-blue)" }}>Wise</span>
              </span>
            </Link>
          )}
          {collapsed && (
            <div style={{ width: 30, height: 30, borderRadius: 8, background: "linear-gradient(135deg,var(--accent-blue),var(--accent-cyan))", display: "flex", alignItems: "center", justifyContent: "center" }}>
              <Brain size={15} color="white" />
            </div>
          )}
          <button onClick={() => setCollapsed(c => !c)} style={{ background: "none", border: "none", cursor: "pointer", color: "var(--text-muted)", display: "flex", padding: 4, borderRadius: 6, flexShrink: 0 }}>
            {collapsed ? <Menu size={16} /> : <ChevronLeft size={16} />}
          </button>
        </div>

        {/* Nav */}
        <nav style={{ flex: 1, padding: "12px 8px", overflowY: "auto" }}>
          {!collapsed && <div style={{ fontSize: "0.62rem", fontWeight: 700, color: "var(--text-muted)", textTransform: "uppercase", letterSpacing: "0.08em", padding: "0 8px 8px" }}>Main</div>}
          {NAV.map(({ path, icon: Icon, label }) => {
            const active = pathname === path;
            return (
              <Link key={path} to={path} title={collapsed ? label : undefined} style={{
                display: "flex", alignItems: "center", gap: collapsed ? 0 : 10,
                padding: collapsed ? "10px" : "9px 12px",
                justifyContent: collapsed ? "center" : "flex-start",
                borderRadius: 9, marginBottom: 2, textDecoration: "none",
                background: active ? "var(--glow-blue)" : "transparent",
                border: active ? "1px solid var(--border-strong)" : "1px solid transparent",
                color: active ? "var(--accent-blue)" : "var(--text-secondary)",
                transition: "all 0.18s",
              }}
                onMouseEnter={e => { if (!active) { (e.currentTarget as HTMLElement).style.background = "var(--bg-card)"; (e.currentTarget as HTMLElement).style.color = "var(--text-primary)"; } }}
                onMouseLeave={e => { if (!active) { (e.currentTarget as HTMLElement).style.background = "transparent"; (e.currentTarget as HTMLElement).style.color = "var(--text-secondary)"; } }}
              >
                <Icon size={16} style={{ flexShrink: 0 }} />
                {!collapsed && <span style={{ fontWeight: active ? 700 : 500, fontSize: "0.875rem", whiteSpace: "nowrap" }}>{label}</span>}
                {active && !collapsed && <div style={{ marginLeft: "auto", width: 5, height: 5, borderRadius: "50%", background: "var(--accent-blue)" }} />}
              </Link>
            );
          })}
        </nav>

        {/* Bottom */}
        <div style={{ padding: "8px", borderTop: "1px solid var(--border)" }}>
          <button onClick={toggle} title={collapsed ? "Toggle theme" : undefined} style={{
            width: "100%", display: "flex", alignItems: "center", gap: collapsed ? 0 : 10,
            justifyContent: collapsed ? "center" : "flex-start",
            padding: collapsed ? "9px" : "9px 12px", borderRadius: 9, cursor: "pointer",
            background: "none", border: "1px solid transparent", color: "var(--text-muted)",
            fontSize: "0.85rem", transition: "all 0.18s", marginBottom: 2,
          }}>
            {theme === "dark" ? <Sun size={15} /> : <Moon size={15} />}
            {!collapsed && <span>{theme === "dark" ? "Light Mode" : "Dark Mode"}</span>}
          </button>

          {user && (
            <>
              {!collapsed && (
                <div style={{ padding: "8px 10px", borderRadius: 9, background: "var(--bg-card)", border: "1px solid var(--border)", marginBottom: 4 }}>
                  <div style={{ fontWeight: 700, fontSize: "0.82rem", color: "var(--text-primary)", marginBottom: 1, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{user.name}</div>
                  <div style={{ fontSize: "0.7rem", color: "var(--text-muted)", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{user.email}</div>
                </div>
              )}
              <button onClick={() => { logout(); navigate("/"); }} title={collapsed ? "Sign Out" : undefined} style={{
                width: "100%", display: "flex", alignItems: "center", gap: collapsed ? 0 : 10,
                justifyContent: collapsed ? "center" : "flex-start",
                padding: collapsed ? "9px" : "9px 12px", borderRadius: 9, cursor: "pointer",
                background: "none", border: "1px solid transparent", color: "#ef4444",
                fontSize: "0.85rem", transition: "all 0.18s",
              }}>
                <LogOut size={15} />
                {!collapsed && <span>Sign Out</span>}
              </button>
            </>
          )}
        </div>
      </aside>

      {/* Main content */}
      <main style={{ flex: 1, minWidth: 0, padding: "32px 28px", overflowY: "auto" }}>
        {children}
      </main>
    </div>
  );
}
