import { createContext, useContext, useState, useEffect, type ReactNode } from "react";

export interface User {
  id: string; name: string; email: string;
  targetRole?: string; experience?: string; companyType?: string;
  college?: string; graduationYear?: string; skills?: string[];
  resumeData?: { skills: string[]; projects: { name: string; tech: string[]; description: string }[]; experienceLevel: string; education: string; };
}

interface AuthCtx { user: User | null; loading: boolean; setUser: (u: User | null) => void; logout: () => void; }
const AuthContext = createContext<AuthCtx>({ user: null, loading: true, setUser: () => {}, logout: () => {} });

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser]     = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetch_ = async () => {
      const token = localStorage.getItem("token");
      if (!token) { setLoading(false); return; }
      try {
        const res = await fetch("/auth/me", { headers: { Authorization: `Bearer ${token}` } });
        if (!res.ok) throw new Error();
        const data = await res.json();
        setUser({ id: data._id, ...data });
      } catch {
        localStorage.removeItem("token");
      } finally { setLoading(false); }
    };
    fetch_();
  }, []);

  const logout = () => { localStorage.removeItem("token"); setUser(null); };

  return (
    <AuthContext.Provider value={{ user, loading, setUser, logout }}>
      {children}
    </AuthContext.Provider>
  );
}
export const useAuth = () => useContext(AuthContext);
