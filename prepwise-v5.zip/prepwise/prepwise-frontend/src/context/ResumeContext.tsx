import { createContext, useContext, useState, type ReactNode } from "react";

export interface ResumeData {
  skills: string[];
  projects: { name: string; tech: string[]; description: string }[];
  experienceLevel: "fresher" | "junior" | "mid" | "senior";
  education?: string;
}

interface ResumeCtx { resumeData: ResumeData | null; setResumeData: (d: ResumeData, raw?: string) => void; clearResume: () => void; }
const ResumeContext = createContext<ResumeCtx>({ resumeData: null, setResumeData: () => {}, clearResume: () => {} });

export function ResumeProvider({ children }: { children: ReactNode }) {
  const [resumeData, setData] = useState<ResumeData | null>(null);
  return (
    <ResumeContext.Provider value={{
      resumeData,
      setResumeData: (d) => setData(d),
      clearResume:   () => setData(null),
    }}>
      {children}
    </ResumeContext.Provider>
  );
}
export const useResume = () => useContext(ResumeContext);
