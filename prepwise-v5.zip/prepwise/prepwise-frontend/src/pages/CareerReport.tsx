import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import {
  Award, TrendingUp, Brain, Target, FileText, Mic, Star,
  Download, RefreshCw, CheckCircle, AlertTriangle, ArrowRight,
  Zap, BookOpen, Code, Globe, Lightbulb, BarChart2, Shield,
  ChevronRight, Flame, Clock, Calendar
} from "lucide-react";
import { useAuth } from "../context/AuthContext";
import { useResume } from "../context/ResumeContext";
import { loadJsPDFAndGenerate } from "../services/pdfUtils";

interface ReportData {
  overallScore: number; atsScore: number; interviewAvg: number; readiness: number;
  strengths: string[]; weaknesses: string[];
  actionPlan: { priority: "high"|"medium"|"low"; action: string; timeframe: string }[];
  careerRoles: { role: string; match: number; reason: string; salaryRange: string }[];
  learningRoadmap: { phase: number; title: string; duration: string; topics: string[]; resources: string[] }[];
  certifications: { name: string; provider: string; priority: "high"|"medium"; relevance: string }[];
  projectIdeas: { title: string; tech: string[]; impact: string; complexity: "beginner"|"intermediate"|"advanced" }[];
  portfolioContent: { section: string; content: string }[];
  weeklyPlan: { day: string; tasks: string[] }[];
  nextSteps: string[];
  candidateName?: string; targetRole?: string; generatedAt?: string;
}

const ScoreRing = ({ score, size = 100, label = "/100", color }: { score: number; size?: number; label?: string; color?: string }) => {
  const r = size * 0.38; const c = 2 * Math.PI * r; const d = (score / 100) * c;
  const col = color || (score >= 75 ? "var(--accent-green)" : score >= 50 ? "#f59e0b" : "#ef4444");
  const cx = size / 2;
  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
      <circle cx={cx} cy={cx} r={r} fill="none" stroke="var(--border)" strokeWidth={size * 0.07} />
      <circle cx={cx} cy={cx} r={r} fill="none" stroke={col} strokeWidth={size * 0.07} strokeLinecap="round"
        strokeDasharray={`${d} ${c - d}`} strokeDashoffset={c / 4} style={{ transition: "stroke-dasharray 1.2s ease" }} />
      <text x={cx} y={cx - 4} textAnchor="middle" fontFamily="Syne" fontWeight={800} fontSize={size * 0.18} fill="var(--text-primary)">{score}</text>
      <text x={cx} y={cx + size * 0.13} textAnchor="middle" fontSize={size * 0.09} fill="var(--text-muted)">{label}</text>
    </svg>
  );
};

const PBadge = ({ p }: { p: "high"|"medium"|"low" }) => {
  const m = { high:{label:"High",color:"#ef4444",bg:"rgba(239,68,68,0.08)",border:"rgba(239,68,68,0.2)"}, medium:{label:"Med",color:"#f59e0b",bg:"rgba(245,158,11,0.08)",border:"rgba(245,158,11,0.2)"}, low:{label:"Low",color:"var(--accent-blue)",bg:"var(--glow-blue)",border:"var(--border-strong)"} }[p];
  return <span style={{ padding:"2px 8px",borderRadius:100,fontSize:"0.62rem",fontWeight:800,background:m.bg,border:`1px solid ${m.border}`,color:m.color,textTransform:"uppercase",letterSpacing:"0.04em",flexShrink:0 }}>{m.label}</span>;
};
const Skel = ({ w="100%",h=14,r=5 }: { w?: string|number; h?: number; r?: number }) => <div className="skeleton" style={{ width:w,height:h,borderRadius:r }} />;

export default function CareerReport() {
  const { user } = useAuth();
  const { resumeData } = useResume();
  const [report, setReport] = useState<ReportData | null>(null);
  const [loading, setLoading] = useState(false);
  const [downloading, setDownloading] = useState(false);
  const [tab, setTab] = useState<"overview"|"roadmap"|"projects"|"portfolio"|"plan">("overview");
  const [stats, setStats] = useState({ total: 0, avgScore: 0, readiness: 0 });
  const [generated, setGenerated] = useState(false);

  useEffect(() => {
    const load = async () => {
      try {
        const token = localStorage.getItem("token");
        const res = await fetch("/interview/stats", { headers: { Authorization: `Bearer ${token}` } });
        if (res.ok) { const d = await res.json(); setStats({ total: d.total||0, avgScore: d.avgScore||0, readiness: d.readiness||0 }); }
      } catch { /* keep defaults */ }
    };
    load();
  }, []);

  const generateReport = async () => {
    setLoading(true);
    try {
      const token = localStorage.getItem("token");
      const res = await fetch("/career/report", {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
        body: JSON.stringify({ resumeData, stats, targetRole: user?.targetRole || "Software Developer", experience: user?.experience || "Fresher", skills: user?.skills || [] }),
      });
      if (!res.ok) throw new Error("Failed");
      const data = await res.json();
      setReport(data); setGenerated(true);
    } catch {
      setReport(getFallbackReport(user?.name, user?.targetRole));
      setGenerated(true);
    } finally { setLoading(false); }
  };

  const downloadReport = async () => {
    if (!report) return;
    setDownloading(true);
    try {
      await loadJsPDFAndGenerate(report, user?.name || "Candidate", stats);
    } catch (e) { console.error("PDF error:", e); }
    finally { setDownloading(false); }
  };

  const tabs = [
    { id: "overview" as const, label: "Overview",        icon: <BarChart2 size={12}/> },
    { id: "roadmap"  as const, label: "Learning Roadmap", icon: <BookOpen size={12}/> },
    { id: "projects" as const, label: "Project Ideas",    icon: <Code size={12}/> },
    { id: "portfolio"as const, label: "Portfolio",        icon: <Globe size={12}/> },
    { id: "plan"     as const, label: "Weekly Plan",      icon: <Calendar size={12}/> },
  ];
  const sc = (v: number) => v >= 75 ? "var(--accent-green)" : v >= 50 ? "#f59e0b" : "#ef4444";

  return (
    <div style={{ maxWidth: 960, margin: "0 auto" }}>
      <style>{`@keyframes spin{from{transform:rotate(0deg)}to{transform:rotate(360deg)}}`}</style>
      <div style={{ marginBottom: 22 }}>
        <div className="tag" style={{ display:"inline-flex",alignItems:"center",gap:6,borderRadius:100,padding:"5px 14px",marginBottom:10,fontSize:"0.75rem" }}><Award size={11}/> Career Intelligence</div>
        <h1 style={{ fontFamily:"Syne,sans-serif",fontWeight:800,fontSize:"clamp(1.7rem,3vw,2.1rem)",letterSpacing:"-0.03em",color:"var(--text-primary)",marginBottom:7 }}>
          Final <span className="gradient-text">Performance Report</span>
        </h1>
        <p style={{ color:"var(--text-secondary)",fontSize:"0.9rem" }}>Complete career intelligence — ATS analysis, interview performance, skill gaps, role recommendations & prep strategy.</p>
      </div>

      {/* Stats snapshot */}
      <div style={{ display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(180px,1fr))",gap:12,marginBottom:18 }}>
        {[
          { label:"Interview Sessions", value:String(stats.total),  icon:Mic,      color:"var(--accent-blue)",   sub:stats.total===0?"No sessions yet":"completed" },
          { label:"Avg Interview Score", value:stats.avgScore>0?String(stats.avgScore):"—", icon:TrendingUp, color:sc(stats.avgScore), sub:"across all rounds" },
          { label:"Readiness Score",     value:String(stats.readiness), icon:Target,   color:sc(stats.readiness), sub:"out of 100" },
          { label:"Resume Analyzed",     value:resumeData?"Yes ✓":"No", icon:FileText, color:resumeData?"var(--accent-green)":"#f59e0b", sub:resumeData?"Profile saved":"Upload resume first" },
        ].map(s => (
          <div key={s.label} className="card" style={{ borderRadius:12,padding:"14px 16px" }}>
            <div style={{ width:32,height:32,borderRadius:8,background:`${s.color}18`,border:`1px solid ${s.color}30`,display:"flex",alignItems:"center",justifyContent:"center",marginBottom:9 }}><s.icon size={14} color={s.color}/></div>
            <div style={{ fontFamily:"Syne,sans-serif",fontWeight:800,fontSize:"1.5rem",color:"var(--text-primary)",lineHeight:1,marginBottom:2 }}>{s.value}</div>
            <div style={{ fontWeight:600,fontSize:"0.76rem",color:"var(--text-primary)",marginBottom:1 }}>{s.label}</div>
            <div style={{ fontSize:"0.66rem",color:"var(--text-muted)" }}>{s.sub}</div>
          </div>
        ))}
      </div>

      {!generated ? (
        <div className="card" style={{ borderRadius:16,padding:"56px 36px",textAlign:"center" }}>
          <div style={{ width:66,height:66,borderRadius:"50%",background:"var(--glow-blue)",border:"1px solid var(--border-strong)",display:"flex",alignItems:"center",justifyContent:"center",margin:"0 auto 20px" }}>
            <Brain size={28} color="var(--accent-blue)"/>
          </div>
          <h3 style={{ fontFamily:"Syne,sans-serif",fontWeight:700,fontSize:"1.15rem",color:"var(--text-primary)",marginBottom:8 }}>Generate Your Career Intelligence Report</h3>
          <p style={{ color:"var(--text-secondary)",fontSize:"0.88rem",lineHeight:1.7,maxWidth:440,margin:"0 auto 28px" }}>
            AI synthesizes your resume, interview performance, and skill profile into one complete career plan — role recommendations, learning roadmap, project ideas, and a weekly schedule.
          </p>
          <div style={{ display:"flex",gap:10,justifyContent:"center",flexWrap:"wrap",marginBottom:24 }}>
            {["Career Role Match","Skill Roadmap","Project Suggestions","Portfolio Content","Weekly Study Plan","PDF Download"].map(f => (
              <div key={f} style={{ display:"flex",alignItems:"center",gap:5,fontSize:"0.76rem",color:"var(--text-muted)" }}>
                <CheckCircle size={11} color="var(--accent-green)"/> {f}
              </div>
            ))}
          </div>
          {stats.total === 0 && !resumeData && (
            <div style={{ padding:"10px 14px",borderRadius:9,background:"rgba(245,158,11,0.07)",border:"1px solid rgba(245,158,11,0.2)",fontSize:"0.78rem",color:"#f59e0b",marginBottom:20,maxWidth:400,margin:"0 auto 20px",textAlign:"left" }}>
              💡 For the most accurate report, first <Link to="/resume" style={{ color:"var(--accent-blue)",fontWeight:700 }}>analyze your resume</Link> and complete at least one <Link to="/mock" style={{ color:"var(--accent-blue)",fontWeight:700 }}>mock interview</Link>.
            </div>
          )}
          <button onClick={generateReport} disabled={loading} className="btn-primary" style={{ padding:"11px 30px",borderRadius:10,fontSize:"0.9rem" }}>
            <span style={{ position:"relative",zIndex:1,display:"flex",alignItems:"center",gap:8 }}>
              {loading ? <><RefreshCw size={14} style={{ animation:"spin 1s linear infinite" }}/> Generating…</> : <><Zap size={14}/> Generate Full Report</>}
            </span>
          </button>
        </div>
      ) : loading ? (
        <div className="card" style={{ borderRadius:16,padding:"56px 36px",textAlign:"center" }}>
          <div style={{ width:60,height:60,borderRadius:"50%",border:"3px solid var(--border)",borderTopColor:"var(--accent-blue)",animation:"spin 0.8s linear infinite",margin:"0 auto 22px" }}/>
          <p style={{ color:"var(--text-secondary)",fontSize:"0.88rem" }}>Building your personalized career intelligence report…</p>
        </div>
      ) : report && (
        <div style={{ display:"flex",flexDirection:"column",gap:14 }}>
          {/* Score Hero */}
          <div className="card" style={{ borderRadius:16,padding:"22px 26px" }}>
            <div style={{ display:"flex",gap:20,alignItems:"center",flexWrap:"wrap" }}>
              <div style={{ display:"flex",flexDirection:"column",alignItems:"center",gap:4 }}>
                <ScoreRing score={report.overallScore} size={110} label="Overall"/>
                <div style={{ fontSize:"0.65rem",fontWeight:700,color:"var(--text-muted)",textTransform:"uppercase",letterSpacing:"0.06em" }}>Career Readiness</div>
              </div>
              <div style={{ display:"flex",gap:14 }}>
                <div style={{ display:"flex",flexDirection:"column",alignItems:"center",gap:3 }}>
                  <ScoreRing score={report.atsScore} size={72} label="ATS" color="var(--accent-blue)"/>
                  <div style={{ fontSize:"0.6rem",color:"var(--text-muted)" }}>Resume</div>
                </div>
                <div style={{ display:"flex",flexDirection:"column",alignItems:"center",gap:3 }}>
                  <ScoreRing score={report.interviewAvg} size={72} label="Avg" color="var(--accent-cyan)"/>
                  <div style={{ fontSize:"0.6rem",color:"var(--text-muted)" }}>Interview</div>
                </div>
              </div>
              <div style={{ flex:1,minWidth:200 }}>
                <div style={{ fontFamily:"Syne,sans-serif",fontWeight:800,fontSize:"1.1rem",color:"var(--text-primary)",marginBottom:6 }}>
                  {report.overallScore >= 80 ? "Excellent — Interview Ready! 🚀" : report.overallScore >= 60 ? "Good Progress — Keep Pushing 💪" : "Building Up — Stay Consistent 📈"}
                </div>
                <div style={{ display:"flex",gap:8,marginBottom:10,flexWrap:"wrap" }}>
                  {report.strengths.slice(0,2).map((s,i) => (
                    <span key={i} style={{ padding:"3px 9px",borderRadius:100,fontSize:"0.72rem",fontWeight:600,background:"rgba(0,229,160,0.08)",border:"1px solid rgba(0,229,160,0.2)",color:"var(--accent-green)" }}>✓ {s}</span>
                  ))}
                </div>
                <p style={{ fontSize:"0.78rem",color:"var(--text-secondary)",lineHeight:1.6 }}>
                  {stats.total} sessions · {report.careerRoles.length} matching roles · {report.actionPlan.filter(a=>a.priority==="high").length} high-priority actions
                  {report.generatedAt && <span style={{ color:"var(--text-muted)" }}> · Generated {new Date(report.generatedAt).toLocaleDateString()}</span>}
                </p>
              </div>
              <div style={{ display:"flex",flexDirection:"column",gap:7 }}>
                <button onClick={downloadReport} disabled={downloading} className="btn-primary" style={{ padding:"8px 14px",borderRadius:8,fontSize:"0.78rem",display:"flex",alignItems:"center",gap:5 }}>
                  <span style={{ position:"relative",zIndex:1,display:"flex",alignItems:"center",gap:5 }}>
                    {downloading ? <RefreshCw size={12} style={{ animation:"spin 0.8s linear infinite" }}/> : <Download size={12}/>}
                    {downloading ? "Generating PDF…" : "Download PDF"}
                  </span>
                </button>
                <button onClick={generateReport} className="btn-ghost" style={{ padding:"8px 14px",borderRadius:8,fontSize:"0.78rem",display:"flex",alignItems:"center",gap:5 }}>
                  <RefreshCw size={12}/> Refresh
                </button>
              </div>
            </div>
          </div>

          {/* Tabs */}
          <div style={{ display:"flex",gap:5,overflowX:"auto",paddingBottom:3 }}>
            {tabs.map(t => (
              <button key={t.id} onClick={()=>setTab(t.id)} style={{ display:"flex",alignItems:"center",gap:5,padding:"7px 13px",borderRadius:8,cursor:"pointer",fontWeight:600,fontSize:"0.78rem",whiteSpace:"nowrap",flexShrink:0, border:`1px solid ${tab===t.id?"var(--accent-blue)":"var(--border)"}`, background:tab===t.id?"var(--glow-blue)":"var(--bg-primary)", color:tab===t.id?"var(--accent-blue)":"var(--text-muted)", transition:"all 0.18s" }}>
                {t.icon} {t.label}
              </button>
            ))}
          </div>

          {/* OVERVIEW */}
          {tab === "overview" && (
            <div style={{ display:"flex",flexDirection:"column",gap:12 }}>
              <div className="card" style={{ borderRadius:13,padding:"16px 18px" }}>
                <div style={{ fontFamily:"Syne,sans-serif",fontWeight:700,fontSize:"0.85rem",color:"var(--text-primary)",marginBottom:5,display:"flex",alignItems:"center",gap:6 }}><Target size={13} color="var(--accent-blue)"/> Career Role Recommendations</div>
                <p style={{ fontSize:"0.75rem",color:"var(--text-muted)",marginBottom:12 }}>Roles matched to your resume and interview performance.</p>
                {report.careerRoles.map((role,i) => (
                  <div key={i} style={{ padding:"12px 14px",borderRadius:9,background:"var(--bg-primary)",border:"1px solid var(--border)",marginBottom:8,display:"flex",gap:12,alignItems:"flex-start" }}>
                    <div style={{ minWidth:44,textAlign:"center" }}>
                      <div style={{ fontFamily:"Syne,sans-serif",fontWeight:800,fontSize:"1.2rem",color:sc(role.match) }}>{role.match}%</div>
                      <div style={{ fontSize:"0.6rem",color:"var(--text-muted)" }}>match</div>
                    </div>
                    <div style={{ flex:1 }}>
                      <div style={{ fontWeight:700,fontSize:"0.85rem",color:"var(--text-primary)",marginBottom:3 }}>{role.role}</div>
                      <div style={{ fontSize:"0.75rem",color:"var(--text-secondary)",lineHeight:1.5,marginBottom:4 }}>{role.reason}</div>
                      <span style={{ fontSize:"0.68rem",padding:"2px 8px",borderRadius:100,background:"rgba(0,229,160,0.07)",border:"1px solid rgba(0,229,160,0.2)",color:"var(--accent-green)",fontWeight:600 }}>💰 {role.salaryRange}</span>
                    </div>
                    <div style={{ width:60,height:4,borderRadius:2,background:"var(--border)",overflow:"hidden",alignSelf:"center" }}>
                      <div style={{ width:`${role.match}%`,height:"100%",background:sc(role.match),borderRadius:2 }}/>
                    </div>
                  </div>
                ))}
              </div>

              <div style={{ display:"grid",gridTemplateColumns:"1fr 1fr",gap:12 }}>
                <div className="card" style={{ borderRadius:13,padding:"14px 16px" }}>
                  <div style={{ fontFamily:"Syne,sans-serif",fontWeight:700,fontSize:"0.82rem",color:"var(--text-primary)",marginBottom:10,display:"flex",alignItems:"center",gap:6 }}><Star size={12} color="var(--accent-green)"/> Strengths</div>
                  {report.strengths.map((s,i) => <div key={i} style={{ display:"flex",gap:7,marginBottom:7,alignItems:"flex-start" }}><CheckCircle size={11} color="var(--accent-green)" style={{flexShrink:0,marginTop:2}}/><span style={{fontSize:"0.77rem",color:"var(--text-secondary)",lineHeight:1.5}}>{s}</span></div>)}
                </div>
                <div className="card" style={{ borderRadius:13,padding:"14px 16px" }}>
                  <div style={{ fontFamily:"Syne,sans-serif",fontWeight:700,fontSize:"0.82rem",color:"var(--text-primary)",marginBottom:10,display:"flex",alignItems:"center",gap:6 }}><AlertTriangle size={12} color="#f59e0b"/> Areas to Improve</div>
                  {report.weaknesses.map((w,i) => <div key={i} style={{ display:"flex",gap:7,marginBottom:7,alignItems:"flex-start" }}><ArrowRight size={10} color="#f59e0b" style={{flexShrink:0,marginTop:3}}/><span style={{fontSize:"0.77rem",color:"var(--text-secondary)",lineHeight:1.5}}>{w}</span></div>)}
                </div>
              </div>

              <div className="card" style={{ borderRadius:13,padding:"14px 16px" }}>
                <div style={{ fontFamily:"Syne,sans-serif",fontWeight:700,fontSize:"0.82rem",color:"var(--text-primary)",marginBottom:5,display:"flex",alignItems:"center",gap:6 }}><Award size={12} color="var(--accent-purple)"/> Recommended Certifications</div>
                <div style={{ display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(200px,1fr))",gap:8,marginTop:10 }}>
                  {report.certifications.map((cert,i) => (
                    <div key={i} style={{ padding:"10px 12px",borderRadius:9,background:"var(--bg-primary)",border:`1px solid ${cert.priority==="high"?"rgba(239,68,68,0.2)":"var(--border)"}` }}>
                      <div style={{ fontWeight:700,fontSize:"0.78rem",color:"var(--text-primary)",marginBottom:3 }}>{cert.name}</div>
                      <div style={{ fontSize:"0.68rem",color:"var(--text-muted)",marginBottom:5 }}>by {cert.provider}</div>
                      <div style={{ display:"flex",alignItems:"center",justifyContent:"space-between" }}>
                        <span style={{ fontSize:"0.68rem",color:"var(--text-secondary)" }}>{cert.relevance}</span>
                        <span style={{ fontSize:"0.6rem",padding:"1px 6px",borderRadius:100,fontWeight:700,background:cert.priority==="high"?"rgba(239,68,68,0.08)":"rgba(245,158,11,0.08)",color:cert.priority==="high"?"#ef4444":"#f59e0b" }}>{cert.priority}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="card" style={{ borderRadius:13,padding:"14px 16px",background:"linear-gradient(135deg,rgba(59,142,255,0.06),rgba(0,229,160,0.04))",border:"1px solid rgba(59,142,255,0.2)" }}>
                <div style={{ fontFamily:"Syne,sans-serif",fontWeight:700,fontSize:"0.82rem",color:"var(--text-primary)",marginBottom:10,display:"flex",alignItems:"center",gap:6 }}><Flame size={12} color="#f59e0b"/> Immediate Next Steps</div>
                {report.nextSteps.map((step,i) => (
                  <div key={i} style={{ display:"flex",gap:10,marginBottom:8,alignItems:"flex-start" }}>
                    <div style={{ width:22,height:22,borderRadius:6,background:"var(--glow-blue)",border:"1px solid var(--border-strong)",display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0,fontSize:"0.65rem",fontWeight:800,color:"var(--accent-blue)" }}>{i+1}</div>
                    <span style={{ fontSize:"0.78rem",color:"var(--text-secondary)",lineHeight:1.55 }}>{step}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* ROADMAP */}
          {tab === "roadmap" && (
            <div style={{ display:"flex",flexDirection:"column",gap:12 }}>
              <div style={{ padding:"10px 14px",borderRadius:9,background:"rgba(59,142,255,0.06)",border:"1px solid rgba(59,142,255,0.15)",fontSize:"0.78rem",color:"var(--text-secondary)",display:"flex",gap:7,alignItems:"center" }}>
                <Lightbulb size={13} color="var(--accent-blue)" style={{flexShrink:0}}/> Personalized learning roadmap based on your skill gaps and target role.
              </div>
              {report.learningRoadmap.map((phase,i) => (
                <div key={i} className="card" style={{ borderRadius:13,padding:"16px 18px" }}>
                  <div style={{ display:"flex",alignItems:"flex-start",gap:12 }}>
                    <div style={{ width:36,height:36,borderRadius:9,background:"linear-gradient(135deg,var(--accent-blue),var(--accent-cyan))",display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0,fontFamily:"Syne,sans-serif",fontWeight:800,fontSize:"0.9rem",color:"#fff" }}>{phase.phase}</div>
                    <div style={{ flex:1 }}>
                      <div style={{ display:"flex",alignItems:"center",gap:8,marginBottom:4 }}>
                        <div style={{ fontFamily:"Syne,sans-serif",fontWeight:700,fontSize:"0.9rem",color:"var(--text-primary)" }}>{phase.title}</div>
                        <span style={{ fontSize:"0.68rem",padding:"2px 8px",borderRadius:100,background:"var(--glow-blue)",border:"1px solid var(--border-strong)",color:"var(--accent-blue)",fontWeight:600,display:"flex",alignItems:"center",gap:4 }}><Clock size={9}/> {phase.duration}</span>
                      </div>
                      <div style={{ display:"flex",flexWrap:"wrap",gap:5,marginBottom:10 }}>
                        {phase.topics.map((t,j) => <span key={j} style={{ padding:"3px 9px",borderRadius:100,fontSize:"0.71rem",fontWeight:600,background:"var(--bg-primary)",border:"1px solid var(--border)",color:"var(--text-secondary)" }}>{t}</span>)}
                      </div>
                      <div style={{ fontSize:"0.65rem",fontWeight:700,color:"var(--text-muted)",marginBottom:5,textTransform:"uppercase",letterSpacing:"0.05em" }}>Resources</div>
                      {phase.resources.map((r,j) => <div key={j} style={{ display:"flex",gap:6,marginBottom:4,alignItems:"flex-start" }}><ChevronRight size={10} color="var(--accent-green)" style={{flexShrink:0,marginTop:2}}/><span style={{fontSize:"0.75rem",color:"var(--text-secondary)"}}>{r}</span></div>)}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* PROJECTS */}
          {tab === "projects" && (
            <div style={{ display:"flex",flexDirection:"column",gap:11 }}>
              <div style={{ padding:"10px 14px",borderRadius:9,background:"rgba(0,229,160,0.05)",border:"1px solid rgba(0,229,160,0.15)",fontSize:"0.78rem",color:"var(--text-secondary)",display:"flex",gap:7,alignItems:"center" }}>
                <Code size={13} color="var(--accent-green)" style={{flexShrink:0}}/> Build these projects to demonstrate skills and strengthen your resume.
              </div>
              {report.projectIdeas.map((project,i) => {
                const cc = project.complexity==="beginner"?"var(--accent-green)":project.complexity==="intermediate"?"#f59e0b":"#ef4444";
                return (
                  <div key={i} className="card" style={{ borderRadius:13,padding:"16px 18px" }}>
                    <div style={{ display:"flex",alignItems:"flex-start",justifyContent:"space-between",gap:10,marginBottom:8 }}>
                      <div style={{ fontFamily:"Syne,sans-serif",fontWeight:700,fontSize:"0.9rem",color:"var(--text-primary)" }}>{project.title}</div>
                      <span style={{ padding:"3px 9px",borderRadius:100,fontSize:"0.65rem",fontWeight:700,background:`${cc}15`,color:cc,border:`1px solid ${cc}30`,textTransform:"capitalize",flexShrink:0 }}>{project.complexity}</span>
                    </div>
                    <p style={{ fontSize:"0.78rem",color:"var(--text-secondary)",lineHeight:1.6,marginBottom:10 }}>{project.impact}</p>
                    <div style={{ display:"flex",flexWrap:"wrap",gap:5 }}>
                      {project.tech.map((t,j) => <span key={j} style={{ padding:"3px 9px",borderRadius:100,fontSize:"0.71rem",fontWeight:600,background:"var(--glow-blue)",border:"1px solid var(--border-strong)",color:"var(--accent-blue)" }}>{t}</span>)}
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {/* PORTFOLIO */}
          {tab === "portfolio" && (
            <div style={{ display:"flex",flexDirection:"column",gap:11 }}>
              <div style={{ padding:"10px 14px",borderRadius:9,background:"rgba(139,92,246,0.06)",border:"1px solid rgba(139,92,246,0.18)",fontSize:"0.78rem",color:"var(--text-secondary)",display:"flex",gap:7,alignItems:"center" }}>
                <Globe size={13} color="var(--accent-purple)" style={{flexShrink:0}}/> Portfolio-ready content derived from your resume. Copy directly to your website or GitHub.
              </div>
              {report.portfolioContent.map((item,i) => (
                <div key={i} className="card" style={{ borderRadius:13,padding:"16px 18px" }}>
                  <div style={{ fontSize:"0.7rem",fontWeight:700,color:"var(--accent-purple)",textTransform:"uppercase",letterSpacing:"0.06em",marginBottom:8 }}>{item.section}</div>
                  <div style={{ fontSize:"0.82rem",color:"var(--text-secondary)",lineHeight:1.7,whiteSpace:"pre-wrap",padding:"10px 12px",borderRadius:8,background:"var(--bg-primary)",border:"1px solid var(--border)" }}>{item.content}</div>
                  <button onClick={()=>navigator.clipboard?.writeText(item.content)} style={{ marginTop:8,padding:"5px 12px",borderRadius:7,border:"1px solid var(--border)",background:"none",cursor:"pointer",fontSize:"0.72rem",color:"var(--text-muted)",fontWeight:600 }}>Copy</button>
                </div>
              ))}
            </div>
          )}

          {/* WEEKLY PLAN */}
          {tab === "plan" && (
            <div style={{ display:"flex",flexDirection:"column",gap:11 }}>
              <div className="card" style={{ borderRadius:13,padding:"14px 16px" }}>
                <div style={{ fontFamily:"Syne,sans-serif",fontWeight:700,fontSize:"0.85rem",color:"var(--text-primary)",marginBottom:5,display:"flex",alignItems:"center",gap:6 }}><Calendar size={13} color="var(--accent-cyan)"/> Your Weekly Preparation Plan</div>
                <p style={{ fontSize:"0.75rem",color:"var(--text-muted)",marginBottom:14 }}>Structured daily schedule to build momentum and consistency.</p>
                <div style={{ display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(200px,1fr))",gap:9 }}>
                  {report.weeklyPlan.map((day,i) => (
                    <div key={i} style={{ padding:"12px 13px",borderRadius:9,background:"var(--bg-primary)",border:"1px solid var(--border)" }}>
                      <div style={{ fontFamily:"Syne,sans-serif",fontWeight:700,fontSize:"0.82rem",color:"var(--accent-blue)",marginBottom:8 }}>{day.day}</div>
                      {day.tasks.map((task,j) => (
                        <div key={j} style={{ display:"flex",gap:6,marginBottom:5,alignItems:"flex-start" }}>
                          <div style={{ width:5,height:5,borderRadius:"50%",background:"var(--accent-blue)",flexShrink:0,marginTop:6 }}/>
                          <span style={{ fontSize:"0.73rem",color:"var(--text-secondary)",lineHeight:1.5 }}>{task}</span>
                        </div>
                      ))}
                    </div>
                  ))}
                </div>
              </div>

              <div className="card" style={{ borderRadius:13,padding:"14px 16px" }}>
                <div style={{ fontFamily:"Syne,sans-serif",fontWeight:700,fontSize:"0.82rem",color:"var(--text-primary)",marginBottom:5,display:"flex",alignItems:"center",gap:6 }}><Shield size={12} color="var(--accent-blue)"/> Priority Action Plan</div>
                {(["high","medium","low"] as const).map(level => {
                  const items = report.actionPlan.filter(a=>a.priority===level);
                  if (!items.length) return null;
                  return (
                    <div key={level} style={{ marginBottom:14 }}>
                      <div style={{ display:"flex",alignItems:"center",gap:6,marginBottom:8 }}><PBadge p={level}/><span style={{fontSize:"0.7rem",color:"var(--text-muted)"}}>{items.length} action{items.length>1?"s":""}</span></div>
                      {items.map((item,i) => (
                        <div key={i} style={{ display:"flex",gap:9,padding:"10px 12px",borderRadius:8,background:"var(--bg-primary)",border:`1px solid ${level==="high"?"rgba(239,68,68,0.15)":level==="medium"?"rgba(245,158,11,0.15)":"var(--border)"}`,marginBottom:7,alignItems:"flex-start" }}>
                          <div style={{ flex:1 }}><div style={{fontSize:"0.78rem",color:"var(--text-secondary)",lineHeight:1.55}}>{item.action}</div></div>
                          <span style={{ fontSize:"0.65rem",color:"var(--text-muted)",whiteSpace:"nowrap",flexShrink:0,padding:"2px 7px",borderRadius:100,background:"var(--bg-primary)",border:"1px solid var(--border)",display:"flex",alignItems:"center",gap:3 }}><Clock size={8}/>{item.timeframe}</span>
                        </div>
                      ))}
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Quick Links */}
          <div style={{ display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:9 }}>
            {[
              { to:"/mock",      icon:Mic,      label:"Start Mock Interview", color:"var(--accent-blue)" },
              { to:"/resume",    icon:FileText,  label:"Analyze Resume",       color:"var(--accent-purple)" },
              { to:"/skill",     icon:Target,    label:"Skill Gap Report",     color:"var(--accent-cyan)" },
            ].map(a => (
              <Link key={a.to} to={a.to} style={{ textDecoration:"none" }}>
                <div style={{ padding:"11px 13px",borderRadius:10,display:"flex",alignItems:"center",gap:9,cursor:"pointer",border:"1px solid var(--border)",background:"var(--bg-card)",transition:"all 0.18s" }}
                  onMouseEnter={e=>{const el=e.currentTarget as HTMLElement;el.style.borderColor=a.color;el.style.background="var(--bg-card-hover)";}}
                  onMouseLeave={e=>{const el=e.currentTarget as HTMLElement;el.style.borderColor="var(--border)";el.style.background="var(--bg-card)";}}>
                  <div style={{ width:30,height:30,borderRadius:7,background:`${a.color}15`,border:`1px solid ${a.color}22`,display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0 }}><a.icon size={14} color={a.color}/></div>
                  <span style={{fontWeight:700,fontSize:"0.78rem",color:"var(--text-primary)"}}>{a.label}</span>
                  <ChevronRight size={12} color="var(--text-muted)" style={{marginLeft:"auto"}}/>
                </div>
              </Link>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function getFallbackReport(name = "Candidate", targetRole = "Software Developer"): ReportData {
  return {
    overallScore:62, atsScore:68, interviewAvg:58, readiness:62,
    strengths:["Strong frontend development skills with React","Good project diversity demonstrating full-stack capability","Clear educational background in Computer Science","Ability to build and deploy end-to-end applications"],
    weaknesses:["Limited system design exposure — high priority for product companies","No quantified achievements in resume — reduces ATS ranking","Cloud and DevOps skills not demonstrated","Database optimization and advanced SQL knowledge gaps"],
    actionPlan:[
      { priority:"high",   action:"Add 3 quantified achievements to resume (metrics boost ATS score 15-20 pts)", timeframe:"This week" },
      { priority:"high",   action:"Complete system design fundamentals — top gap for SDE roles",                  timeframe:"2-3 weeks" },
      { priority:"medium", action:"Practice 5 STAR behavioural answers and record yourself",                       timeframe:"This week" },
      { priority:"medium", action:"Add cloud skills (AWS basics) to technical portfolio",                          timeframe:"1 month" },
      { priority:"low",    action:"Earn AWS Cloud Practitioner certification to signal cloud readiness",            timeframe:"2 months" },
    ],
    careerRoles:[
      { role:"Full Stack Developer",            match:82, reason:"Strong React + Node.js aligns with full-stack JDs. Projects show end-to-end delivery.", salaryRange:"₹6–12 LPA (fresher)" },
      { role:"Frontend Developer",              match:78, reason:"React experience and UI project work make this a natural fit.",                            salaryRange:"₹5–10 LPA (fresher)" },
      { role:"Backend Engineer (Node.js)",      match:65, reason:"Backend and API work is evident but lacks database optimization depth.",                   salaryRange:"₹6–11 LPA (fresher)" },
      { role:"SDE Intern → Full Time",          match:88, reason:"Profile suits internship-to-full-time pipeline at mid-size product companies.",           salaryRange:"₹3–6 LPA (intern)" },
    ],
    learningRoadmap:[
      { phase:1, title:"Core CS Fundamentals", duration:"3 weeks", topics:["DSA — Arrays, Trees, Graphs","OS — Processes, Memory","DBMS — SQL, ACID"], resources:["Striver's DSA Sheet (free)","Gate Smashers OS (YouTube)","TutorialsPoint DBMS"] },
      { phase:2, title:"System Design Basics",  duration:"2 weeks", topics:["Scalability","Load balancing & caching","Microservices overview"], resources:["System Design Primer (GitHub)","Gaurav Sen (YouTube)","ByteByteGo newsletter"] },
      { phase:3, title:"Interview Sprint",      duration:"2 weeks", topics:["LeetCode Medium problems","STAR behavioural answers","Mock interviews daily"], resources:["LeetCode Top 150","STAR method templates","PrepWise Mock Interview"] },
    ],
    certifications:[
      { name:"AWS Cloud Practitioner",             provider:"Amazon Web Services",   priority:"high",   relevance:"Most requested cloud cert for SDE roles" },
      { name:"Meta Frontend Developer Certificate", provider:"Coursera / Meta",        priority:"high",   relevance:"Validates React skills for frontend positions" },
      { name:"MongoDB Developer Certificate",       provider:"MongoDB University",      priority:"medium", relevance:"Free cert, signals NoSQL database depth" },
    ],
    projectIdeas:[
      { title:"Real-Time Collaborative Code Editor", tech:["React","WebSocket","Node.js","Monaco Editor"], impact:"Demonstrates real-time systems and WebSocket expertise. Highly memorable in interviews.", complexity:"intermediate" },
      { title:"Mini E-Commerce with Payment Gateway", tech:["React","Node.js","Stripe API","MongoDB","Redis"], impact:"End-to-end project with payments, cart, and caching — covers multiple interview topics.", complexity:"intermediate" },
      { title:"DSA Visualizer Tool",                  tech:["React","D3.js","TypeScript"],                    impact:"Shows both DSA knowledge and frontend skill. Visually impressive for portfolio.",          complexity:"beginner" },
      { title:"URL Shortener with Analytics",          tech:["Node.js","Redis","PostgreSQL","Express"],         impact:"Classic system design project. Shows caching, database design, and API skills.",           complexity:"beginner" },
    ],
    portfolioContent:[
      { section:"Hero / About",   content:`Full Stack Developer passionate about building scalable web applications. Proficient in React, Node.js, and MongoDB. Currently seeking ${targetRole} roles at product companies.` },
      { section:"Skills Summary", content:"Frontend: React, TypeScript, HTML/CSS, Tailwind\nBackend: Node.js, Express, REST APIs\nDatabases: MongoDB, SQL\nTools: Git, GitHub, VS Code\nLearning: AWS, Docker, System Design" },
      { section:"Project Highlight", content:"PrepWise — AI Placement Platform\n• Built full-stack interview prep platform with AI-powered resume analysis\n• Tech: React + TypeScript, Node.js, MongoDB, Groq AI\n• Features: PDF parsing, real-time scoring, ATS analysis, personalized questions" },
      { section:"GitHub README",  content:`## 👋 Hi, I'm ${name}\n\n🔭 Working on: Full-stack web apps with React & Node.js\n🌱 Learning: AWS, System Design, Docker\n💬 Ask me about: React, Node.js, REST APIs, MongoDB\n\n### 🛠️ Tech Stack\nReact • Node.js • MongoDB • TypeScript` },
    ],
    weeklyPlan:[
      { day:"Monday",    tasks:["Solve 2 LeetCode Easy problems","Read one system design article","15 min PrepWise mock — HR round"] },
      { day:"Tuesday",   tasks:["Deep-dive DSA topic (trees/graphs)","Review OS concepts (1 chapter)","Update resume with new keywords"] },
      { day:"Wednesday", tasks:["Solve 2 LeetCode Medium problems","Watch 1 system design video (30 min)","PrepWise mock — Technical round"] },
      { day:"Thursday",  tasks:["DBMS and CN revision (1 hour)","Practice 3 STAR behavioural answers","Code a mini project feature"] },
      { day:"Friday",    tasks:["LeetCode contest or 3 problems","Resume analyzer check — re-score","PrepWise mock — DSA/Project round"] },
      { day:"Saturday",  tasks:["2-hour system design deep dive","Build / push project to GitHub","Explore 1 new certification module"] },
      { day:"Sunday",    tasks:["Review the week's weak areas","Revise all STAR answers prepared","Plan next week's focus topics"] },
    ],
    nextSteps:[
      "Upload your resume to the Resume Analyzer — get an ATS score and exact keyword gaps to fix",
      "Complete one mock interview in each round (HR, Technical, DSA) to update your skill gap report",
      "Start Phase 1 of the learning roadmap — pick one DSA topic daily for 3 weeks",
      "Build one of the suggested projects and push it to GitHub with a strong README",
      "Begin the AWS Cloud Practitioner course (free tier) — 20 min/day is enough",
    ],
    candidateName: name,
    targetRole,
  };
}
