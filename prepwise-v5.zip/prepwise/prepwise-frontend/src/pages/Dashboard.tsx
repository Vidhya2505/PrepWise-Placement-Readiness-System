import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { Mic, FileText, Target, TrendingUp, Award, Clock, ChevronRight, ArrowUp, Flame, Brain, RefreshCw } from "lucide-react";

interface Stats {
  total: number; thisMonth: number; avgScore: number; streak: number; readiness: number;
  recent: { round: string; score: number; createdAt: string; color: string }[];
  roundStats: { round: string; count: number; avgScore: number }[];
}

const Ring = ({ score }: { score: number }) => {
  const r = 52; const c = 2 * Math.PI * r; const d = (score / 100) * c;
  const col = score >= 75 ? "var(--accent-green)" : score >= 50 ? "var(--accent-blue)" : "#f59e0b";
  return (
    <svg width={124} height={124} viewBox="0 0 124 124">
      <circle cx={62} cy={62} r={r} fill="none" stroke="var(--border)" strokeWidth={9} />
      <circle cx={62} cy={62} r={r} fill="none" stroke={col} strokeWidth={9} strokeLinecap="round"
        strokeDasharray={`${d} ${c - d}`} strokeDashoffset={c / 4} style={{ transition: "stroke-dasharray 1.2s ease" }} />
      <text x={62} y={57} textAnchor="middle" fontFamily="Syne" fontWeight={800} fontSize={21} fill="var(--text-primary)">{score}</text>
      <text x={62} y={74} textAnchor="middle" fontSize={10} fill="var(--text-muted)">/ 100</text>
    </svg>
  );
};

const GoalRing = ({ pct, color, label, icon }: { pct: number; color: string; label: string; icon: string }) => {
  const r = 24; const c = 2 * Math.PI * r; const d = (pct / 100) * c;
  return (
    <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 7 }}>
      <div style={{ position: "relative" }}>
        <svg width={60} height={60} viewBox="0 0 60 60">
          <circle cx={30} cy={30} r={r} fill="none" stroke="var(--border)" strokeWidth={5} />
          <circle cx={30} cy={30} r={r} fill="none" stroke={color} strokeWidth={5} strokeLinecap="round"
            strokeDasharray={`${d} ${c - d}`} strokeDashoffset={c / 4} style={{ transition: "stroke-dasharray 1s ease" }} />
        </svg>
        <div style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center", fontSize: "1rem" }}>{icon}</div>
      </div>
      <div style={{ textAlign: "center" }}>
        <div style={{ fontWeight: 700, fontSize: "0.72rem", color: pct === 100 ? color : "var(--text-primary)" }}>{pct === 100 ? "Done!" : `${pct}%`}</div>
        <div style={{ fontSize: "0.62rem", color: "var(--text-muted)" }}>{label}</div>
      </div>
    </div>
  );
};

const Skel = ({ w = "100%", h = 14, r = 5 }: { w?: string | number; h?: number; r?: number }) => (
  <div className="skeleton" style={{ width: w, height: h, borderRadius: r }} />
);

function timeAgo(d: string) {
  const m = Math.floor((Date.now() - new Date(d).getTime()) / 60000);
  if (m < 60)   return `${m}m ago`;
  if (m < 1440) return `${Math.floor(m / 60)}h ago`;
  return m < 2880 ? "Yesterday" : `${Math.floor(m / 1440)}d ago`;
}

export default function Dashboard() {
  const { user } = useAuth();
  const [stats, setStats]     = useState<Stats | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError]     = useState("");
  const [synced, setSynced]   = useState<Date | null>(null);

  const goalsKey = `pw_goals_${user?.id || "g"}_${new Date().toDateString()}`;
  const [goals, setGoals] = useState(() => {
    try { return JSON.parse(localStorage.getItem(goalsKey) || "null") || { practice: 0, challenge: 0, study: 0 }; }
    catch { return { practice: 0, challenge: 0, study: 0 }; }
  });
  const toggleGoal = (k: keyof typeof goals) => {
    const u = { ...goals, [k]: goals[k] >= 100 ? 0 : 100 };
    setGoals(u); localStorage.setItem(goalsKey, JSON.stringify(u));
  };

  const load = async () => {
    setLoading(true); setError("");
    try {
      const token = localStorage.getItem("token");
      const res = await fetch("/interview/stats", { headers: { Authorization: `Bearer ${token}` } });
      if (!res.ok) throw new Error(`${res.status}`);
      setStats(await res.json());
      setSynced(new Date());
    } catch (e) { setError(e instanceof Error ? e.message : "Failed"); }
    finally { setLoading(false); }
  };
  useEffect(() => { load(); }, []);

  const n = user?.name?.split(" ")[0] || "there";
  const h = new Date().getHours();
  const greet = h < 12 ? "Good morning" : h < 17 ? "Good afternoon" : "Good evening";

  const total    = stats?.total     ?? 0;
  const month    = stats?.thisMonth ?? 0;
  const avg      = stats?.avgScore  ?? 0;
  const streak   = stats?.streak    ?? 0;
  const ready    = stats?.readiness ?? 0;
  const recent   = stats?.recent    ?? [];
  const sc = (v: number) => v >= 75 ? "var(--accent-green)" : v >= 55 ? "#f59e0b" : "#ef4444";

  const today = new Date().getDay();
  const mo = today === 0 ? 6 : today - 1;
  const weekDots = ["M","T","W","T","F","S","S"].map((d, i) => ({ d, on: streak > 0 && i <= mo && i >= mo - (streak - 1) }));

  const contextMsg = total === 0 ? "Complete your first mock interview to see your stats."
    : avg >= 80 ? `Averaging ${avg}/100 — strong performance! 🚀`
    : avg >= 60 ? `Avg ${avg}/100 — push for 80+ to stand out.`
    : `Avg ${avg}/100 — keep practising, improvement is visible!`;

  return (
    <div style={{ maxWidth: 1080, margin: "0 auto" }}>
      {/* Greeting */}
      <div style={{ marginBottom: 22, display: "flex", alignItems: "flex-start", justifyContent: "space-between", gap: 12, flexWrap: "wrap" }}>
        <div>
          <h1 style={{ fontFamily: "Syne,sans-serif", fontWeight: 800, fontSize: "clamp(1.4rem,2.5vw,1.9rem)", letterSpacing: "-0.03em", color: "var(--text-primary)", marginBottom: 5 }}>
            {greet}, <span className="gradient-text">{n}</span> 👋
          </h1>
          <p style={{ color: "var(--text-secondary)", fontSize: "0.88rem" }}>{contextMsg}</p>
        </div>
        <button onClick={load} disabled={loading} style={{ display: "flex", alignItems: "center", gap: 6, padding: "6px 12px", borderRadius: 8, border: "1px solid var(--border)", background: "var(--bg-primary)", color: "var(--text-muted)", fontSize: "0.75rem", fontWeight: 600, cursor: loading ? "not-allowed" : "pointer", opacity: loading ? 0.6 : 1 }}>
          <RefreshCw size={11} style={{ animation: loading ? "spin 1s linear infinite" : "none" }} />
          {synced ? `Synced ${timeAgo(synced.toISOString())}` : "Refresh"}
        </button>
      </div>

      {/* Top row */}
      <div style={{ display: "grid", gridTemplateColumns: "240px 1fr 180px", gap: 14, marginBottom: 14 }}>
        {/* Readiness */}
        <div className="card" style={{ borderRadius: 15, padding: "20px", display: "flex", flexDirection: "column", alignItems: "center" }}>
          <div style={{ fontFamily: "Syne,sans-serif", fontWeight: 700, fontSize: "0.85rem", color: "var(--text-primary)", marginBottom: 12, alignSelf: "flex-start" }}>Readiness Score</div>
          {loading ? <Skel w={124} h={124} r={62} /> : <Ring score={ready} />}
          {!loading && (
            <>
              <div style={{ marginTop: 8, fontSize: "0.7rem", color: "var(--text-muted)", textAlign: "center" }}>
                {ready === 0 ? "Complete interviews to build your score" : ready < 50 ? "Keep practising — you're getting there" : ready < 75 ? "Good progress! Push harder." : "Interview-ready — maintain your streak!"}
              </div>
              <div style={{ width: "100%", marginTop: 12, display: "flex", flexDirection: "column", gap: 5 }}>
                {[
                  { label: "Interviews",  val: Math.min(100, total * 10),         color: "var(--accent-blue)"  },
                  { label: "Avg Score",   val: avg,                                color: sc(avg)               },
                  { label: "Streak",      val: Math.min(100, streak * 14),         color: "#f59e0b"             },
                  { label: "Activity",    val: Math.min(100, (total / 20) * 100),  color: "var(--accent-green)" },
                ].map(c => (
                  <div key={c.label} style={{ display: "flex", alignItems: "center", gap: 7 }}>
                    <div style={{ flex: 1, height: 3, borderRadius: 2, background: "var(--border)", overflow: "hidden" }}>
                      <div style={{ width: `${c.val}%`, height: "100%", background: c.color, borderRadius: 2, transition: "width 0.8s ease" }} />
                    </div>
                    <span style={{ fontSize: "0.6rem", color: "var(--text-muted)", width: 55, textAlign: "right" }}>{c.label}</span>
                  </div>
                ))}
              </div>
            </>
          )}
        </div>

        {/* Goals */}
        <div className="card" style={{ borderRadius: 15, padding: "20px" }}>
          <div style={{ fontFamily: "Syne,sans-serif", fontWeight: 700, fontSize: "0.85rem", color: "var(--text-primary)", marginBottom: 3 }}>Today's Goals</div>
          <div style={{ fontSize: "0.72rem", color: "var(--text-muted)", marginBottom: 16 }}>Click a ring to mark complete — resets daily</div>
          <div style={{ display: "flex", justifyContent: "space-around", marginBottom: 16 }}>
            <GoalRing pct={goals.practice} color="var(--accent-blue)"  label="Practice"  icon="📋" />
            <GoalRing pct={goals.challenge} color="#f59e0b"             label="Challenge" icon="🔥" />
            <GoalRing pct={goals.study}    color="var(--accent-green)" label="Study 30m" icon="📚" />
          </div>
          <div style={{ display: "flex", gap: 8 }}>
            {(["practice","challenge","study"] as const).map((k, i) => (
              <button key={k} onClick={() => toggleGoal(k)} style={{
                flex: 1, padding: "7px 4px", borderRadius: 8, cursor: "pointer", fontSize: "0.68rem", fontWeight: 600,
                border: `1px solid ${goals[k] === 100 ? "var(--accent-green)" : "var(--border)"}`,
                background: goals[k] === 100 ? "rgba(0,229,160,0.08)" : "var(--bg-primary)",
                color: goals[k] === 100 ? "var(--accent-green)" : "var(--text-muted)",
                transition: "all 0.18s",
              }}>
                {goals[k] === 100 ? "✓ Done" : ["Mark practice","Do challenge","Study 30 min"][i]}
              </button>
            ))}
          </div>
          <div style={{ marginTop: 10, fontSize: "0.65rem", color: "var(--text-muted)", textAlign: "center" }}>
            {Object.values(goals).filter(v => v === 100).length}/3 completed today
          </div>
        </div>

        {/* Streak */}
        <div className="card" style={{ borderRadius: 15, padding: "18px", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", textAlign: "center" }}>
          <div style={{ fontSize: "2.2rem", lineHeight: 1, marginBottom: 5 }}>🔥</div>
          {loading ? <Skel w={50} h={32} r={4} /> : (
            <div style={{ fontFamily: "Syne,sans-serif", fontWeight: 800, fontSize: "2.2rem", color: streak > 0 ? "#f59e0b" : "var(--text-muted)", lineHeight: 1, marginBottom: 3 }}>{streak}</div>
          )}
          <div style={{ fontWeight: 600, fontSize: "0.78rem", color: "var(--text-primary)", marginBottom: 2 }}>Day Streak</div>
          <div style={{ fontSize: "0.65rem", color: "var(--text-muted)", marginBottom: 11 }}>{streak === 0 ? "Start today!" : streak >= 7 ? "On fire! 🚀" : "Keep it up!"}</div>
          <div style={{ display: "flex", gap: 3 }}>
            {weekDots.map((day, i) => (
              <div key={i} style={{ width: 16, height: 16, borderRadius: 3, background: day.on ? "rgba(245,158,11,0.2)" : "var(--bg-primary)", border: `1px solid ${day.on ? "rgba(245,158,11,0.5)" : "var(--border)"}`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: day.on ? "0.5rem" : "0.45rem", color: day.on ? "#f59e0b" : "var(--text-muted)" }}>
                {day.on ? "●" : day.d}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Stat cards */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr 1fr", gap: 12, marginBottom: 14 }}>
        {[
          { label: "Mock Interviews", val: String(month), sub: "this month",       total: `${total} all-time`,   icon: Mic,       color: "var(--accent-blue)",  trendUp: month > 0, trend: `${total} total` },
          { label: "Avg Score",       val: avg > 0 ? String(avg) : "—", sub: "across all rounds", total: avg >= 75 ? "Strong 💪" : avg > 0 ? "Keep going" : "No data yet", icon: TrendingUp, color: sc(avg), trendUp: avg >= 60, trend: avg > 0 ? `${avg}/100` : "—" },
          { label: "Total Sessions",  val: String(total), sub: "all-time",          total: total >= 10 ? "Dedicated 🌟" : total > 0 ? "Keep going" : "Try your first", icon: Clock, color: "var(--accent-green)", trendUp: total > 0, trend: total > 0 ? `${total} done` : "Start now" },
          { label: "Day Streak",      val: streak > 0 ? `${streak}🔥` : "0", sub: "days in a row", total: streak >= 7 ? "On fire! 🔥" : streak > 0 ? "Keep it up" : "Start today", icon: Award, color: streak > 0 ? "#f59e0b" : "var(--text-muted)", trendUp: streak > 0, trend: streak > 0 ? `${streak} days` : "—" },
        ].map(s => (
          <div key={s.label} className="card" style={{ borderRadius: 13, padding: "16px" }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 10 }}>
              <div style={{ width: 34, height: 34, borderRadius: 8, background: `${s.color}15`, border: `1px solid ${s.color}22`, display: "flex", alignItems: "center", justifyContent: "center" }}>
                <s.icon size={15} color={s.color} />
              </div>
              <div style={{ display: "flex", alignItems: "center", gap: 3, color: s.trendUp ? "var(--accent-green)" : "var(--text-muted)", fontSize: "0.65rem", fontWeight: 600 }}>
                {s.trendUp && <ArrowUp size={9} />} {s.trend}
              </div>
            </div>
            {loading ? <Skel w="55%" h={26} r={4} /> : (
              <div style={{ fontFamily: "Syne,sans-serif", fontWeight: 800, fontSize: "1.7rem", color: "var(--text-primary)", lineHeight: 1, marginBottom: 3 }}>{s.val}</div>
            )}
            <div style={{ fontWeight: 600, fontSize: "0.78rem", color: "var(--text-primary)", marginBottom: 1 }}>{s.label}</div>
            <div style={{ fontSize: "0.68rem", color: "var(--text-muted)" }}>{s.total}</div>
          </div>
        ))}
      </div>

      {/* Bottom */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 14 }}>
        {/* Recent interviews */}
        <div className="card" style={{ borderRadius: 15, padding: "18px" }}>
          <div style={{ fontFamily: "Syne,sans-serif", fontWeight: 700, fontSize: "0.85rem", color: "var(--text-primary)", marginBottom: 12, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            Recent Interviews
            <Link to="/mock" style={{ fontSize: "0.72rem", color: "var(--accent-blue)", fontWeight: 600, textDecoration: "none" }}>+ New</Link>
          </div>
          {loading ? (
            <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>{[1,2,3].map(i => <Skel key={i} h={48} r={8} />)}</div>
          ) : error ? (
            <div style={{ padding: "12px", borderRadius: 8, background: "rgba(239,68,68,0.06)", border: "1px solid rgba(239,68,68,0.15)", textAlign: "center", fontSize: "0.78rem", color: "#ef4444" }}>
              Could not load <button onClick={load} style={{ background: "none", border: "none", color: "var(--accent-blue)", cursor: "pointer", fontWeight: 600 }}>Retry</button>
            </div>
          ) : recent.length === 0 ? (
            <div style={{ display: "flex", flexDirection: "column", alignItems: "center", padding: "24px 14px", gap: 8 }}>
              <Mic size={26} color="var(--border)" />
              <div style={{ fontSize: "0.78rem", color: "var(--text-muted)", textAlign: "center" }}>No interviews yet.</div>
              <Link to="/mock" style={{ fontSize: "0.75rem", color: "var(--accent-blue)", fontWeight: 700, textDecoration: "none" }}>Start your first →</Link>
            </div>
          ) : (
            <div style={{ display: "flex", flexDirection: "column", gap: 7 }}>
              {recent.map((r, i) => (
                <div key={i} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "9px 11px", borderRadius: 8, background: "var(--bg-primary)", border: "1px solid var(--border)" }}>
                  <div>
                    <div style={{ fontWeight: 600, fontSize: "0.8rem", color: "var(--text-primary)", marginBottom: 1 }}>{r.round}</div>
                    <div style={{ fontSize: "0.68rem", color: "var(--text-muted)" }}>{timeAgo(r.createdAt)}</div>
                  </div>
                  <div style={{ fontFamily: "Syne,sans-serif", fontWeight: 800, fontSize: "1.05rem", color: r.color }}>{r.score}</div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Performance */}
        <div className="card" style={{ borderRadius: 15, padding: "18px" }}>
          <div style={{ fontFamily: "Syne,sans-serif", fontWeight: 700, fontSize: "0.85rem", color: "var(--text-primary)", marginBottom: 12, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            Performance
            <Link to="/skill" style={{ fontSize: "0.72rem", color: "var(--accent-blue)", fontWeight: 600, textDecoration: "none" }}>Details</Link>
          </div>
          {loading ? (
            <div style={{ display: "flex", flexDirection: "column", gap: 9 }}>{[1,2,3,4].map(i => <Skel key={i} h={18} r={4} />)}</div>
          ) : total === 0 ? (
            <div style={{ display: "flex", flexDirection: "column", alignItems: "center", padding: "24px 14px", gap: 8 }}>
              <Target size={26} color="var(--border)" />
              <div style={{ fontSize: "0.78rem", color: "var(--text-muted)", textAlign: "center" }}>Complete interviews to see your breakdown.</div>
            </div>
          ) : (
            <div style={{ display: "flex", flexDirection: "column", gap: 9 }}>
              {[
                { skill: "Sessions Done",  val: Math.min(100, total * 10),         color: "var(--accent-blue)"  },
                { skill: "Answer Quality", val: avg,                                color: sc(avg)               },
                { skill: "Consistency",    val: Math.min(100, streak * 14),         color: "#f59e0b"             },
                { skill: "This Month",     val: Math.min(100, (month / 10) * 100),  color: "var(--accent-cyan)"  },
                { skill: "Readiness",      val: ready,                              color: sc(ready)             },
              ].map(s => (
                <div key={s.skill}>
                  <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 3 }}>
                    <span style={{ fontSize: "0.75rem", color: "var(--text-secondary)", fontWeight: 500 }}>{s.skill}</span>
                    <span style={{ fontSize: "0.75rem", color: s.color, fontWeight: 700 }}>{s.val}%</span>
                  </div>
                  <div style={{ height: 4, borderRadius: 2, background: "var(--border)", overflow: "hidden" }}>
                    <div style={{ width: `${s.val}%`, height: "100%", background: s.color, borderRadius: 2, transition: "width 0.8s ease" }} />
                  </div>
                </div>
              ))}
              {recent.length >= 2 && (
                <div style={{ marginTop: 4, padding: "7px 9px", borderRadius: 7, background: "var(--bg-primary)", border: "1px solid var(--border)" }}>
                  <div style={{ fontSize: "0.62rem", color: "var(--text-muted)", marginBottom: 4 }}>Score trend (last {recent.length})</div>
                  <div style={{ display: "flex", gap: 3, alignItems: "flex-end", height: 20 }}>
                    {recent.slice().reverse().map((r, i) => (
                      <div key={i} style={{ flex: 1, background: r.color, borderRadius: 2, height: `${(r.score / 100) * 100}%`, minHeight: 3 }} />
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Quick Actions */}
        <div style={{ display: "flex", flexDirection: "column", gap: 9 }}>
          {[
            { to: "/mock",    icon: Mic,      label: "Start Mock Interview",  sub: total > 0 ? `${total} sessions done` : "AI Coach ready",             color: "var(--accent-blue)"   },
            { to: "/resume",  icon: FileText, label: "Resume Analyzer",       sub: "Upload PDF → ATS score + coaching",                                  color: "var(--accent-purple)" },
            { to: "/skill",   icon: Target,   label: "Skill Gap Report",      sub: total > 0 ? `Based on ${total} interview sessions` : "See weak areas", color: "var(--accent-cyan)"   },
            { to: "/profile", icon: Brain,    label: "Update Profile",        sub: user?.targetRole || "Set your target role",                            color: "var(--accent-green)"  },
          ].map(a => (
            <Link key={a.to} to={a.to} style={{ textDecoration: "none" }}>
              <div style={{ padding: "11px 13px", borderRadius: 10, display: "flex", alignItems: "center", gap: 11, cursor: "pointer", border: "1px solid var(--border)", background: "var(--bg-card)", transition: "all 0.18s" }}
                onMouseEnter={e => { const el = e.currentTarget as HTMLElement; el.style.borderColor = a.color; el.style.background = "var(--bg-card-hover)"; }}
                onMouseLeave={e => { const el = e.currentTarget as HTMLElement; el.style.borderColor = "var(--border)"; el.style.background = "var(--bg-card)"; }}>
                <div style={{ width: 30, height: 30, borderRadius: 7, background: `${a.color}15`, border: `1px solid ${a.color}22`, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
                  <a.icon size={14} color={a.color} />
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontWeight: 700, fontSize: "0.8rem", color: "var(--text-primary)" }}>{a.label}</div>
                  <div style={{ fontSize: "0.65rem", color: "var(--text-muted)", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{a.sub}</div>
                </div>
                <ChevronRight size={12} color="var(--text-muted)" />
              </div>
            </Link>
          ))}
        </div>
      </div>

      {/* New user banner */}
      {!loading && total === 0 && (
        <div style={{ marginTop: 18, padding: "20px 24px", borderRadius: 15, background: "linear-gradient(135deg,rgba(59,142,255,0.07),rgba(0,229,160,0.05))", border: "1px solid rgba(59,142,255,0.2)", display: "flex", alignItems: "center", gap: 16, flexWrap: "wrap" }}>
          <div style={{ width: 44, height: 44, borderRadius: 11, background: "var(--glow-blue)", border: "1px solid var(--border-strong)", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
            <Brain size={20} color="var(--accent-blue)" />
          </div>
          <div style={{ flex: 1 }}>
            <div style={{ fontFamily: "Syne,sans-serif", fontWeight: 700, fontSize: "0.9rem", color: "var(--text-primary)", marginBottom: 3 }}>Welcome to PrepWise, {n}! 🎉</div>
            <div style={{ fontSize: "0.78rem", color: "var(--text-secondary)", lineHeight: 1.6 }}>Your dashboard fills with real data as you practice. Start with a mock interview — your readiness score, streak, and performance chart will appear here.</div>
          </div>
          <Link to="/mock" className="btn-primary" style={{ padding: "9px 18px", borderRadius: 9, fontWeight: 700, fontSize: "0.85rem", textDecoration: "none", flexShrink: 0 }}>
            <span style={{ position: "relative", zIndex: 1 }}>Begin Now →</span>
          </Link>
        </div>
      )}
    </div>
  );
}
