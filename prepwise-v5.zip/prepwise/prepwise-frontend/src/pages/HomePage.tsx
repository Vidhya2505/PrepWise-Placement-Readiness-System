import { useEffect, useRef, useState, type ElementType } from "react";
import { Link } from "react-router-dom";
import { FileText, Brain, Mic, BarChart3, Target, RefreshCw, TrendingUp, Shield, ChevronRight, ArrowRight, Zap, Award } from "lucide-react";

const FeatureCard = ({ icon: Icon, title, description, accent, delay }: { icon: ElementType; title: string; description: string; accent: string; delay: string }) => (
  <div className={`card animate-fade-up opacity-0 ${delay}`} style={{ borderRadius: 16, padding: "26px", cursor: "default" }}>
    <div style={{ width: 46, height: 46, borderRadius: 11, display: "flex", alignItems: "center", justifyContent: "center", background: `${accent}15`, border: `1px solid ${accent}30`, marginBottom: 14 }}>
      <Icon size={20} color={accent} />
    </div>
    <h3 style={{ fontFamily: "Syne,sans-serif", fontWeight: 700, fontSize: "1rem", marginBottom: 8, color: "var(--text-primary)" }}>{title}</h3>
    <p style={{ color: "var(--text-secondary)", fontSize: "0.875rem", lineHeight: 1.7 }}>{description}</p>
  </div>
);

const StepCard = ({ number, title, description, delay }: { number: string; title: string; description: string; delay: string }) => (
  <div className={`animate-fade-up opacity-0 ${delay}`} style={{ display: "flex", gap: 18, alignItems: "flex-start" }}>
    <div style={{ width: 44, height: 44, borderRadius: 11, flexShrink: 0, background: "linear-gradient(135deg,var(--accent-blue),var(--accent-cyan))", display: "flex", alignItems: "center", justifyContent: "center", fontFamily: "Syne,sans-serif", fontWeight: 800, fontSize: "1rem", color: "white", boxShadow: "0 4px 14px rgba(59,142,255,0.35)" }}>
      {number}
    </div>
    <div>
      <h3 style={{ fontFamily: "Syne,sans-serif", fontWeight: 700, fontSize: "1rem", marginBottom: 6, color: "var(--text-primary)" }}>{title}</h3>
      <p style={{ color: "var(--text-secondary)", fontSize: "0.875rem", lineHeight: 1.7 }}>{description}</p>
    </div>
  </div>
);

export default function HomePage() {
  const heroRef = useRef<HTMLDivElement>(null);
  const [mouse, setMouse] = useState({ x: 0, y: 0 });
  useEffect(() => {
    const h = (e: MouseEvent) => setMouse({ x: e.clientX, y: e.clientY });
    window.addEventListener("mousemove", h);
    return () => window.removeEventListener("mousemove", h);
  }, []);

  const features = [
    { icon: FileText,   title: "Smart Resume Analysis",         description: "Upload your resume and get instant ATS score, keyword gaps, section feedback, and actionable improvements.",                accent: "var(--accent-blue)"   },
    { icon: Brain,      title: "AI Skill Gap Detection",        description: "Diagnoses claimed skills vs demonstrated knowledge — DSA, OS, DBMS, CN — and shows exactly what to fix first.",           accent: "var(--accent-cyan)"   },
    { icon: Mic,        title: "Resume-Aware Mock Interviews",  description: "Questions generated from YOUR actual resume and projects. Not generic — personalised to your profile every session.",       accent: "var(--accent-green)"  },
    { icon: BarChart3,  title: "Intelligent Answer Evaluation", description: "Every answer scored on content depth, clarity, structure, and confidence — with WHY you got that score.",                  accent: "var(--accent-blue)"   },
    { icon: Target,     title: "Placement Readiness Score",     description: "A real 0–100 score computed from your actual interview history, streak, and performance trends.",                           accent: "var(--accent-cyan)"   },
    { icon: RefreshCw,  title: "STAR & Filler Word Detection",  description: "Tracks Situation/Task/Action/Result in behavioural answers and highlights filler words (um, like, basically) live.",     accent: "var(--accent-green)"  },
    { icon: TrendingUp, title: "Progress Tracking",             description: "Dashboard shows real data — total sessions, avg score, streak, recent interviews — all from your actual history.",         accent: "var(--accent-blue)"   },
    { icon: Shield,     title: "Recruiter View & Risk Score",   description: "After every answer: how a recruiter would rate you, hire decision, and your real interview risk level.",                    accent: "var(--accent-cyan)"   },
  ];
  const steps = [
    { number: "01", title: "Create Your Account",     description: "Sign up in 60 seconds. Tell us your target role, company type, and current skills." },
    { number: "02", title: "Analyze Your Resume",     description: "Upload your resume (PDF). AI extracts skills, scores it against JDs, and saves your profile." },
    { number: "03", title: "Take a Mock Interview",   description: "AI generates 5 questions personalised to your resume and chosen round (HR/Technical/Project/DSA)." },
    { number: "04", title: "Get Coached Per Answer",  description: "After each answer: score breakdown, recruiter view, filler words, improved answer, next steps." },
    { number: "05", title: "Track & Improve",         description: "Dashboard updates after every session. Watch your readiness score climb as you practice." },
  ];

  return (
    <div style={{ minHeight: "100vh", background: "var(--bg-primary)" }}>
      {/* HERO */}
      <section ref={heroRef} className="noise-overlay" style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", position: "relative", overflow: "hidden", paddingTop: 80 }}>
        <div className="grid-overlay" style={{ position: "absolute", inset: 0, opacity: 0.35 }} />
        <div className="orb orb-blue" style={{ width: 580, height: 580, top: "8%", left: "58%", transform: `translate(${mouse.x * 0.008}px,${mouse.y * 0.008}px)`, transition: "transform 0.5s ease" }} />
        <div className="orb orb-cyan" style={{ width: 380, height: 380, bottom: "18%", left: "8%", transform: `translate(${mouse.x * -0.004}px,${mouse.y * -0.004}px)`, transition: "transform 0.5s ease" }} />
        <div className="animate-float" style={{ position: "absolute", top: "14%", right: "7%", width: 72, height: 72, borderRadius: 14, border: "1px solid var(--border-strong)", background: "var(--glow-blue)", transform: "rotate(18deg)" }} />
        <div className="animate-float delay-300" style={{ position: "absolute", bottom: "24%", left: "4%", width: 44, height: 44, borderRadius: "50%", border: "1px solid rgba(0,229,160,0.2)", background: "rgba(0,229,160,0.05)" }} />

        <div style={{ maxWidth: 820, margin: "0 auto", padding: "0 24px", textAlign: "center", position: "relative", zIndex: 1 }}>
          <div className="animate-fade-up opacity-0 tag" style={{ display: "inline-flex", alignItems: "center", gap: 7, borderRadius: 100, padding: "5px 14px", marginBottom: 28 }}>
            <Zap size={11} /> AI-Powered Placement Intelligence
          </div>
          <h1 className="animate-fade-up opacity-0 delay-100" style={{ fontFamily: "Syne,sans-serif", fontWeight: 800, fontSize: "clamp(2.6rem,6vw,4.8rem)", lineHeight: 1.08, letterSpacing: "-0.04em", marginBottom: 22 }}>
            Crack Interviews with<br /><span className="gradient-text">Intelligent Preparation</span>
          </h1>
          <p className="animate-fade-up opacity-0 delay-200" style={{ fontSize: "clamp(0.95rem,2vw,1.15rem)", color: "var(--text-secondary)", lineHeight: 1.75, maxWidth: 580, margin: "0 auto 36px", fontWeight: 400 }}>
            PrepWise reads your actual resume, generates personalised interview questions, and after every answer tells you exactly why you scored that — with recruiter view, risk analysis, and a rewritten model answer.
          </p>
          <div className="animate-fade-up opacity-0 delay-300" style={{ display: "flex", gap: 12, justifyContent: "center", flexWrap: "wrap" }}>
            <Link to="/signup" className="btn-primary" style={{ padding: "13px 30px", borderRadius: 10, fontWeight: 700, fontSize: "0.95rem", textDecoration: "none", display: "inline-flex", alignItems: "center", gap: 8 }}>
              <span style={{ position: "relative", zIndex: 1, display: "flex", alignItems: "center", gap: 8 }}>Start Free Today <ArrowRight size={17} /></span>
            </Link>
            <a href="#how-it-works" className="btn-ghost" style={{ padding: "13px 28px", borderRadius: 10, fontWeight: 600, fontSize: "0.95rem", textDecoration: "none", display: "inline-flex", alignItems: "center", gap: 7 }}>
              See How It Works <ChevronRight size={15} />
            </a>
          </div>
        </div>
        <div style={{ position: "absolute", bottom: 0, left: 0, right: 0, height: 180, background: "linear-gradient(to bottom,transparent,var(--bg-primary))" }} />
      </section>

      {/* FEATURES */}
      <section id="features" style={{ padding: "80px 24px", maxWidth: 1200, margin: "0 auto" }}>
        <div style={{ textAlign: "center", marginBottom: 52 }}>
          <div className="tag animate-fade-up opacity-0" style={{ display: "inline-flex", alignItems: "center", gap: 7, borderRadius: 100, padding: "5px 14px", marginBottom: 14 }}><Award size={11} /> Everything You Need</div>
          <h2 className="animate-fade-up opacity-0 delay-100" style={{ fontFamily: "Syne,sans-serif", fontWeight: 800, fontSize: "clamp(1.9rem,4vw,2.9rem)", letterSpacing: "-0.03em", lineHeight: 1.1, marginBottom: 14 }}>
            A Complete Placement<br /><span className="gradient-text">Intelligence System</span>
          </h2>
          <p className="animate-fade-up opacity-0 delay-200" style={{ color: "var(--text-secondary)", fontSize: "0.95rem", maxWidth: 500, margin: "0 auto", lineHeight: 1.7 }}>
            Not just a quiz app. PrepWise understands your resume, evaluates your answers deeply, and builds a personalised path.
          </p>
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(270px,1fr))", gap: 18 }}>
          {features.map((f, i) => <FeatureCard key={f.title} {...f} delay={`delay-${Math.min((i % 4 + 1) * 100, 400)}`} />)}
        </div>
      </section>

      {/* HOW IT WORKS */}
      <section id="how-it-works" style={{ padding: "80px 24px", background: "var(--bg-secondary)" }}>
        <div style={{ maxWidth: 1100, margin: "0 auto", display: "grid", gridTemplateColumns: "1fr 1fr", gap: 72, alignItems: "center" }}>
          <div>
            <div className="tag animate-fade-up opacity-0" style={{ display: "inline-flex", alignItems: "center", gap: 7, borderRadius: 100, padding: "5px 14px", marginBottom: 18 }}><ChevronRight size={11} /> Simple Process</div>
            <h2 className="animate-fade-up opacity-0 delay-100" style={{ fontFamily: "Syne,sans-serif", fontWeight: 800, fontSize: "clamp(1.7rem,3.5vw,2.5rem)", letterSpacing: "-0.03em", marginBottom: 14, lineHeight: 1.15 }}>
              Your Path to<br /><span className="gradient-text-green">Placement Readiness</span>
            </h2>
            <p className="animate-fade-up opacity-0 delay-200" style={{ color: "var(--text-secondary)", fontSize: "0.92rem", lineHeight: 1.8, marginBottom: 36 }}>
              A structured process designed around how placements actually work — each step feeds the next.
            </p>
            <Link to="/signup" className="btn-primary animate-fade-up opacity-0 delay-300" style={{ padding: "11px 26px", borderRadius: 10, fontWeight: 600, fontSize: "0.9rem", textDecoration: "none", display: "inline-flex", alignItems: "center", gap: 7 }}>
              <span style={{ position: "relative", zIndex: 1, display: "flex", alignItems: "center", gap: 7 }}>Begin Your Journey <ArrowRight size={15} /></span>
            </Link>
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: 26 }}>
            {steps.map((s, i) => <StepCard key={s.number} {...s} delay={`delay-${(i + 1) * 100}`} />)}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section style={{ padding: "100px 24px", textAlign: "center", position: "relative", overflow: "hidden" }}>
        <div className="orb orb-blue" style={{ width: 500, height: 500, top: "50%", left: "50%", transform: "translate(-50%,-50%)" }} />
        <div style={{ position: "relative", zIndex: 1, maxWidth: 600, margin: "0 auto" }}>
          <h2 className="animate-fade-up opacity-0" style={{ fontFamily: "Syne,sans-serif", fontWeight: 800, fontSize: "clamp(1.9rem,4vw,3rem)", letterSpacing: "-0.04em", lineHeight: 1.1, marginBottom: 18 }}>
            Ready to land your<br /><span className="gradient-text">dream placement?</span>
          </h2>
          <p className="animate-fade-up opacity-0 delay-100" style={{ color: "var(--text-secondary)", fontSize: "0.95rem", lineHeight: 1.7, marginBottom: 32 }}>
            Resume analysis, AI-powered mock interviews, and per-answer coaching — all free, all personalised to you.
          </p>
          <div className="animate-fade-up opacity-0 delay-200" style={{ display: "flex", gap: 12, justifyContent: "center", flexWrap: "wrap" }}>
            <Link to="/signup" className="btn-primary" style={{ padding: "13px 34px", borderRadius: 10, fontWeight: 700, fontSize: "0.95rem", textDecoration: "none", display: "inline-flex", alignItems: "center", gap: 8 }}>
              <span style={{ position: "relative", zIndex: 1, display: "flex", alignItems: "center", gap: 8 }}>Create Free Account <ArrowRight size={17} /></span>
            </Link>
            <Link to="/login" className="btn-ghost" style={{ padding: "13px 24px", borderRadius: 10, fontWeight: 600, fontSize: "0.95rem", textDecoration: "none" }}>Sign In</Link>
          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer style={{ borderTop: "1px solid var(--border)", padding: "28px 24px", background: "var(--bg-secondary)" }}>
        <div style={{ maxWidth: 1200, margin: "0 auto", display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: 14 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 9 }}>
            <div style={{ width: 30, height: 30, borderRadius: 7, background: "linear-gradient(135deg,var(--accent-blue),var(--accent-cyan))", display: "flex", alignItems: "center", justifyContent: "center" }}><Brain size={14} color="white" /></div>
            <span style={{ fontFamily: "Syne,sans-serif", fontWeight: 800, fontSize: "1rem", color: "var(--text-primary)" }}>Prep<span style={{ color: "var(--accent-blue)" }}>Wise</span></span>
          </div>
          <p style={{ color: "var(--text-muted)", fontSize: "0.85rem" }}>© 2025 PrepWise. Built for placement warriors.</p>
          <div style={{ display: "flex", gap: 20 }}>
            {["Privacy","Terms","Contact"].map(l => (
              <a key={l} href="#" style={{ color: "var(--text-muted)", fontSize: "0.85rem", textDecoration: "none" }}
                onMouseEnter={e => (e.currentTarget.style.color = "var(--accent-blue)")}
                onMouseLeave={e => (e.currentTarget.style.color = "var(--text-muted)")}>{l}</a>
            ))}
          </div>
        </div>
      </footer>
    </div>
  );
}
