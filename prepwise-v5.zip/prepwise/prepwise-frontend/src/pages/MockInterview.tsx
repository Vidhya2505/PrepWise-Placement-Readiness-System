import { useState, useRef, useEffect, useCallback } from "react";
import {
  Mic, MicOff, Send, ChevronRight, Clock, Brain, User,
  RefreshCw, CheckCircle, AlertTriangle, Zap, BarChart2,
  MessageSquare, TrendingUp, Download, RotateCcw, Volume2,
  VolumeX, StopCircle, Camera, CameraOff, Video, VideoOff,
  Eye, Smile, Activity, FileText, ThumbsUp, ThumbsDown,
  Lightbulb, ArrowRight, Sparkles, Target, Info, ArrowUpRight,
  XCircle, AlertOctagon, Gauge, UserCheck, Flame, BookOpen
} from "lucide-react";
import { useResume } from "../context/ResumeContext";
import { downloadMockInterviewPDF } from "../services/pdfUtils";

type Phase = "setup" | "loading" | "interview" | "results";
type Round = "HR" | "Technical" | "Project" | "DSA" | "Behavioural";

const ROUNDS: { id: Round; label: string; desc: string; color: string; icon: string }[] = [
  { id: "HR",          label: "HR Round",           desc: "Intro, goals, motivation, self-awareness",  color: "var(--accent-blue)",   icon: "👤" },
  { id: "Technical",   label: "Technical Round",    desc: "Core CS: DSA, OS, DBMS, Networking",        color: "var(--accent-cyan)",   icon: "💻" },
  { id: "Behavioural", label: "Behavioural Round",  desc: "STAR method, teamwork, leadership",          color: "var(--accent-purple)", icon: "🎯" },
  { id: "Project",     label: "Project Discussion", desc: "Deep dive into your resume projects",        color: "var(--accent-green)",  icon: "🚀" },
  { id: "DSA",         label: "DSA Round",          desc: "Problem solving & coding approach",          color: "#f59e0b",              icon: "🧠" },
];

interface AIFeedback {
  score: number; label: string; color: string; interpretation: string;
  scoreBreakdown: { content: number; clarity: number; structure: number; confidence: number; fillerPenalty?: number };
  breakdown: { depth: number; clarity: number; structure: number; confidence: number };
  weakestMetric: string; weakestVal: number;
  whyThisScore: string[]; topFixes: string[];
  strengths: string[]; improvements: string[];
  improvedAnswer: string; suggestedStructure: string[];
  insight: string; nextSteps: string[];
  recruiterView: { communication: string; problemSolving: string; technicalDepth: string; hireDecision: string; hireReason: string };
  confidenceContentGap: { hasGap: boolean; insight: string };
  realInterviewRisk: { level: string; verdict: string; reason: string };
  questionDifficulty: { level: string; expectedDuration: string; expectedDepth: string };
  deliveryAnalysis: { estimatedSeconds: number; idealSeconds: string; verdict: string; wordsPerMinute: number };
  weakAreaPractice: { area: string; tip: string; practicePrompt: string };
  totalFillerOccurrences: number; fillerJudgment: string; fillerJudgmentColor: string;
  fillerWords: Record<string, number>; wordCount: number; speakingPaceNote: string;
  starComponents?: { hasSituation: boolean; hasTask: boolean; hasAction: boolean; hasResult: boolean };
  isTooShort?: boolean;
}
interface FeedbackItem { question: string; answer: string; feedback: AIFeedback; previousAnswer?: string; }

const FILLER_WORDS = ["um","uh","like","you know","basically","literally","sort of","kind of","actually","right","okay","so","well","i mean","honestly"];

function detectFillers(text: string) {
  const lower = text.toLowerCase();
  const counts: Record<string, number> = {};
  FILLER_WORDS.forEach(fw => { const m = lower.match(new RegExp(`\\b${fw}\\b`, "gi")); if (m) counts[fw] = m.length; });
  return { counts, total: Object.values(counts).reduce((a, b) => a + b, 0) };
}

function highlightFillers(text: string) {
  const parts: { text: string; isFiller: boolean }[] = [];
  let remaining = text;
  while (remaining.length > 0) {
    let found = false;
    for (const fw of FILLER_WORDS) {
      const re = new RegExp(`^(${fw})\\b`, "i");
      const match = re.exec(remaining);
      if (match) { parts.push({ text: match[0], isFiller: true }); remaining = remaining.slice(match[0].length); found = true; break; }
    }
    if (!found) {
      const indices = FILLER_WORDS.map(fw => { const m = new RegExp(`\\b${fw}\\b`, "i").exec(remaining); return m ? m.index : Infinity; });
      const next = Math.min(...indices);
      if (!isFinite(next)) { parts.push({ text: remaining, isFiller: false }); break; }
      parts.push({ text: remaining.slice(0, next), isFiller: false });
      remaining = remaining.slice(next);
    }
  }
  return parts;
}

function metricLabel(key: string, val: number) {
  if (key === "depth")      return val >= 80 ? "Strong"          : val >= 60 ? "Moderate"  : "Basic";
  if (key === "clarity")    return val >= 80 ? "Very Clear"      : val >= 60 ? "Clear"      : "Unclear";
  if (key === "structure")  return val >= 80 ? "Well Structured" : val >= 60 ? "Structured" : "Needs Structure";
  if (key === "confidence") return val >= 80 ? "Very Confident"  : val >= 60 ? "Confident"  : "Uncertain";
  return "";
}

// Helper: sanitize recruiter rating values
function sanitizeRating(val: string): { display: string; color: string } {
  const v = (val || "Average").trim();
  if (v === "Excellent" || v === "Strong")  return { display: v, color: "var(--accent-green)" };
  if (v === "Average" || v === "Good")      return { display: v, color: "#f59e0b" };
  if (v === "Poor" || v === "Basic")        return { display: v, color: "#ef4444" };
  if (v === "None" || v === "N/A" || v === "") return { display: "—", color: "var(--text-muted)" };
  return { display: v, color: "#f59e0b" };
}

const hireColor = (d: string) => d === "Strong Yes" ? "var(--accent-green)" : d === "Yes" ? "#10B981" : d === "Maybe" ? "#f59e0b" : "#ef4444";
const riskColor = (l: string) => l === "low" ? "var(--accent-green)" : l === "medium" ? "#f59e0b" : "#ef4444";
const riskBg    = (l: string) => l === "low" ? "rgba(0,229,160,0.06)" : l === "medium" ? "rgba(245,158,11,0.06)" : "rgba(239,68,68,0.06)";
const BODY_TIPS = ["Maintain eye contact with the camera.","Sit up straight — good posture!","Smile gently — you look tense.","Speak at a steady pace.","Take a breath before answering.","Keep your hands relaxed and visible."];

// Minimum word count before submitting
const MIN_WORDS = 3;

export default function MockInterview() {
  const { resumeData } = useResume();

  const [phase, setPhase]             = useState<Phase>("setup");
  const [selectedRound, setRound]     = useState<Round>("Technical");
  const [questions, setQuestions]     = useState<string[]>([]);
  const [qIndex, setQIndex]           = useState(0);
  const [answer, setAnswer]           = useState("");
  const [micOn, setMicOn]             = useState(false);
  const [timer, setTimer]             = useState(120);
  const [timerActive, setTimerActive] = useState(true);
  const [feedbacks, setFeedbacks]     = useState<FeedbackItem[]>([]);
  const [submitted, setSubmitted]     = useState(false);
  const [retryMode, setRetryMode]     = useState(false);
  const [retryPrev, setRetryPrev]     = useState("");
  const [listening, setListening]     = useState(false);
  const [analyzing, setAnalyzing]     = useState(false);
  const [loadingQs, setLoadingQs]     = useState(false);
  const [loadingNext, setLoadingNext] = useState(false);
  const [error, setError]             = useState("");
  const [answerError, setAnswerError] = useState("");

  const [cameraEnabled, setCameraEnabled] = useState(false);
  const [cameraOn, setCameraOn]           = useState(false);
  const [cameraError, setCameraError]     = useState("");
  const [recording, setRecording]         = useState(false);
  const [recordingURL, setRecordingURL]   = useState<string | null>(null);
  const [confScore, setConfScore]         = useState(70);
  const [eyeContactPct, setEyeContactPct] = useState(78);
  const [speakingPace, setSpeakingPace]   = useState("Good");
  const [pauseLevel, setPauseLevel]       = useState("Normal");
  const [bodyTip, setBodyTip]             = useState(BODY_TIPS[0]);
  const [happyPct, setHappyPct]           = useState(35);
  const [neutralPct, setNeutralPct]       = useState(50);
  const [nervousPct, setNervousPct]       = useState(15);
  const [emLabel, setEmLabel]             = useState("Neutral");
  const [emColor, setEmColor]             = useState("#A855F7");

  const timerRef    = useRef<ReturnType<typeof setInterval> | null>(null);
  const recogRef    = useRef<{ stop(): void } | null>(null);
  const videoRef    = useRef<HTMLVideoElement>(null);
  const streamRef   = useRef<MediaStream | null>(null);
  const recorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef   = useRef<Blob[]>([]);
  const emotionRef  = useRef<ReturnType<typeof setInterval> | null>(null);

  const token = () => localStorage.getItem("token") || "";
  const authH = () => ({ "Content-Type": "application/json", Authorization: `Bearer ${token()}` });

  const currentQ = questions[qIndex] ?? "";
  const totalQs  = questions.length;
  const wordCount = answer.trim().split(/\s+/).filter(Boolean).length;

  useEffect(() => {
    if (phase === "interview" && !submitted && timerActive) {
      timerRef.current = setInterval(() => setTimer(t => t > 0 ? t - 1 : 0), 1000);
    }
    return () => { if (timerRef.current) clearInterval(timerRef.current); };
  }, [phase, submitted, qIndex, timerActive]);
  useEffect(() => { setTimer(120); setTimerActive(true); setAnswerError(""); }, [qIndex]);
  useEffect(() => { if (cameraOn && streamRef.current && videoRef.current) { const v = videoRef.current; v.srcObject = streamRef.current; v.muted = true; v.play().catch(() => setTimeout(() => v.play().catch(() => {}), 400)); } }, [cameraOn, phase]);

  const startCamera = useCallback(async () => {
    try {
      setCameraError("");
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: "user" }, audio: false });
      streamRef.current = stream; setCameraOn(true);
      emotionRef.current = setInterval(() => {
        const h = Math.round((Math.random() * 0.5 + 0.1) * 100); const f = Math.round(Math.random() * 25); const n = Math.max(0, 100 - h - f);
        setHappyPct(h); setNeutralPct(n); setNervousPct(f);
        setConfScore(Math.min(99, Math.max(20, Math.round(h * 0.8 + n * 0.5 - f * 0.6 + 30))));
        setEyeContactPct(Math.round(Math.random() * 20 + 65));
        setSpeakingPace(["Good","Slightly fast","Ideal","Slightly slow"][Math.floor(Math.random() * 4)]);
        setPauseLevel(["Normal","Slightly high","Low"][Math.floor(Math.random() * 3)]);
        setBodyTip(BODY_TIPS[Math.floor(Math.random() * BODY_TIPS.length)]);
        if (h > 45) { setEmLabel("Confident"); setEmColor("#10B981"); } else if (f > 25) { setEmLabel("Nervous"); setEmColor("#EF4444"); } else { setEmLabel("Neutral"); setEmColor("#A855F7"); }
      }, 2500);
    } catch (err) {
      const m = err instanceof Error ? err.message : "";
      setCameraError(m.includes("Permission") || m.includes("denied") ? "Permission denied. Click the camera icon in address bar → Allow." : m.includes("NotFound") ? "No camera found." : "Could not start camera.");
    }
  }, []);

  const stopCamera = useCallback(() => {
    streamRef.current?.getTracks().forEach(t => t.stop()); streamRef.current = null;
    if (videoRef.current) videoRef.current.srcObject = null;
    setCameraOn(false); if (emotionRef.current) clearInterval(emotionRef.current);
  }, []);

  const startRecording = () => {
    if (!streamRef.current) return; chunksRef.current = [];
    const rec = new MediaRecorder(streamRef.current);
    rec.ondataavailable = e => { if (e.data.size > 0) chunksRef.current.push(e.data); };
    rec.onstop = () => setRecordingURL(URL.createObjectURL(new Blob(chunksRef.current, { type: "video/webm" })));
    rec.start(); recorderRef.current = rec; setRecording(true);
  };
  const stopRecording = () => { recorderRef.current?.stop(); setRecording(false); };

  const startListening = () => {
    const SR = (window as unknown as { SpeechRecognition?: new () => { continuous: boolean; interimResults: boolean; lang: string; onresult: ((e: { results: { length: number; [i: number]: { [j: number]: { transcript: string } } } }) => void) | null; onend: (() => void) | null; start(): void; stop(): void }; webkitSpeechRecognition?: new () => unknown }).SpeechRecognition || (window as unknown as { webkitSpeechRecognition?: new () => unknown }).webkitSpeechRecognition;
    if (!SR) { alert("Voice input not supported. Use Chrome or Edge."); return; }
    const r = new (SR as new () => { continuous: boolean; interimResults: boolean; lang: string; onresult: ((e: { results: { length: number; [i: number]: { [j: number]: { transcript: string } } } }) => void) | null; onend: (() => void) | null; start(): void; stop(): void })();
    r.continuous = true; r.interimResults = true; r.lang = "en-US";
    r.onresult = (e) => { let t = ""; for (let i = 0; i < e.results.length; i++) t += e.results[i][0].transcript; setAnswer(t); };
    r.onend = () => setListening(false);
    r.start(); recogRef.current = r; setListening(true);
  };
  const stopListening = () => { recogRef.current?.stop(); setListening(false); };
  useEffect(() => () => { stopCamera(); if (timerRef.current) clearInterval(timerRef.current); }, [stopCamera]);

  const startInterview = async () => {
    setLoadingQs(true); setError(""); setPhase("loading");
    try {
      const res = await fetch("/ai/generate-questions", { method: "POST", headers: authH(), body: JSON.stringify({ interviewType: selectedRound, resumeData }) });
      if (!res.ok) throw new Error(`Server ${res.status}`);
      const data = await res.json();
      if (!data.questions?.length) throw new Error("No questions returned");
      setQuestions(data.questions); setQIndex(0); setFeedbacks([]); setAnswer(""); setSubmitted(false);
      setPhase("interview"); if (cameraEnabled && !cameraOn) startCamera();
    } catch (err) { setError(err instanceof Error ? err.message : "Failed to load questions."); setPhase("setup"); }
    finally { setLoadingQs(false); }
  };

  const getAIFeedback = async (question: string, userAnswer: string): Promise<AIFeedback> => {
    const { counts: fillerCounts, total: totalFillerOccurrences } = detectFillers(userAnswer);
    const wc = userAnswer.trim().split(/\s+/).filter(Boolean).length;
    const estSec = Math.round((wc / 130) * 60);
    const isTooShort = wc < 10;
    const starComponents = {
      hasSituation: /situation|context|when|time when|once|project|team/i.test(userAnswer),
      hasTask:      /task|responsibility|challenge|goal|needed to|had to|was asked/i.test(userAnswer),
      hasAction:    /i did|i took|i implemented|i decided|i built|i fixed|i designed|i created|i resolved/i.test(userAnswer),
      hasResult:    /result|outcome|achieved|improved|reduced|increased|success|learned|impact|dropped|won|shipped/i.test(userAnswer),
    };
    const fillerMeta = {
      totalFillerOccurrences,
      fillerJudgment: totalFillerOccurrences === 0 ? "None — excellent 🎉" : totalFillerOccurrences <= 2 ? "Minimal ✓" : totalFillerOccurrences <= 5 ? "Moderate — needs work" : "Too many ⚠",
      fillerJudgmentColor: totalFillerOccurrences === 0 ? "var(--accent-green)" : totalFillerOccurrences <= 2 ? "var(--accent-blue)" : totalFillerOccurrences <= 5 ? "#f59e0b" : "#ef4444",
      fillerWords: fillerCounts, wordCount: wc,
      speakingPaceNote: wc < 20 ? "Very brief" : wc < 60 ? "Brief" : wc < 150 ? "Good length" : wc < 250 ? "Detailed" : "Very detailed",
      starComponents: selectedRound === "Behavioural" ? starComponents : undefined,
      isTooShort,
    };

    try {
      const res = await fetch("/ai/feedback-answer", { method: "POST", headers: authH(), body: JSON.stringify({ question, answer: userAnswer, round: selectedRound, resumeData }) });
      if (res.ok) {
        const data = await res.json(); const f = data.feedback || data;
        const score = typeof f.score === "number" ? Math.max(10, Math.min(97, f.score)) : 50;
        const label = score >= 85 ? "Excellent" : score >= 70 ? "Strong" : score >= 55 ? "Good" : score >= 40 ? "Needs Work" : "Too Brief";
        const color = score >= 85 ? "var(--accent-green)" : score >= 70 ? "var(--accent-blue)" : score >= 55 ? "var(--accent-cyan)" : score >= 40 ? "#f59e0b" : "#ef4444";
        const fp = Math.min(10, totalFillerOccurrences * 2);

        // Sanitize improvedAnswer — never show "None", "null", etc.
        const rawIA = f.improvedAnswer || "";
        const improvedAnswer = (rawIA.trim().toLowerCase() === "none" || rawIA.trim().toLowerCase() === "null" || rawIA.trim() === "" || rawIA.length < 5) ? "" : rawIA;

        return {
          score, label, color,
          interpretation: f.interpretation || (score >= 70 ? "Good candidate" : score < 30 ? "Answer is too short — try again with a full response" : "Needs improvement"),
          scoreBreakdown: { ...(f.scoreBreakdown || { content: Math.round(score*0.4), clarity: Math.round(score*0.2), structure: Math.round(score*0.2), confidence: Math.round(score*0.2) }), fillerPenalty: fp },
          breakdown: f.breakdown || { depth: score, clarity: score, structure: score, confidence: score },
          weakestMetric: f.weakestMetric || "depth", weakestVal: f.weakestVal || score,
          whyThisScore: Array.isArray(f.whyThisScore) ? f.whyThisScore : [],
          topFixes: Array.isArray(f.topFixes) ? f.topFixes : [],
          strengths: Array.isArray(f.strengths) && f.strengths.length > 0 ? f.strengths : (score >= 55 ? ["Attempted the question"] : []),
          improvements: Array.isArray(f.improvements) ? f.improvements : [],
          improvedAnswer,
          suggestedStructure: Array.isArray(f.suggestedStructure) ? f.suggestedStructure : [],
          insight: f.insight || "",
          nextSteps: Array.isArray(f.nextSteps) ? f.nextSteps : [],
          recruiterView: f.recruiterView || { communication:"Poor", problemSolving:"Poor", technicalDepth:"None", hireDecision:"No", hireReason:"Answer too short to evaluate." },
          confidenceContentGap: f.confidenceContentGap || { hasGap: false, insight: "" },
          realInterviewRisk: f.realInterviewRisk || { level: score >= 70 ? "low" : score < 30 ? "high" : "medium", verdict: score >= 70 ? "Good chance" : score < 30 ? "Unprepared" : "Borderline", reason: score < 30 ? "Answer was too brief — provide full responses in real interviews." : "Based on answer quality." },
          questionDifficulty: f.questionDifficulty || { level: "Medium", expectedDuration: "60-90 seconds", expectedDepth: "Definition + example" },
          deliveryAnalysis: f.deliveryAnalysis || { estimatedSeconds: estSec, idealSeconds: "60-90", verdict: estSec < 30 ? "Too short" : "Good", wordsPerMinute: Math.round((wc/Math.max(estSec,1))*60) },
          weakAreaPractice: f.weakAreaPractice || { area: "depth", tip: "", practicePrompt: "" },
          ...fillerMeta,
        };
      }
    } catch { /* use local fallback below */ }

    // Local fallback (no network)
    const lower = userAnswer.toLowerCase();
    const confPhrases = ["i believe","i implemented","for example","i achieved","i built","i designed","i created"];
    const vagPhrases  = ["maybe","i think","i guess","kind of","possibly","i tried"];
    const cc = confPhrases.filter(p => lower.includes(p)).length;
    const vc = vagPhrases.filter(p => lower.includes(p)).length;
    const cs = Math.min(100, Math.max(20, cc * 18 + 40 - vc * 12));
    const ds = wc < 5 ? 10 : wc < 20 ? 20 : wc < 50 ? 45 : wc < 100 ? 65 : wc < 180 ? 82 : 90;
    const cls = wc > 300 ? 55 : wc < 10 ? 10 : Math.min(90, 50 + wc / 4);
    const ss = selectedRound === "Behavioural"
      ? (starComponents.hasSituation?25:0)+(starComponents.hasTask?25:0)+(starComponents.hasAction?25:0)+(starComponents.hasResult?25:0)
      : Math.round(Math.min(90, 40 + wc/3));
    const fp = Math.min(10, totalFillerOccurrences * 2);
    const score = Math.max(10, Math.min(97, Math.round(ds*0.4)+Math.round(cls*0.2)+Math.round(ss*0.2)+Math.round(cs*0.2)-fp));
    const label = score >= 85 ? "Excellent" : score >= 70 ? "Strong" : score >= 55 ? "Good" : score >= 40 ? "Needs Work" : "Too Brief";
    const color = score >= 85 ? "var(--accent-green)" : score >= 70 ? "var(--accent-blue)" : score >= 55 ? "var(--accent-cyan)" : score >= 40 ? "#f59e0b" : "#ef4444";
    const metrics = { depth: ds, clarity: Math.round(cls), structure: ss, confidence: Math.round(cs) };
    const wk = (Object.keys(metrics) as (keyof typeof metrics)[]).reduce((a,b) => metrics[a] < metrics[b] ? a : b);
    const strengths: string[] = [];
    const improvements: string[] = [];
    if (wc >= 80 && ds >= 65) strengths.push("Good answer depth — detailed enough.");
    if (totalFillerOccurrences === 0) strengths.push("Clean delivery — zero filler words.");
    if (!strengths.length && score >= 40) strengths.push("Attempted the question — build on this.");
    if (wc < 10) improvements.push("Answer is too brief. Aim for at least 3-5 sentences with a specific example.");
    else if (wc < 40) improvements.push("Too brief — add a specific example from your own experience.");
    if (vc > 1) improvements.push("Replace 'I think/guess/maybe' with assertive ownership language.");
    if (score < 60 && !improvements.length) improvements.push("Answer needs more structure and specific examples.");
    return {
      score, label, color,
      interpretation: score < 25 ? "Too brief to evaluate properly — provide a full answer" : score >= 70 ? "Above average" : "Needs improvement",
      scoreBreakdown: { content: Math.round(ds*0.4), clarity: Math.round(cls*0.2), structure: Math.round(ss*0.2), confidence: Math.round(cs*0.2), fillerPenalty: fp },
      breakdown: metrics, weakestMetric: wk, weakestVal: metrics[wk],
      whyThisScore: improvements, topFixes: improvements.slice(0,3),
      strengths, improvements, improvedAnswer: "",
      suggestedStructure: [], insight: "", nextSteps: [],
      recruiterView: { communication: score < 30 ? "Poor" : "Average", problemSolving: score < 30 ? "Poor" : "Average", technicalDepth: score < 30 ? "None" : "Average", hireDecision: score >= 70 ? "Maybe" : "No", hireReason: score < 30 ? "Answer too short to evaluate." : "Needs more depth." },
      confidenceContentGap: { hasGap: false, insight: "" },
      realInterviewRisk: { level: score >= 70 ? "low" : score < 30 ? "high" : "medium", verdict: score >= 70 ? "Good chance" : score < 30 ? "Unprepared" : "Borderline", reason: score < 30 ? "Answer was too short — provide full responses." : "Based on answer quality." },
      questionDifficulty: { level: "Medium", expectedDuration: "60-90s", expectedDepth: "Definition + example" },
      deliveryAnalysis: { estimatedSeconds: estSec, idealSeconds: "60-90", verdict: estSec < 30 ? "Too short" : "Good", wordsPerMinute: Math.round((wc/Math.max(estSec,1))*60) },
      weakAreaPractice: { area: wk, tip: "", practicePrompt: "" },
      ...fillerMeta,
    };
  };

  const handleSubmit = async () => {
    setAnswerError("");
    if (wordCount < MIN_WORDS) {
      setAnswerError(`Please write at least ${MIN_WORDS} words before submitting. A good answer is 3–6 sentences.`);
      return;
    }
    if (listening) stopListening();
    if (timerRef.current) clearInterval(timerRef.current);
    setAnalyzing(true);
    const feedback = await getAIFeedback(currentQ, answer);
    const item: FeedbackItem = { question: currentQ, answer, feedback, previousAnswer: retryMode ? retryPrev : undefined };
    if (retryMode) { setFeedbacks(f => { const u = [...f]; u[u.length - 1] = item; return u; }); }
    else setFeedbacks(f => [...f, item]);
    setAnalyzing(false); setSubmitted(true); setRetryMode(false);
  };

  const handleNext = () => {
    setLoadingNext(true);
    setTimeout(() => {
      setLoadingNext(false); setAnswer(""); setSubmitted(false); setAnswerError("");
      if (qIndex + 1 >= questions.length) {
        if (recording) stopRecording(); stopCamera();
        saveSession(); setPhase("results");
      } else setQIndex(i => i + 1);
    }, 400);
  };

  const saveSession = async () => {
    if (!feedbacks.length) return;
    try {
      const avgScore = Math.round(feedbacks.reduce((a, b) => a + b.feedback.score, 0) / feedbacks.length);
      await fetch("/interview/save", { method: "POST", headers: authH(), body: JSON.stringify({ round: selectedRound, questions: feedbacks.map(f => f.question), answers: feedbacks.map(f => f.answer), scores: feedbacks.map(f => f.feedback.score), avgScore, feedbacks: feedbacks.map(f => ({ score: f.feedback.score, label: f.feedback.label, strengths: f.feedback.strengths.slice(0,2), improvements: f.feedback.improvements.slice(0,2), hireDecision: f.feedback.recruiterView.hireDecision })) }) });
    } catch { /* non-blocking */ }
  };

  const handleRetry = (prev: string) => { setRetryPrev(prev); setAnswer(""); setSubmitted(false); setRetryMode(true); setTimer(120); setTimerActive(true); setAnswerError(""); };
  const resetAll = () => { setPhase("setup"); setQIndex(0); setFeedbacks([]); setAnswer(""); setSubmitted(false); setRetryMode(false); setRecordingURL(null); setCameraEnabled(false); stopCamera(); setQuestions([]); setError(""); setAnswerError(""); };

  const avgScore   = feedbacks.length ? Math.round(feedbacks.reduce((a, b) => a + b.feedback.score, 0) / feedbacks.length) : 0;
  const timerColor = timer < 30 ? "#ef4444" : timer < 60 ? "#f59e0b" : "var(--accent-green)";

  // ── SETUP ──────────────────────────────────────────────────────────────────
  if (phase === "setup") return (
    <div style={{ maxWidth: 820, margin: "0 auto" }}>
      <style>{`@keyframes spin{from{transform:rotate(0deg)}to{transform:rotate(360deg)}}`}</style>
      <div style={{ marginBottom: 22 }}>
        <div className="tag" style={{ display: "inline-flex", alignItems: "center", gap: 6, borderRadius: 100, padding: "5px 14px", marginBottom: 10, fontSize: "0.75rem" }}><Mic size={11} /> AI Interview Coach</div>
        <h1 style={{ fontFamily: "Syne,sans-serif", fontWeight: 800, fontSize: "clamp(1.7rem,3vw,2.1rem)", letterSpacing: "-0.03em", color: "var(--text-primary)", marginBottom: 7 }}>Mock Interview + <span className="gradient-text">AI Coach</span></h1>
        <p style={{ color: "var(--text-secondary)", fontSize: "0.9rem" }}>AI questions from your resume · per-answer coaching · recruiter view · delivery analysis · real interview risk.</p>
      </div>

      {resumeData && (
        <div style={{ padding: "10px 14px", borderRadius: 10, background: "rgba(0,229,160,0.05)", border: "1px solid rgba(0,229,160,0.2)", marginBottom: 16, display: "flex", alignItems: "center", gap: 8 }}>
          <CheckCircle size={13} color="var(--accent-green)" />
          <span style={{ fontSize: "0.8rem", color: "var(--text-secondary)" }}><strong style={{ color: "var(--accent-green)" }}>Resume loaded</strong> — questions will be personalised to your skills & projects.</span>
        </div>
      )}

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 20 }}>
        {ROUNDS.map(r => (
          <button key={r.id} onClick={() => setRound(r.id)} style={{ padding: "15px 16px", borderRadius: 11, cursor: "pointer", textAlign: "left", border: `2px solid ${selectedRound === r.id ? r.color : "var(--border)"}`, background: selectedRound === r.id ? `${r.color}10` : "var(--bg-card)", transition: "all 0.18s" }}>
            <div style={{ fontSize: "1.2rem", marginBottom: 7 }}>{r.icon}</div>
            <div style={{ fontFamily: "Syne,sans-serif", fontWeight: 700, fontSize: "0.88rem", color: selectedRound === r.id ? r.color : "var(--text-primary)", marginBottom: 3 }}>{r.label}</div>
            <div style={{ fontSize: "0.75rem", color: "var(--text-muted)", lineHeight: 1.5 }}>{r.desc}</div>
          </button>
        ))}
      </div>

      <div className="card" style={{ borderRadius: 12, padding: "16px 18px", marginBottom: 18 }}>
        <div style={{ fontFamily: "Syne,sans-serif", fontWeight: 700, fontSize: "0.85rem", color: "var(--text-primary)", marginBottom: 12 }}>Setup Options</div>
        <div style={{ display: "flex", gap: 9, flexWrap: "wrap" }}>
          <button onClick={() => setMicOn(v => !v)} style={{ display: "flex", alignItems: "center", gap: 7, padding: "8px 14px", borderRadius: 8, cursor: "pointer", border: `1px solid ${micOn ? "var(--accent-blue)" : "var(--border)"}`, background: micOn ? "var(--glow-blue)" : "var(--bg-primary)", color: micOn ? "var(--accent-blue)" : "var(--text-secondary)", fontWeight: 600, fontSize: "0.82rem", transition: "all 0.18s" }}>
            {micOn ? <Mic size={13} /> : <MicOff size={13} />} {micOn ? "🎙️ Voice On" : "Voice Off"}
          </button>
          <button onClick={() => setCameraEnabled(v => !v)} style={{ display: "flex", alignItems: "center", gap: 7, padding: "8px 14px", borderRadius: 8, cursor: "pointer", border: `1px solid ${cameraEnabled ? "var(--accent-purple)" : "var(--border)"}`, background: cameraEnabled ? "rgba(168,85,247,0.08)" : "var(--bg-primary)", color: cameraEnabled ? "var(--accent-purple)" : "var(--text-secondary)", fontWeight: 600, fontSize: "0.82rem", transition: "all 0.18s" }}>
            {cameraEnabled ? <Camera size={13} /> : <CameraOff size={13} />} {cameraEnabled ? "📷 Camera On" : "Camera Off"}
          </button>
        </div>
        {cameraEnabled && (
          <div style={{ marginTop: 12, display: "flex", gap: 14, alignItems: "flex-start", flexWrap: "wrap", padding: "12px", borderRadius: 9, background: "var(--bg-primary)", border: "1px solid var(--border)" }}>
            <div style={{ width: 200, height: 134, borderRadius: 9, overflow: "hidden", background: "#000", border: "2px solid var(--border)", position: "relative", flexShrink: 0 }}>
              <video ref={videoRef} autoPlay muted playsInline style={{ width: "100%", height: "100%", objectFit: "cover", transform: "scaleX(-1)", display: cameraOn ? "block" : "none" }} />
              {!cameraOn && <div style={{ position: "absolute", inset: 0, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", color: "var(--text-muted)" }}><Camera size={24} style={{ opacity: 0.3, marginBottom: 6 }} /><span style={{ fontSize: "0.72rem" }}>Preview here</span></div>}
              {cameraOn && <div style={{ position: "absolute", bottom: 5, left: 5, background: "rgba(0,229,160,0.9)", borderRadius: 100, padding: "1px 7px", fontSize: "0.6rem", fontWeight: 700, color: "#fff" }}>● LIVE</div>}
            </div>
            <div style={{ display: "flex", flexDirection: "column", gap: 8, flex: 1 }}>
              <div style={{ fontWeight: 700, fontSize: "0.8rem", color: "var(--text-primary)" }}>Test your camera</div>
              <button onClick={cameraOn ? stopCamera : startCamera} style={{ display: "flex", alignItems: "center", gap: 7, padding: "8px 14px", borderRadius: 8, cursor: "pointer", width: "fit-content", border: `1px solid ${cameraOn ? "#ef4444" : "var(--accent-green)"}`, background: cameraOn ? "rgba(239,68,68,0.08)" : "rgba(0,229,160,0.08)", color: cameraOn ? "#ef4444" : "var(--accent-green)", fontWeight: 600, fontSize: "0.78rem" }}>
                {cameraOn ? <><CameraOff size={12} /> Stop</> : <><Camera size={12} /> Start Preview</>}
              </button>
              {cameraOn && <div style={{ fontSize: "0.75rem", color: "var(--accent-green)", display: "flex", alignItems: "center", gap: 5 }}><CheckCircle size={12} /> Camera working!</div>}
              {cameraError && <div style={{ fontSize: "0.72rem", color: "#ef4444", lineHeight: 1.5 }}>⚠ {cameraError}</div>}
            </div>
          </div>
        )}
      </div>

      {/* Tip box */}
      <div style={{ padding: "10px 14px", borderRadius: 9, background: "rgba(59,142,255,0.05)", border: "1px solid rgba(59,142,255,0.15)", marginBottom: 16, fontSize: "0.8rem", color: "var(--text-secondary)", lineHeight: 1.6 }}>
        💡 <strong style={{ color: "var(--accent-blue)" }}>Tip:</strong> Give full answers (3–6 sentences). The AI evaluates depth, clarity, structure, and confidence. Short answers like "hi" or "yes" will score very low.
      </div>

      {error && <div style={{ padding: "10px 14px", borderRadius: 9, background: "rgba(239,68,68,0.07)", border: "1px solid rgba(239,68,68,0.2)", marginBottom: 14, fontSize: "0.8rem", color: "#ef4444" }}>⚠ {error}</div>}

      <button onClick={startInterview} disabled={loadingQs} className="btn-primary" style={{ padding: "12px 30px", borderRadius: 10, fontWeight: 700, fontSize: "0.92rem", display: "inline-flex", alignItems: "center", gap: 8, opacity: loadingQs ? 0.7 : 1 }}>
        <span style={{ position: "relative", zIndex: 1, display: "flex", alignItems: "center", gap: 8 }}>
          {loadingQs ? <><RefreshCw size={14} style={{ animation: "spin 1s linear infinite" }} /> Generating questions…</> : <>Begin {selectedRound} Round <ChevronRight size={15} /></>}
        </span>
      </button>
    </div>
  );

  if (phase === "loading") return (
    <div style={{ maxWidth: 520, margin: "80px auto", textAlign: "center" }}>
      <div style={{ width: 68, height: 68, borderRadius: "50%", background: "var(--glow-blue)", border: "1px solid var(--border-strong)", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 18px" }}>
        <Brain size={28} color="var(--accent-blue)" style={{ animation: "spin 1.5s linear infinite" }} />
      </div>
      <h2 style={{ fontFamily: "Syne,sans-serif", fontWeight: 700, fontSize: "1.15rem", color: "var(--text-primary)", marginBottom: 7 }}>Generating your questions…</h2>
      <p style={{ fontSize: "0.82rem", color: "var(--text-muted)" }}>AI tailoring {selectedRound} questions{resumeData ? " to your resume" : ""}…</p>
    </div>
  );

  // ── INTERVIEW ──────────────────────────────────────────────────────────────
  if (phase === "interview") return (
    <div style={{ maxWidth: cameraOn ? 1140 : 840, margin: "0 auto" }}>
      <style>{`@keyframes spin{from{transform:rotate(0deg)}to{transform:rotate(360deg)}} @keyframes analyzing{from{width:0}to{width:100%}}`}</style>
      {/* Progress + timer */}
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 10 }}>
        <div style={{ flex: 1 }}>
          <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 4 }}>
            <span style={{ fontSize: "0.75rem", color: "var(--text-muted)", fontWeight: 600 }}>{selectedRound} · Q{qIndex + 1} of {totalQs}{retryMode && <span style={{ marginLeft: 7, color: "#f59e0b", fontWeight: 700 }}>↩ Retry</span>}</span>
            <span style={{ fontSize: "0.7rem", color: "var(--text-muted)" }}>{feedbacks.length} answered</span>
          </div>
          <div style={{ height: 5, borderRadius: 3, background: "var(--border)", overflow: "hidden", display: "flex", gap: 1 }}>
            {Array.from({ length: totalQs }).map((_, i) => <div key={i} style={{ flex: 1, background: i < feedbacks.length ? "var(--accent-blue)" : i === feedbacks.length ? "rgba(59,142,255,0.25)" : "transparent", transition: "background 0.4s", borderRadius: 2 }} />)}
          </div>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 7, marginLeft: 14, flexShrink: 0 }}>
          <button onClick={() => setTimerActive(v => !v)} style={{ background: "none", border: "none", cursor: "pointer", color: "var(--text-muted)", display: "flex", padding: 0 }}>{timerActive ? <Clock size={12} /> : <StopCircle size={12} />}</button>
          <span style={{ fontFamily: "Syne,sans-serif", fontWeight: 700, fontSize: "0.95rem", color: timerColor, minWidth: 40 }}>{Math.floor(timer / 60)}:{String(timer % 60).padStart(2, "0")}</span>
          <div style={{ width: 44, height: 4, borderRadius: 2, background: "var(--border)", overflow: "hidden" }}><div style={{ width: `${(timer / 120) * 100}%`, height: "100%", background: timerColor, transition: "width 1s linear" }} /></div>
        </div>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: cameraOn ? "1fr 282px" : "1fr", gap: 14, alignItems: "start" }}>
        <div>
          {/* Question */}
          <div className="card" style={{ borderRadius: 15, padding: "20px 24px", marginBottom: 10 }}>
            <div style={{ display: "flex", gap: 11 }}>
              <div style={{ width: 36, height: 36, borderRadius: 9, background: "linear-gradient(135deg,var(--accent-blue),var(--accent-cyan))", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}><Brain size={15} color="white" /></div>
              <div>
                <div style={{ fontSize: "0.65rem", fontWeight: 700, color: "var(--accent-blue)", textTransform: "uppercase", letterSpacing: "0.08em", marginBottom: 6 }}>PrepWise Interviewer</div>
                <p style={{ fontSize: "0.97rem", lineHeight: 1.75, color: "var(--text-primary)", fontWeight: 500, margin: 0 }}>{currentQ}</p>
              </div>
            </div>
          </div>

          {/* Body */}
          {analyzing ? (
            <div className="card" style={{ borderRadius: 15, padding: "36px 22px", textAlign: "center" }}>
              <div style={{ width: 48, height: 48, borderRadius: "50%", background: "var(--glow-blue)", border: "1px solid var(--border-strong)", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 14px" }}><Brain size={22} color="var(--accent-blue)" /></div>
              <div style={{ fontFamily: "Syne,sans-serif", fontWeight: 700, fontSize: "0.95rem", color: "var(--text-primary)", marginBottom: 5 }}>AI analysing your response…</div>
              <div style={{ fontSize: "0.78rem", color: "var(--text-muted)", marginBottom: 18 }}>Checking depth · recruiter view · risk · delivery</div>
              <div style={{ maxWidth: 280, margin: "0 auto", height: 3, borderRadius: 2, background: "var(--border)", overflow: "hidden" }}><div style={{ height: "100%", background: "linear-gradient(90deg,var(--accent-blue),var(--accent-cyan))", animation: "analyzing 2.5s ease forwards" }} /></div>
            </div>
          ) : loadingNext ? (
            <div className="card" style={{ borderRadius: 15, padding: "28px", textAlign: "center" }}><span style={{ fontSize: "0.85rem", color: "var(--text-muted)" }}>Loading next question…</span></div>
          ) : !submitted ? (
            <div className="card" style={{ borderRadius: 15, padding: "18px 20px" }}>
              <div style={{ display: "flex", gap: 10, alignItems: "flex-start" }}>
                <div style={{ width: 32, height: 32, borderRadius: 8, background: "var(--bg-primary)", border: "1px solid var(--border)", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}><User size={14} color="var(--text-muted)" /></div>
                <div style={{ flex: 1 }}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 9 }}>
                    <span style={{ fontSize: "0.68rem", fontWeight: 700, color: "var(--text-muted)", textTransform: "uppercase", letterSpacing: "0.08em" }}>Your Answer</span>
                    {micOn && (
                      <button onClick={listening ? stopListening : startListening} style={{ display: "flex", alignItems: "center", gap: 5, padding: "5px 10px", borderRadius: 7, cursor: "pointer", border: `1px solid ${listening ? "#ef4444" : "var(--accent-blue)"}`, background: listening ? "rgba(239,68,68,0.08)" : "var(--glow-blue)", color: listening ? "#ef4444" : "var(--accent-blue)", fontSize: "0.72rem", fontWeight: 600 }}>
                        {listening ? <><VolumeX size={11} /> Stop</> : <><Volume2 size={11} /> Speak</>}
                        {listening && <span style={{ width: 5, height: 5, borderRadius: "50%", background: "#ef4444" }} />}
                      </button>
                    )}
                  </div>
                  {retryMode && retryPrev && <div style={{ padding: "7px 10px", borderRadius: 7, background: "rgba(245,158,11,0.05)", border: "1px solid rgba(245,158,11,0.18)", marginBottom: 8, fontSize: "0.72rem", color: "var(--text-muted)" }}><span style={{ color: "#f59e0b", fontWeight: 700 }}>Previous: </span>{retryPrev.slice(0, 100)}…</div>}
                  <textarea
                    value={answer} onChange={e => { setAnswer(e.target.value); if (answerError) setAnswerError(""); }}
                    placeholder={selectedRound === "Behavioural" ? "STAR: Situation → Task → Action → Result…\n\nTip: Aim for 80–150 words with a real example from your experience." : "Type a complete answer — aim for 3–6 sentences with a real example.\n\nThe AI evaluates your depth, clarity, structure, and confidence."}
                    rows={cameraOn ? 6 : 7}
                    style={{ width: "100%", background: "var(--bg-primary)", border: `1px solid ${answerError ? "#ef4444" : "var(--border)"}`, borderRadius: 9, padding: "11px 13px", color: "var(--text-primary)", fontSize: "0.88rem", lineHeight: 1.7, resize: "vertical", outline: "none", fontFamily: "DM Sans,sans-serif", transition: "border-color 0.2s" }}
                    onFocus={e => (e.currentTarget.style.borderColor = answerError ? "#ef4444" : "var(--accent-blue)")}
                    onBlur={e => (e.currentTarget.style.borderColor = answerError ? "#ef4444" : "var(--border)")}
                  />
                  {answerError && (
                    <div style={{ display: "flex", gap: 6, alignItems: "flex-start", marginTop: 7, padding: "8px 10px", borderRadius: 7, background: "rgba(239,68,68,0.07)", border: "1px solid rgba(239,68,68,0.2)" }}>
                      <AlertTriangle size={12} color="#ef4444" style={{ flexShrink: 0, marginTop: 1 }} />
                      <span style={{ fontSize: "0.78rem", color: "#ef4444", lineHeight: 1.5 }}>{answerError}</span>
                    </div>
                  )}
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: 9 }}>
                    <div style={{ display: "flex", gap: 9, alignItems: "center" }}>
                      <span style={{ fontSize: "0.7rem", color: wordCount >= 40 ? "var(--accent-green)" : wordCount >= 15 ? "#f59e0b" : "var(--text-muted)" }}>{wordCount} words</span>
                      {wordCount < 15 && wordCount > 0 && <span style={{ fontSize: "0.65rem", color: "#f59e0b" }}>Aim for 60+ words</span>}
                      {wordCount >= 60 && <span style={{ fontSize: "0.65rem", color: "var(--accent-green)" }}>✓ Good length</span>}
                    </div>
                    <button onClick={handleSubmit} disabled={!answer.trim()} className="btn-primary" style={{ padding: "9px 22px", borderRadius: 9, fontWeight: 700, fontSize: "0.85rem", opacity: !answer.trim() ? 0.4 : 1, display: "flex", alignItems: "center", gap: 6 }}>
                      <span style={{ position: "relative", zIndex: 1, display: "flex", alignItems: "center", gap: 6 }}>Submit <Send size={12} /></span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ) : (() => {
            const last = feedbacks[feedbacks.length - 1]; const fb = last.feedback;
            const fillerParts = highlightFillers(last.answer); const wk = fb.weakestMetric as keyof typeof fb.breakdown;
            return (
              <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>

                {/* Too short warning */}
                {fb.isTooShort && (
                  <div style={{ padding: "12px 16px", borderRadius: 11, background: "rgba(239,68,68,0.07)", border: "1px solid rgba(239,68,68,0.25)", display: "flex", gap: 10, alignItems: "flex-start" }}>
                    <AlertOctagon size={15} color="#ef4444" style={{ flexShrink: 0, marginTop: 1 }} />
                    <div>
                      <div style={{ fontWeight: 700, fontSize: "0.85rem", color: "#ef4444", marginBottom: 3 }}>Answer too short</div>
                      <div style={{ fontSize: "0.78rem", color: "var(--text-secondary)", lineHeight: 1.6 }}>
                        You answered with only {fb.wordCount} word{fb.wordCount !== 1 ? "s" : ""}. In a real interview, a 1-word or very short answer would immediately disqualify you. See the model answer below to understand what a good response looks like, then hit <strong>Retry</strong>.
                      </div>
                    </div>
                  </div>
                )}

                {/* Score card */}
                <div className="card" style={{ borderRadius: 15, padding: "18px 22px" }}>
                  <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", marginBottom: 12 }}>
                    <div><div style={{ fontFamily: "Syne,sans-serif", fontWeight: 700, fontSize: "0.95rem", color: "var(--text-primary)", marginBottom: 2 }}>AI Coach Feedback</div><div style={{ fontSize: "0.72rem", color: "var(--text-muted)" }}>{fb.wordCount} words · {fb.speakingPaceNote}</div></div>
                    <div style={{ textAlign: "right" }}>
                      <div style={{ display: "flex", alignItems: "baseline", gap: 3, justifyContent: "flex-end" }}><div style={{ fontFamily: "Syne,sans-serif", fontWeight: 800, fontSize: "2.4rem", color: fb.color, lineHeight: 1 }}>{fb.score}</div><div style={{ fontSize: "0.8rem", color: "var(--text-muted)" }}>/100</div></div>
                      <div style={{ fontSize: "0.7rem", color: fb.color, fontWeight: 700, marginTop: 2 }}>{fb.label}</div>
                      <div style={{ fontSize: "0.62rem", color: "var(--text-muted)", maxWidth: 180, textAlign: "right", marginTop: 1 }}>{fb.interpretation}</div>
                    </div>
                  </div>
                  <div style={{ height: 4, borderRadius: 2, background: "var(--border)", marginBottom: 13, overflow: "hidden" }}><div style={{ width: `${fb.score}%`, height: "100%", background: fb.color, borderRadius: 2, transition: "width 0.8s ease" }} /></div>
                  {/* Score breakdown */}
                  <div style={{ padding: "10px 12px", borderRadius: 9, background: "var(--bg-primary)", border: "1px solid var(--border)", marginBottom: 12 }}>
                    <div style={{ fontSize: "0.66rem", fontWeight: 700, color: "var(--text-muted)", marginBottom: 8, display: "flex", alignItems: "center", gap: 5 }}><Info size={10} /> Score breakdown</div>
                    {[{ label:"Content Quality", val:fb.scoreBreakdown.content, max:40, color:"var(--accent-blue)" },{ label:"Clarity", val:fb.scoreBreakdown.clarity, max:20, color:"var(--accent-cyan)" },{ label:"Structure", val:fb.scoreBreakdown.structure, max:20, color:"var(--accent-purple)" },{ label:"Confidence", val:fb.scoreBreakdown.confidence, max:20, color:"var(--accent-green)" }].map(s => (
                      <div key={s.label} style={{ display: "flex", alignItems: "center", gap: 7, marginBottom: 5 }}>
                        <div style={{ width: 110, fontSize: "0.66rem", color: "var(--text-muted)", flexShrink: 0 }}>{s.label} <span style={{ color: "var(--text-muted)" }}>/{s.max}</span></div>
                        <div style={{ flex: 1, height: 4, borderRadius: 2, background: "var(--border)", overflow: "hidden" }}><div style={{ width: `${(s.val / s.max) * 100}%`, height: "100%", background: s.color, borderRadius: 2, transition: "width 0.5s" }} /></div>
                        <div style={{ fontSize: "0.66rem", fontWeight: 700, color: s.color, width: 30, textAlign: "right" }}>{s.val}</div>
                      </div>
                    ))}
                    {(fb.scoreBreakdown.fillerPenalty || 0) > 0 && (
                      <div style={{ display: "flex", alignItems: "center", gap: 7 }}>
                        <div style={{ width: 110, fontSize: "0.66rem", color: "#ef4444", flexShrink: 0 }}>Filler Penalty</div>
                        <div style={{ flex: 1, height: 4, borderRadius: 2, background: "var(--border)", overflow: "hidden" }}><div style={{ width: `${((fb.scoreBreakdown.fillerPenalty||0)/10)*100}%`, height: "100%", background: "#ef4444", borderRadius: 2 }} /></div>
                        <div style={{ fontSize: "0.66rem", fontWeight: 700, color: "#ef4444", width: 30, textAlign: "right" }}>-{fb.scoreBreakdown.fillerPenalty}</div>
                      </div>
                    )}
                  </div>
                  {/* Metric tiles */}
                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr 1fr", gap: 7 }}>
                    {(["depth","clarity","structure","confidence"] as const).map(k => { const v = fb.breakdown[k]; const isWeak = k === wk; return (
                      <div key={k} style={{ padding: "9px 7px", borderRadius: 8, background: isWeak ? "rgba(239,68,68,0.04)" : "var(--bg-primary)", border: `1px solid ${isWeak ? "rgba(239,68,68,0.3)" : "var(--border)"}`, textAlign: "center", position: "relative" }}>
                        {isWeak && <div style={{ position: "absolute", top: -5, left: "50%", transform: "translateX(-50%)", background: "#ef4444", borderRadius: 100, padding: "1px 6px", fontSize: "0.5rem", fontWeight: 700, color: "#fff", whiteSpace: "nowrap" }}>⚠ Weakest</div>}
                        <div style={{ fontFamily: "Syne,sans-serif", fontWeight: 800, fontSize: "1rem", color: v >= 70 ? "var(--accent-green)" : isWeak ? "#ef4444" : "#f59e0b", marginTop: isWeak ? 4 : 0 }}>{v}</div>
                        <div style={{ fontSize: "0.58rem", color: "var(--text-muted)", fontWeight: 600, marginBottom: 1, textTransform: "capitalize" }}>{k}</div>
                        <div style={{ fontSize: "0.55rem", color: v >= 70 ? "var(--accent-green)" : isWeak ? "#ef4444" : "#f59e0b", fontWeight: 600 }}>{metricLabel(k, v)}</div>
                      </div>
                    ); })}
                  </div>
                </div>

                {/* Risk + difficulty */}
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
                  <div style={{ padding: "13px 15px", borderRadius: 11, background: riskBg(fb.realInterviewRisk.level), border: `1px solid ${riskColor(fb.realInterviewRisk.level)}30` }}>
                    <div style={{ display: "flex", alignItems: "center", gap: 5, marginBottom: 7 }}><Flame size={12} color={riskColor(fb.realInterviewRisk.level)} /><span style={{ fontFamily: "Syne,sans-serif", fontWeight: 700, fontSize: "0.75rem", color: "var(--text-primary)" }}>Real Interview Risk</span></div>
                    <div style={{ fontFamily: "Syne,sans-serif", fontWeight: 800, fontSize: "0.95rem", color: riskColor(fb.realInterviewRisk.level), marginBottom: 3 }}>{fb.realInterviewRisk.verdict}</div>
                    <div style={{ fontSize: "0.68rem", color: "var(--text-muted)", lineHeight: 1.5 }}>{fb.realInterviewRisk.reason}</div>
                  </div>
                  <div style={{ padding: "13px 15px", borderRadius: 11, background: "var(--bg-primary)", border: "1px solid var(--border)" }}>
                    <div style={{ display: "flex", alignItems: "center", gap: 5, marginBottom: 7 }}><Gauge size={12} color="var(--accent-blue)" /><span style={{ fontFamily: "Syne,sans-serif", fontWeight: 700, fontSize: "0.75rem", color: "var(--text-primary)" }}>Difficulty</span></div>
                    <div style={{ fontFamily: "Syne,sans-serif", fontWeight: 800, fontSize: "0.95rem", color: "var(--accent-blue)", marginBottom: 3 }}>{fb.questionDifficulty.level}</div>
                    <div style={{ fontSize: "0.68rem", color: "var(--text-muted)" }}>Expected: {fb.questionDifficulty.expectedDuration}</div>
                  </div>
                </div>

                {/* Recruiter view — uses sanitizeRating to handle "None", "Poor" etc correctly */}
                <div className="card" style={{ borderRadius: 13, padding: "14px 16px", border: `1px solid ${hireColor(fb.recruiterView.hireDecision)}25` }}>
                  <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 11 }}>
                    <div style={{ display: "flex", alignItems: "center", gap: 6, fontFamily: "Syne,sans-serif", fontWeight: 700, fontSize: "0.78rem", color: "var(--text-primary)" }}><UserCheck size={12} color="var(--accent-purple)" /> Recruiter View</div>
                    <div style={{ padding: "2px 10px", borderRadius: 100, background: `${hireColor(fb.recruiterView.hireDecision)}15`, border: `1px solid ${hireColor(fb.recruiterView.hireDecision)}40` }}>
                      <span style={{ fontSize: "0.7rem", fontWeight: 800, color: hireColor(fb.recruiterView.hireDecision) }}>Hire: {fb.recruiterView.hireDecision}</span>
                    </div>
                  </div>
                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 7, marginBottom: 9 }}>
                    {[{ label:"Communication", val: fb.recruiterView.communication }, { label:"Problem Solving", val: fb.recruiterView.problemSolving }, { label:"Tech Depth", val: fb.recruiterView.technicalDepth }].map(m => {
                      const r = sanitizeRating(m.val);
                      return (
                        <div key={m.label} style={{ padding:"8px 9px", borderRadius:7, background:"var(--bg-primary)", border:"1px solid var(--border)", textAlign:"center" }}>
                          <div style={{ fontFamily:"Syne,sans-serif", fontWeight:700, fontSize:"0.75rem", color:r.color, marginBottom:2 }}>{r.display}</div>
                          <div style={{ fontSize:"0.58rem", color:"var(--text-muted)" }}>{m.label}</div>
                        </div>
                      );
                    })}
                  </div>
                  <div style={{ padding: "7px 10px", borderRadius: 7, background: "var(--bg-primary)", border: "1px solid var(--border)", fontSize: "0.74rem", color: "var(--text-secondary)", lineHeight: 1.55 }}>💬 {fb.recruiterView.hireReason}</div>
                </div>

                {/* Your answer + fillers */}
                <div className="card" style={{ borderRadius: 13, padding: "14px 16px" }}>
                  <div style={{ fontFamily: "Syne,sans-serif", fontWeight: 700, fontSize: "0.78rem", color: "var(--text-primary)", marginBottom: 8, display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                    <div style={{ display: "flex", alignItems: "center", gap: 6 }}><User size={12} /> Your Answer</div>
                    <span style={{ fontSize: "0.65rem", color: fb.fillerJudgmentColor, fontWeight: 700 }}>Fillers: {fb.totalFillerOccurrences} — {fb.fillerJudgment}</span>
                  </div>
                  <div style={{ fontSize: "0.78rem", color: "var(--text-secondary)", lineHeight: 1.75, padding: "9px 11px", borderRadius: 7, background: "var(--bg-primary)", border: "1px solid var(--border)" }}>
                    {fb.totalFillerOccurrences > 0
                      ? fillerParts.map((p, i) => <span key={i} style={p.isFiller ? { background: "rgba(245,158,11,0.25)", color: "#f59e0b", borderRadius: 3, padding: "0 2px", fontWeight: 700 } : {}}>{p.text}</span>)
                      : last.answer}
                  </div>
                  {fb.totalFillerOccurrences > 0 && (
                    <div style={{ display: "flex", gap: 5, flexWrap: "wrap", marginTop: 7 }}>
                      {Object.entries(fb.fillerWords).map(([w, c]) => <span key={w} style={{ padding: "2px 8px", borderRadius: 100, background: "rgba(245,158,11,0.1)", color: "#f59e0b", fontSize: "0.65rem", fontWeight: 700, border: "1px solid rgba(245,158,11,0.2)" }}>"{w}" ×{c}</span>)}
                    </div>
                  )}
                </div>

                {/* Strengths + improvements */}
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
                  <div className="card" style={{ borderRadius: 13, padding: "14px 16px" }}>
                    <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 10, fontFamily: "Syne,sans-serif", fontWeight: 700, fontSize: "0.78rem", color: "var(--accent-green)" }}><ThumbsUp size={12} /> What you did well</div>
                    {fb.strengths.length > 0
                      ? fb.strengths.map((s, i) => <div key={i} style={{ display:"flex",gap:6,marginBottom:6,alignItems:"flex-start" }}><CheckCircle size={10} color="var(--accent-green)" style={{flexShrink:0,marginTop:2}}/><span style={{fontSize:"0.74rem",color:"var(--text-secondary)",lineHeight:1.5}}>{s}</span></div>)
                      : <div style={{ fontSize: "0.74rem", color: "var(--text-muted)", fontStyle: "italic" }}>Give a fuller answer to receive positive feedback.</div>
                    }
                  </div>
                  <div className="card" style={{ borderRadius: 13, padding: "14px 16px" }}>
                    <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 10, fontFamily: "Syne,sans-serif", fontWeight: 700, fontSize: "0.78rem", color: "#f59e0b" }}><ThumbsDown size={12} /> To improve</div>
                    {fb.improvements.length > 0
                      ? fb.improvements.slice(0,3).map((s, i) => <div key={i} style={{ display:"flex",gap:6,marginBottom:6,alignItems:"flex-start" }}><AlertTriangle size={10} color="#f59e0b" style={{flexShrink:0,marginTop:2}}/><span style={{fontSize:"0.74rem",color:"var(--text-secondary)",lineHeight:1.5}}>{s}</span></div>)
                      : <div style={{fontSize:"0.74rem",color:"var(--text-muted)",display:"flex",gap:5}}><CheckCircle size={10} color="var(--accent-green)"/> Great answer!</div>
                    }
                  </div>
                </div>

                {/* STAR */}
                {selectedRound === "Behavioural" && fb.starComponents && (
                  <div className="card" style={{ borderRadius: 11, padding: "10px 14px" }}>
                    <div style={{ display: "flex", gap: 7, flexWrap: "wrap", alignItems: "center" }}>
                      <span style={{ fontSize: "0.65rem", fontWeight: 700, color: "var(--text-muted)" }}>STAR method:</span>
                      {(["Situation","Task","Action","Result"] as const).map((part, i) => {
                        const keys = ["hasSituation","hasTask","hasAction","hasResult"] as const;
                        const found = fb.starComponents![keys[i]];
                        return <span key={part} style={{ padding:"2px 8px",borderRadius:100,fontSize:"0.65rem",fontWeight:700,background:found?"rgba(0,229,160,0.1)":"rgba(239,68,68,0.07)",border:`1px solid ${found?"rgba(0,229,160,0.3)":"rgba(239,68,68,0.2)"}`,color:found?"var(--accent-green)":"#ef4444" }}>{found?"✓":"✗"} {part}</span>;
                      })}
                    </div>
                  </div>
                )}

                {/* Model answer — always show when available, with helpful header */}
                {fb.improvedAnswer ? (
                  <div className="card" style={{ borderRadius: 13, padding: "16px 18px", border: "1px solid rgba(0,229,160,0.25)" }}>
                    <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 10, fontFamily: "Syne,sans-serif", fontWeight: 700, fontSize: "0.82rem", color: "var(--accent-green)" }}>
                      <Sparkles size={13} />
                      {fb.isTooShort ? "Model Answer — What a good response looks like" : "AI-Improved Answer"}
                    </div>
                    {fb.isTooShort && (
                      <div style={{ fontSize: "0.72rem", color: "var(--text-muted)", marginBottom: 9, padding: "5px 9px", borderRadius: 6, background: "rgba(0,229,160,0.04)", border: "1px solid rgba(0,229,160,0.12)" }}>
                        📚 Study this structure, then click <strong>Retry</strong> to answer in your own words.
                      </div>
                    )}
                    <div style={{ fontSize: "0.82rem", color: "var(--text-secondary)", lineHeight: 1.8, padding: "12px 14px", borderRadius: 8, background: "rgba(0,229,160,0.03)", border: "1px solid rgba(0,229,160,0.12)", fontStyle: "normal" }}>
                      {fb.improvedAnswer}
                    </div>
                  </div>
                ) : fb.isTooShort ? (
                  // Fallback if AI didn't return improved answer for short answers
                  <div className="card" style={{ borderRadius: 13, padding: "16px 18px", border: "1px solid rgba(245,158,11,0.25)" }}>
                    <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 8, fontFamily: "Syne,sans-serif", fontWeight: 700, fontSize: "0.82rem", color: "#f59e0b" }}>
                      <Lightbulb size={13} /> How to answer this question
                    </div>
                    <div style={{ fontSize: "0.8rem", color: "var(--text-secondary)", lineHeight: 1.75 }}>
                      A strong answer should: <br/>
                      1. Define or explain the core concept clearly<br/>
                      2. Give a real-world example or use case<br/>
                      3. Mention how you have used or encountered it<br/>
                      4. Explain the trade-offs or when to use it<br/>
                      <br/>
                      Aim for 60–120 words. Hit <strong>Retry</strong> and try again.
                    </div>
                  </div>
                ) : null}

                {fb.insight && (
                  <div style={{ padding: "9px 13px", borderRadius: 9, background: "rgba(139,92,246,0.06)", border: "1px solid rgba(139,92,246,0.18)", display: "flex", gap: 7, alignItems: "flex-start" }}>
                    <Brain size={12} color="var(--accent-purple)" style={{ flexShrink: 0, marginTop: 1 }} />
                    <div style={{ fontSize: "0.74rem", color: "var(--text-secondary)", lineHeight: 1.6 }}><strong style={{ color: "var(--accent-purple)" }}>AI Insight: </strong>{fb.insight}</div>
                  </div>
                )}

                {/* Actions */}
                <div style={{ display: "flex", gap: 9, flexWrap: "wrap" }}>
                  <button onClick={handleNext} className="btn-primary" style={{ padding: "11px 26px", borderRadius: 10, fontWeight: 700, fontSize: "0.88rem", flex: 1 }}>
                    <span style={{ position: "relative", zIndex: 1, display: "flex", alignItems: "center", justifyContent: "center", gap: 6 }}>{qIndex + 1 >= questions.length ? "View Final Report" : "Next Question"} <ArrowRight size={13} /></span>
                  </button>
                  <button onClick={() => handleRetry(last.answer)} className="btn-ghost" style={{ padding: "11px 16px", borderRadius: 10, fontWeight: 600, fontSize: "0.85rem", display: "flex", alignItems: "center", gap: 6 }}><RotateCcw size={12} /> Retry</button>
                </div>
              </div>
            );
          })()}
        </div>

        {/* Camera panel */}
        {cameraOn && (
          <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
            <div className="card" style={{ borderRadius: 15, padding: "11px", overflow: "hidden" }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 7 }}>
                <span style={{ fontWeight: 700, fontSize: "0.75rem", color: "var(--text-primary)", display: "flex", alignItems: "center", gap: 4 }}><Activity size={11} color="var(--accent-green)" /> Live Feed</span>
                <div style={{ display: "flex", gap: 4 }}>
                  <button onClick={recording ? stopRecording : startRecording} style={{ display:"flex",alignItems:"center",gap:2,padding:"2px 7px",borderRadius:5,border:`1px solid ${recording?"#ef4444":"var(--border)"}`,background:recording?"rgba(239,68,68,0.1)":"transparent",color:recording?"#ef4444":"var(--text-muted)",fontSize:"0.6rem",fontWeight:700,cursor:"pointer" }}>{recording ? <><VideoOff size={8}/> Stop</> : <><Video size={8}/> Rec</>}</button>
                  <button onClick={stopCamera} style={{ padding:"2px 5px",borderRadius:5,border:"1px solid var(--border)",background:"transparent",color:"var(--text-muted)",cursor:"pointer",fontSize:"0.62rem" }}>✕</button>
                </div>
              </div>
              <div style={{ width:"100%",aspectRatio:"4/3",borderRadius:9,overflow:"hidden",background:"#111",position:"relative" }}>
                <video ref={videoRef} autoPlay muted playsInline style={{ width:"100%",height:"100%",objectFit:"cover",transform:"scaleX(-1)",display:"block" }} />
                {recording && <div style={{ position:"absolute",top:5,left:5,display:"flex",alignItems:"center",gap:3,background:"rgba(239,68,68,0.92)",borderRadius:100,padding:"2px 6px" }}><div style={{width:4,height:4,borderRadius:"50%",background:"#fff"}}/><span style={{fontSize:"0.56rem",fontWeight:700,color:"#fff"}}>REC</span></div>}
                <div style={{ position:"absolute",bottom:5,right:5,background:"rgba(0,0,0,0.7)",borderRadius:6,padding:"2px 6px",fontSize:"0.62rem",color:"#fff" }}>{emLabel==="Confident"?"😊":emLabel==="Nervous"?"😰":"😐"} {emLabel}</div>
              </div>
            </div>
            <div className="card" style={{ borderRadius: 13, padding: "13px 14px" }}>
              <div style={{ fontWeight: 700, fontSize: "0.75rem", color: "var(--text-primary)", marginBottom: 10, display: "flex", alignItems: "center", gap: 4 }}><Smile size={11} color="var(--accent-blue)" /> Emotion Tracker</div>
              <div style={{ display: "flex", alignItems: "center", gap: 9, marginBottom: 10 }}>
                <div style={{ position: "relative", width: 46, height: 46, flexShrink: 0 }}>
                  <svg width={46} height={46} viewBox="0 0 46 46"><circle cx={23} cy={23} r={18} fill="none" stroke="var(--border)" strokeWidth={5}/><circle cx={23} cy={23} r={18} fill="none" stroke={emColor} strokeWidth={5} strokeLinecap="round" strokeDasharray={`${(confScore/100)*113.1} 113.1`} strokeDashoffset={28.3} style={{transition:"stroke-dasharray 1s ease"}}/></svg>
                  <div style={{ position:"absolute",inset:0,display:"flex",alignItems:"center",justifyContent:"center",fontSize:"0.62rem",fontWeight:800,color:"var(--text-primary)" }}>{confScore}%</div>
                </div>
                <div><div style={{ fontWeight:700,fontSize:"0.78rem",color:emColor }}>{emLabel}</div><div style={{ fontSize:"0.6rem",color:"var(--text-muted)" }}>Confidence</div></div>
              </div>
              {[{icon:<Eye size={9}/>,label:"Eye Contact",val:`${eyeContactPct}%`,good:eyeContactPct>=70},{icon:<Volume2 size={9}/>,label:"Pace",val:speakingPace,good:speakingPace==="Good"||speakingPace==="Ideal"},{icon:<StopCircle size={9}/>,label:"Pauses",val:pauseLevel,good:pauseLevel==="Normal"}].map(m => (
                <div key={m.label} style={{ display:"flex",justifyContent:"space-between",alignItems:"center",padding:"4px 7px",borderRadius:6,background:"var(--bg-primary)",border:"1px solid var(--border)",marginBottom:5 }}>
                  <div style={{ display:"flex",alignItems:"center",gap:4,fontSize:"0.65rem",color:"var(--text-muted)" }}>{m.icon} {m.label}</div>
                  <span style={{ fontSize:"0.65rem",fontWeight:700,color:m.good?"var(--accent-green)":"#f59e0b" }}>{m.val}</span>
                </div>
              ))}
              {[{label:"Happy",val:happyPct,color:"#10B981"},{label:"Neutral",val:neutralPct,color:"#A855F7"},{label:"Nervous",val:nervousPct,color:"#EF4444"}].map(e => (
                <div key={e.label} style={{ marginBottom: 5 }}>
                  <div style={{ display:"flex",justifyContent:"space-between",marginBottom:2 }}><span style={{fontSize:"0.6rem",color:"var(--text-muted)"}}>{e.label}</span><span style={{fontSize:"0.6rem",color:e.color,fontWeight:700}}>{e.val}%</span></div>
                  <div style={{ height:3,background:"var(--border)",borderRadius:3,overflow:"hidden" }}><div style={{height:"100%",width:`${e.val}%`,background:e.color,borderRadius:3,transition:"width 1s ease"}}/></div>
                </div>
              ))}
              <div style={{ marginTop:7,padding:"5px 8px",borderRadius:6,background:"rgba(59,142,255,0.06)",border:"1px solid rgba(59,142,255,0.12)",fontSize:"0.63rem",color:"var(--text-secondary)",lineHeight:1.5 }}>💡 {bodyTip}</div>
            </div>
          </div>
        )}
      </div>
    </div>
  );

  // ── RESULTS ─────────────────────────────────────────────────────────────────
  const interpretation = avgScore >= 85 ? "Interview-ready 🌟" : avgScore >= 70 ? "Strong candidate 💪" : avgScore >= 55 ? "Good — needs practice 📚" : "Needs significant practice 🔥";
  const allStrengths    = [...new Set(feedbacks.flatMap(f => f.feedback.strengths))].filter(Boolean).slice(0, 5);
  const allImprovements = [...new Set(feedbacks.flatMap(f => f.feedback.improvements))].filter(Boolean).slice(0, 5);

  const downloadReport = () => {
    downloadMockInterviewPDF({
      round: selectedRound,
      avgScore,
      interpretation,
      strengths: allStrengths,
      improvements: allImprovements,
      feedbacks,
    });
  };

  return (
    <div style={{ maxWidth: 800, margin: "0 auto" }}>
      <div style={{ textAlign: "center", marginBottom: 26 }}>
        <div style={{ width:68,height:68,borderRadius:"50%",margin:"0 auto 12px",background:avgScore>=70?"rgba(0,229,160,0.15)":"rgba(245,158,11,0.12)",border:`2px solid ${avgScore>=70?"var(--accent-green)":"#f59e0b"}`,display:"flex",alignItems:"center",justifyContent:"center" }}>
          {avgScore>=70?<CheckCircle size={28} color="var(--accent-green)"/>:<AlertTriangle size={28} color="#f59e0b"/>}
        </div>
        <h1 style={{ fontFamily:"Syne,sans-serif",fontWeight:800,fontSize:"1.7rem",color:"var(--text-primary)",marginBottom:5 }}>{selectedRound} — Final Report</h1>
        <div style={{ fontFamily:"Syne,sans-serif",fontWeight:800,fontSize:"3.5rem",color:avgScore>=70?"var(--accent-green)":"#f59e0b",lineHeight:1,marginBottom:3 }}>{avgScore}<span style={{fontSize:"1.1rem",color:"var(--text-muted)"}}>/100</span></div>
        <div style={{ fontSize:"0.9rem",color:avgScore>=70?"var(--accent-green)":"#f59e0b",fontWeight:700,marginBottom:3 }}>{interpretation}</div>
        <div style={{ fontSize:"0.78rem",color:"var(--text-muted)" }}>{feedbacks.length} questions answered</div>
      </div>

      {recordingURL && (
        <div className="card" style={{ borderRadius:13,padding:"13px 16px",marginBottom:12,display:"flex",alignItems:"center",gap:12 }}>
          <Video size={16} color="var(--accent-blue)"/>
          <div style={{flex:1}}><div style={{fontWeight:700,fontSize:"0.85rem",color:"var(--text-primary)",marginBottom:1}}>Session Recording Ready</div><div style={{fontSize:"0.72rem",color:"var(--text-muted)"}}>Review your expressions and body language</div></div>
          <a href={recordingURL} download="prepwise-interview.webm" style={{padding:"6px 14px",borderRadius:7,background:"var(--glow-blue)",border:"1px solid var(--border-strong)",color:"var(--accent-blue)",fontWeight:600,fontSize:"0.77rem",textDecoration:"none"}}>Download</a>
        </div>
      )}

      <div style={{ display:"grid",gridTemplateColumns:"1fr 1fr 1fr 1fr",gap:11,marginBottom:14 }}>
        {[{label:"Depth",val:Math.round(feedbacks.reduce((a,f)=>a+f.feedback.breakdown.depth,0)/feedbacks.length),icon:<BarChart2 size={12}/>,color:"var(--accent-blue)"},{label:"Clarity",val:Math.round(feedbacks.reduce((a,f)=>a+f.feedback.breakdown.clarity,0)/feedbacks.length),icon:<MessageSquare size={12}/>,color:"var(--accent-cyan)"},{label:"Structure",val:Math.round(feedbacks.reduce((a,f)=>a+f.feedback.breakdown.structure,0)/feedbacks.length),icon:<TrendingUp size={12}/>,color:"var(--accent-purple)"},{label:"Confidence",val:Math.round(feedbacks.reduce((a,f)=>a+f.feedback.breakdown.confidence,0)/feedbacks.length),icon:<Zap size={12}/>,color:"var(--accent-green)"}].map(m => (
          <div key={m.label} className="card" style={{ borderRadius:11,padding:"13px",textAlign:"center" }}>
            <div style={{color:m.color,display:"flex",justifyContent:"center",marginBottom:4}}>{m.icon}</div>
            <div style={{fontFamily:"Syne,sans-serif",fontWeight:800,fontSize:"1.4rem",color:m.color}}>{m.val}</div>
            <div style={{fontSize:"0.65rem",color:"var(--text-muted)",fontWeight:600,marginBottom:1}}>{m.label}</div>
            <div style={{fontSize:"0.58rem",color:m.val>=70?"var(--accent-green)":m.val>=50?"var(--accent-blue)":"#f59e0b",fontWeight:600}}>{metricLabel(m.label.toLowerCase(),m.val)}</div>
          </div>
        ))}
      </div>

      <div style={{ display:"grid",gridTemplateColumns:"1fr 1fr",gap:12,marginBottom:12 }}>
        <div className="card" style={{ borderRadius:13,padding:"16px 18px" }}>
          <div style={{ fontFamily:"Syne,sans-serif",fontWeight:700,fontSize:"0.85rem",color:"var(--accent-green)",marginBottom:10,display:"flex",alignItems:"center",gap:6 }}><ThumbsUp size={13}/> Overall Strengths</div>
          {allStrengths.length > 0
            ? allStrengths.map((s,i)=><div key={i} style={{display:"flex",gap:6,marginBottom:7,alignItems:"flex-start"}}><CheckCircle size={10} color="var(--accent-green)" style={{flexShrink:0,marginTop:2}}/><span style={{fontSize:"0.75rem",color:"var(--text-secondary)",lineHeight:1.5}}>{s}</span></div>)
            : <div style={{fontSize:"0.75rem",color:"var(--text-muted)",fontStyle:"italic"}}>Complete more questions for strength analysis.</div>
          }
        </div>
        <div className="card" style={{ borderRadius:13,padding:"16px 18px" }}>
          <div style={{ fontFamily:"Syne,sans-serif",fontWeight:700,fontSize:"0.85rem",color:"#f59e0b",marginBottom:10,display:"flex",alignItems:"center",gap:6 }}><Lightbulb size={13}/> Improvements</div>
          {allImprovements.length>0
            ? allImprovements.map((s,i)=><div key={i} style={{display:"flex",gap:6,marginBottom:7,alignItems:"flex-start"}}><AlertTriangle size={10} color="#f59e0b" style={{flexShrink:0,marginTop:2}}/><span style={{fontSize:"0.75rem",color:"var(--text-secondary)",lineHeight:1.5}}>{s}</span></div>)
            : <div style={{fontSize:"0.75rem",color:"var(--text-muted)"}}>No major issues — great interview!</div>
          }
        </div>
      </div>

      <div className="card" style={{ borderRadius:15,padding:"18px",marginBottom:14 }}>
        <div style={{ fontFamily:"Syne,sans-serif",fontWeight:700,fontSize:"0.88rem",color:"var(--text-primary)",marginBottom:12,display:"flex",alignItems:"center",gap:7 }}><FileText size={14}/> Question Breakdown</div>
        <div style={{ display:"flex",flexDirection:"column",gap:9 }}>
          {feedbacks.map((f,i) => (
            <div key={i} style={{ padding:"12px 13px",borderRadius:9,background:"var(--bg-primary)",border:"1px solid var(--border)" }}>
              <div style={{ display:"flex",justifyContent:"space-between",marginBottom:5 }}>
                <div style={{ fontSize:"0.8rem",fontWeight:600,color:"var(--text-primary)",flex:1,paddingRight:10,lineHeight:1.5 }}>{f.question}</div>
                <div style={{ textAlign:"right",flexShrink:0 }}>
                  <div style={{ fontFamily:"Syne,sans-serif",fontWeight:800,fontSize:"1.05rem",color:f.feedback.color }}>{f.feedback.score}</div>
                  <div style={{ fontSize:"0.58rem",color:f.feedback.color,fontWeight:600 }}>{f.feedback.label}</div>
                </div>
              </div>
              <div style={{ height:3,borderRadius:2,background:"var(--border)",marginBottom:6,overflow:"hidden" }}><div style={{width:`${f.feedback.score}%`,height:"100%",background:f.feedback.color,borderRadius:2}}/></div>
              <div style={{ display:"flex",gap:10,fontSize:"0.65rem",color:"var(--text-muted)",flexWrap:"wrap" }}>
                <span>Risk: <span style={{color:riskColor(f.feedback.realInterviewRisk.level),fontWeight:700}}>{f.feedback.realInterviewRisk.verdict}</span></span>
                <span>Hire: <span style={{color:hireColor(f.feedback.recruiterView.hireDecision),fontWeight:700}}>{f.feedback.recruiterView.hireDecision}</span></span>
                <span>Fillers: <span style={{color:f.feedback.fillerJudgmentColor,fontWeight:700}}>{f.feedback.totalFillerOccurrences}</span></span>
                {f.feedback.wordCount < 10 && <span style={{color:"#ef4444",fontWeight:700}}>⚠ Too short</span>}
              </div>
            </div>
          ))}
        </div>
      </div>

      <div style={{ display:"flex",gap:9,flexWrap:"wrap" }}>
        <button onClick={resetAll} className="btn-primary" style={{ padding:"10px 20px",borderRadius:10,fontWeight:700,fontSize:"0.85rem",display:"inline-flex",alignItems:"center",gap:6 }}><span style={{position:"relative",zIndex:1,display:"flex",alignItems:"center",gap:6}}><RefreshCw size={13}/> Try Again</span></button>
        <button onClick={downloadReport} className="btn-ghost" style={{ padding:"10px 20px",borderRadius:10,fontWeight:600,fontSize:"0.85rem",display:"inline-flex",alignItems:"center",gap:6 }}><Download size={13}/> Download PDF Report</button>
      </div>
    </div>
  );
}
