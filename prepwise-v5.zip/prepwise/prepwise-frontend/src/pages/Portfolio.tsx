import { useState, useRef } from "react";
import {
  Sparkles, Upload, FileText, Download, Eye, RefreshCw,
  CheckCircle, ChevronRight, User, Code, Briefcase,
  GraduationCap, Mail, ExternalLink, Palette, Zap,
  Star, Globe, Github, Linkedin, Brain, Copy, Check
} from "lucide-react";
import * as pdfjsLib from "pdfjs-dist";
import { useResume } from "../context/ResumeContext";
import { useAuth } from "../context/AuthContext";

pdfjsLib.GlobalWorkerOptions.workerSrc = new URL(
  "pdfjs-dist/build/pdf.worker.min.mjs", import.meta.url
).toString();

type Stage = "upload" | "generating" | "preview" | "export";
type Theme = "dark" | "light";
type PreviewTab = "hero" | "about" | "skills" | "projects" | "contact";

interface PortfolioData {
  hero: { headline: string; subheadline: string; badge: string; ctaText: string };
  about: { summary: string; highlights: { label: string; value: string }[] };
  skills: { categories: { name: string; items: string[] }[] };
  projects: { name: string; tagline: string; description: string; tech: string[]; highlights: string[]; githubUrl: string; liveUrl: string; featured: boolean }[];
  experience: { role: string; org: string; duration: string; bullets: string[] }[];
  education: { degree: string; institution: string; year: string; gpa: string; highlights: string[] }[];
  achievements: { title: string; description: string; icon: string }[];
  contactSuggestions: { tagline: string; email: string; linkedin: string; github: string };
  seoMeta: { title: string; description: string };
  generatedAt?: string;
}

const Tag = ({ label, color = "blue" }: { label: string; color?: string }) => {
  const c = color === "green"
    ? { bg: "rgba(0,229,160,0.08)", border: "rgba(0,229,160,0.25)", text: "var(--accent-green)" }
    : { bg: "var(--glow-blue)", border: "var(--border-strong)", text: "var(--accent-blue)" };
  return (
    <span style={{ padding: "3px 10px", borderRadius: 100, fontSize: "0.73rem", fontWeight: 600, background: c.bg, border: `1px solid ${c.border}`, color: c.text }}>
      {label}
    </span>
  );
};

export default function Portfolio() {
  const { resumeData } = useResume();
  const { user } = useAuth();
  const fileRef = useRef<HTMLInputElement>(null);

  const [stage, setStage] = useState<Stage>("upload");
  const [resumeText, setResumeText] = useState("");
  const [fileName, setFileName] = useState("");
  const [jobDesc, setJobDesc] = useState("");
  const [fileError, setFileError] = useState("");
  const [portfolio, setPortfolio] = useState<PortfolioData | null>(null);
  const [error, setError] = useState("");
  const [progress, setProgress] = useState(0);
  const [progLabel, setProgLabel] = useState("Starting…");
  const [theme, setTheme] = useState<Theme>("dark");
  const [previewTab, setPreviewTab] = useState<PreviewTab>("hero");
  const [exportedHtml, setExportedHtml] = useState("");
  const [copied, setCopied] = useState(false);
  const [editingField, setEditingField] = useState<string | null>(null);

  const extractPdf = async (file: File) => {
    const buf = await file.arrayBuffer();
    const pdf = await pdfjsLib.getDocument({ data: buf }).promise;
    const pages: string[] = [];
    for (let i = 1; i <= pdf.numPages; i++) {
      const page = await pdf.getPage(i);
      const content = await page.getTextContent();
      pages.push(content.items.map((it: unknown) => ((it as { str?: string }).str || "")).join(" "));
    }
    return pages.join("\n");
  };

  const handleFile = async (file: File) => {
    setFileError("");
    const isPdf = file.name.endsWith(".pdf");
    const isTxt = file.name.endsWith(".txt") || file.name.endsWith(".md");
    if (!isPdf && !isTxt) { setFileError("Upload PDF, .txt, or .md file."); return; }
    try {
      const text = isPdf ? await extractPdf(file) : await file.text();
      if (!text.trim()) { setFileError("Could not extract text from this file."); return; }
      setResumeText(text); setFileName(file.name);
    } catch { setFileError("Failed to read file."); }
  };

  const generate = async () => {
    const src = resumeText || (resumeData ? JSON.stringify(resumeData) : "");
    if (!src.trim()) { setError("Please upload a resume first."); return; }
    setError(""); setStage("generating"); setProgress(0);

    const steps: [number, string][] = [
      [15, "Reading your resume…"], [30, "Crafting your story…"],
      [48, "Writing project descriptions…"], [62, "Generating skills breakdown…"],
      [75, "Writing about section…"], [88, "Polishing headlines…"],
    ];
    steps.forEach(([p, l], i) => setTimeout(() => { setProgress(p); setProgLabel(l); }, i * 500));

    try {
      const token = localStorage.getItem("token");
      const res = await fetch("/portfolio/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
        body: JSON.stringify({ resumeText: src, jobDescription: jobDesc, userProfile: { name: user?.name, targetRole: user?.targetRole } }),
      });
      if (!res.ok) throw new Error(`Server ${res.status}`);
      const data: PortfolioData = await res.json();
      setTimeout(() => {
        setProgress(100); setProgLabel("Done!");
        setTimeout(() => { setPortfolio(data); setStage("preview"); }, 400);
      }, 3200);
    } catch (err: unknown) {
      setStage("upload");
      setError(err instanceof Error ? err.message : "Generation failed.");
    }
  };

  const exportHtml = async () => {
    if (!portfolio) return;
    setStage("export");
    try {
      const token = localStorage.getItem("token");
      const res = await fetch("/portfolio/export-html", {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
        body: JSON.stringify({ portfolioData: portfolio, theme }),
      });
      const data = await res.json();
      setExportedHtml(data.html || "");
    } catch { setError("Export failed."); setStage("preview"); }
  };

  const downloadHtml = () => {
    if (!exportedHtml) return;
    const a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob([exportedHtml], { type: "text/html" }));
    a.download = "portfolio.html"; a.click();
  };

  const copyHtml = () => {
    navigator.clipboard.writeText(exportedHtml);
    setCopied(true); setTimeout(() => setCopied(false), 2000);
  };

  const previewTabs: { id: PreviewTab; label: string; icon: React.ReactNode }[] = [
    { id: "hero",     label: "Hero",     icon: <Sparkles size={12}/> },
    { id: "about",    label: "About",    icon: <User size={12}/> },
    { id: "skills",   label: "Skills",   icon: <Code size={12}/> },
    { id: "projects", label: "Projects", icon: <Briefcase size={12}/> },
    { id: "contact",  label: "Contact",  icon: <Mail size={12}/> },
  ];

  return (
    <div style={{ maxWidth: 960, margin: "0 auto" }}>
      {/* Header */}
      <div style={{ marginBottom: 22 }}>
        <div className="tag" style={{ display: "inline-flex", alignItems: "center", gap: 6, borderRadius: 100, padding: "5px 14px", marginBottom: 10, fontSize: "0.75rem" }}>
          <Sparkles size={11}/> Portfolio Generator
        </div>
        <h1 style={{ fontFamily: "Syne,sans-serif", fontWeight: 800, fontSize: "clamp(1.7rem,3vw,2.1rem)", letterSpacing: "-0.03em", color: "var(--text-primary)", marginBottom: 7 }}>
          Portfolio <span className="gradient-text">Generator</span>
        </h1>
        <p style={{ color: "var(--text-secondary)", fontSize: "0.9rem" }}>
          Turn your resume into a beautiful, downloadable portfolio website in seconds.
        </p>
      </div>

      {/* Step indicator */}
      {stage !== "preview" && stage !== "export" && (
        <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 22 }}>
          {[{ n: 1, label: "Upload Resume", active: stage === "upload" }, { n: 2, label: "AI Generates", active: stage === "generating" }].map((s, i) => (
            <div key={s.n} style={{ display: "flex", alignItems: "center", gap: 6 }}>
              <div style={{ width: 26, height: 26, borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "0.7rem", fontWeight: 800, background: s.active ? "linear-gradient(135deg,var(--accent-blue),var(--accent-cyan))" : "var(--bg-primary)", border: `2px solid ${s.active ? "var(--accent-blue)" : "var(--border)"}`, color: s.active ? "#fff" : "var(--text-muted)" }}>{s.n}</div>
              <span style={{ fontSize: "0.76rem", fontWeight: s.active ? 700 : 500, color: s.active ? "var(--text-primary)" : "var(--text-muted)" }}>{s.label}</span>
              {i < 1 && <ChevronRight size={12} color="var(--border)" />}
            </div>
          ))}
        </div>
      )}

      {/* Upload stage */}
      {stage === "upload" && (
        <div style={{ display: "grid", gap: 12 }}>
          {/* Resume source — use existing or upload new */}
          {resumeData && (
            <div className="card" style={{ borderRadius: 13, padding: "14px 18px", display: "flex", alignItems: "center", gap: 11, border: "1px solid rgba(0,229,160,0.25)" }}>
              <CheckCircle size={15} color="var(--accent-green)" />
              <div style={{ flex: 1 }}>
                <div style={{ fontWeight: 700, fontSize: "0.85rem", color: "var(--text-primary)" }}>Resume already analyzed ✓</div>
                <div style={{ fontSize: "0.72rem", color: "var(--text-muted)" }}>Using data from your last resume analysis — {resumeData.skills?.length || 0} skills, {resumeData.projects?.length || 0} projects</div>
              </div>
              <button onClick={() => setResumeText("")} style={{ background: "none", border: "none", cursor: "pointer", fontSize: "0.73rem", color: "var(--text-muted)" }}>Upload different</button>
            </div>
          )}

          {/* File upload */}
          {!resumeData && (
            <div className="card" onClick={() => fileRef.current?.click()} style={{ borderRadius: 16, padding: "44px 36px", textAlign: "center", cursor: "pointer", border: `2px dashed ${fileName ? "var(--accent-green)" : "var(--border)"}`, background: "var(--bg-card)", transition: "all 0.2s" }}>
              <div style={{ width: 56, height: 56, borderRadius: 14, background: "var(--bg-primary)", border: "1px solid var(--border-strong)", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 14px" }}>
                {fileName ? <CheckCircle size={24} color="var(--accent-green)" /> : <Upload size={24} color="var(--accent-blue)" />}
              </div>
              {fileName ? (
                <><div style={{ fontWeight: 700, color: "var(--accent-green)", marginBottom: 4 }}>{fileName}</div><div style={{ fontSize: "0.78rem", color: "var(--text-muted)" }}>Click to change</div></>
              ) : (
                <><h3 style={{ fontFamily: "Syne,sans-serif", fontWeight: 700, color: "var(--text-primary)", marginBottom: 7 }}>Drop your resume</h3><p style={{ color: "var(--text-muted)", fontSize: "0.85rem" }}>PDF, .txt or .md</p></>
              )}
              <input ref={fileRef} type="file" accept=".pdf,.txt,.md" style={{ display: "none" }} onChange={e => { if (e.target.files?.[0]) handleFile(e.target.files[0]); }} />
              {fileError && <div style={{ marginTop: 12, fontSize: "0.78rem", color: "#ef4444" }}>⚠ {fileError}</div>}
            </div>
          )}

          {/* Optional JD */}
          <div className="card" style={{ borderRadius: 13, padding: "18px 22px" }}>
            <div style={{ fontFamily: "Syne,sans-serif", fontWeight: 700, fontSize: "0.85rem", color: "var(--text-primary)", marginBottom: 4 }}>Target Role / JD (optional)</div>
            <p style={{ fontSize: "0.75rem", color: "var(--text-muted)", marginBottom: 9 }}>Paste a job description to tailor the portfolio to a specific role.</p>
            <textarea value={jobDesc} onChange={e => setJobDesc(e.target.value)} placeholder="e.g. 'We are looking for a Full Stack Engineer with React and Node.js experience…'" style={{ width: "100%", minHeight: 90, padding: "10px 12px", borderRadius: 8, fontSize: "0.875rem", resize: "vertical", fontFamily: "inherit", background: "var(--input-bg)", border: "1px solid var(--border)", color: "var(--text-primary)", outline: "none" }} />
          </div>

          {error && <div style={{ padding: "9px 12px", borderRadius: 8, background: "rgba(239,68,68,0.07)", border: "1px solid rgba(239,68,68,0.2)", fontSize: "0.8rem", color: "#ef4444" }}>⚠ {error}</div>}

          <button onClick={generate} className="btn-primary" style={{ padding: "12px 0", borderRadius: 10, fontSize: "0.9rem", display: "flex", alignItems: "center", gap: 8, justifyContent: "center" }}>
            <span style={{ position: "relative", zIndex: 1, display: "flex", alignItems: "center", gap: 8 }}><Sparkles size={15}/> Generate My Portfolio</span>
          </button>
        </div>
      )}

      {/* Generating */}
      {stage === "generating" && (
        <div className="card" style={{ borderRadius: 16, padding: "56px 36px", textAlign: "center" }}>
          <div style={{ width: 66, height: 66, borderRadius: "50%", background: "var(--glow-blue)", border: "1px solid var(--border-strong)", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 22px" }}>
            <Sparkles size={28} color="var(--accent-blue)" />
          </div>
          <h3 style={{ fontFamily: "Syne,sans-serif", fontWeight: 700, fontSize: "1.1rem", color: "var(--text-primary)", marginBottom: 7 }}>Crafting your portfolio…</h3>
          <p style={{ color: "var(--text-muted)", fontSize: "0.85rem", marginBottom: 28 }}>{progLabel}</p>
          <div style={{ maxWidth: 400, margin: "0 auto" }}>
            <div style={{ height: 6, background: "var(--border)", borderRadius: 4, overflow: "hidden" }}>
              <div style={{ height: "100%", width: `${progress}%`, background: "linear-gradient(90deg,var(--accent-blue),var(--accent-cyan))", borderRadius: 4, transition: "width 0.4s ease" }} />
            </div>
            <div style={{ display: "flex", justifyContent: "space-between", marginTop: 7 }}>
              <span style={{ fontSize: "0.7rem", color: "var(--text-muted)" }}>{progLabel}</span>
              <span style={{ fontSize: "0.7rem", color: "var(--accent-blue)", fontWeight: 700 }}>{progress}%</span>
            </div>
          </div>
          <div style={{ display: "flex", justifyContent: "center", gap: 14, marginTop: 26, flexWrap: "wrap" }}>
            {["Hero section", "About me", "Skills", "Projects", "Contact"].map((t, i) => (
              <div key={i} style={{ display: "flex", alignItems: "center", gap: 4, fontSize: "0.72rem", color: progress > i * 18 ? "var(--accent-green)" : "var(--text-muted)" }}>
                <CheckCircle size={10} color={progress > i * 18 ? "var(--accent-green)" : "var(--border)"}/> {t}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Preview */}
      {(stage === "preview" || stage === "export") && portfolio && (
        <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
          {/* Top action bar */}
          <div className="card" style={{ borderRadius: 13, padding: "14px 18px", display: "flex", alignItems: "center", gap: 12, flexWrap: "wrap" }}>
            <div style={{ flex: 1, minWidth: 200 }}>
              <div style={{ fontFamily: "Syne,sans-serif", fontWeight: 800, fontSize: "1rem", color: "var(--text-primary)", marginBottom: 2 }}>
                {portfolio.hero?.headline || "Your Portfolio"} ✦
              </div>
              <div style={{ fontSize: "0.75rem", color: "var(--text-muted)" }}>
                {portfolio.projects?.length || 0} projects · {portfolio.skills?.categories?.length || 0} skill categories · Generated {portfolio.generatedAt ? new Date(portfolio.generatedAt).toLocaleDateString() : "just now"}
              </div>
            </div>
            {/* Theme toggle */}
            <div style={{ display: "flex", alignItems: "center", gap: 7, padding: "6px 12px", borderRadius: 8, background: "var(--bg-primary)", border: "1px solid var(--border)" }}>
              <Palette size={13} color="var(--text-muted)" />
              <span style={{ fontSize: "0.75rem", color: "var(--text-muted)" }}>Theme:</span>
              {(["dark", "light"] as Theme[]).map(t => (
                <button key={t} onClick={() => setTheme(t)} style={{ padding: "3px 10px", borderRadius: 6, cursor: "pointer", fontWeight: 600, fontSize: "0.72rem", border: `1px solid ${theme === t ? "var(--accent-blue)" : "var(--border)"}`, background: theme === t ? "var(--glow-blue)" : "none", color: theme === t ? "var(--accent-blue)" : "var(--text-muted)" }}>
                  {t === "dark" ? "🌙 Dark" : "☀️ Light"}
                </button>
              ))}
            </div>
            <button onClick={() => { setStage("upload"); setPortfolio(null); }} className="btn-ghost" style={{ padding: "8px 14px", borderRadius: 8, fontSize: "0.78rem", display: "flex", alignItems: "center", gap: 5 }}>
              <RefreshCw size={12}/> Regenerate
            </button>
            <button onClick={exportHtml} className="btn-primary" style={{ padding: "8px 18px", borderRadius: 8, fontSize: "0.82rem", display: "flex", alignItems: "center", gap: 6 }}>
              <span style={{ position: "relative", zIndex: 1, display: "flex", alignItems: "center", gap: 6 }}>
                <Download size={13}/> Export HTML
              </span>
            </button>
          </div>

          {/* Preview tabs */}
          <div style={{ display: "flex", gap: 5, overflowX: "auto", paddingBottom: 3 }}>
            {previewTabs.map(t => (
              <button key={t.id} onClick={() => setPreviewTab(t.id)} style={{ display: "flex", alignItems: "center", gap: 5, padding: "7px 13px", borderRadius: 8, cursor: "pointer", fontWeight: 600, fontSize: "0.78rem", border: `1px solid ${previewTab === t.id ? "var(--accent-blue)" : "var(--border)"}`, background: previewTab === t.id ? "var(--glow-blue)" : "var(--bg-primary)", color: previewTab === t.id ? "var(--accent-blue)" : "var(--text-muted)", transition: "all 0.18s", whiteSpace: "nowrap" }}>
                {t.icon} {t.label}
              </button>
            ))}
          </div>

          {/* Hero preview */}
          {previewTab === "hero" && (
            <div className="card" style={{ borderRadius: 13, overflow: "hidden" }}>
              <div style={{ background: theme === "dark" ? "#080C14" : "#F0F4FF", padding: "56px 36px", textAlign: "center", position: "relative" }}>
                <div style={{ position: "absolute", inset: 0, background: "radial-gradient(circle at 60% 40%, rgba(59,142,255,0.12), transparent 60%)" }} />
                <div style={{ position: "relative", zIndex: 1 }}>
                  <div style={{ display: "inline-flex", alignItems: "center", gap: 6, background: "rgba(59,142,255,0.1)", border: "1px solid rgba(59,142,255,0.25)", borderRadius: 100, padding: "4px 14px", marginBottom: 18, fontSize: "0.75rem", fontWeight: 700, color: "#3B8EFF" }}>✦ {portfolio.hero?.badge}</div>
                  <h1 style={{ fontFamily: "Syne,sans-serif", fontWeight: 800, fontSize: "clamp(1.8rem,4vw,3rem)", letterSpacing: "-0.04em", marginBottom: 14, color: theme === "dark" ? "#F0F4FF" : "#0A0F1E", lineHeight: 1.1 }}>
                    <span style={{ background: "linear-gradient(135deg,#3B8EFF,#00D4FF)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>{portfolio.hero?.headline}</span>
                  </h1>
                  <p style={{ color: theme === "dark" ? "#94A3B8" : "#475569", fontSize: "0.95rem", maxWidth: 480, margin: "0 auto 28px", lineHeight: 1.75 }}>{portfolio.hero?.subheadline}</p>
                  <div style={{ display: "inline-flex", alignItems: "center", gap: 8, padding: "11px 28px", borderRadius: 10, background: "linear-gradient(135deg,#3B8EFF,#00D4FF)", color: "#fff", fontWeight: 700, fontSize: "0.9rem" }}>{portfolio.hero?.ctaText} →</div>
                </div>
              </div>
            </div>
          )}

          {/* About preview */}
          {previewTab === "about" && (
            <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
              <div className="card" style={{ borderRadius: 13, padding: "18px 22px" }}>
                <div style={{ fontFamily: "Syne,sans-serif", fontWeight: 700, fontSize: "0.85rem", color: "var(--text-primary)", marginBottom: 10, display: "flex", alignItems: "center", gap: 6 }}><User size={13} color="var(--accent-blue)"/> About Me</div>
                <p style={{ color: "var(--text-secondary)", fontSize: "0.9rem", lineHeight: 1.8 }}>{portfolio.about?.summary}</p>
              </div>
              <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(200px, 1fr))", gap: 9 }}>
                {(portfolio.about?.highlights || []).map((h, i) => (
                  <div key={i} className="card" style={{ borderRadius: 10, padding: "12px 14px" }}>
                    <div style={{ fontSize: "0.65rem", fontWeight: 700, color: "var(--text-muted)", textTransform: "uppercase", letterSpacing: "0.07em", marginBottom: 4 }}>{h.label}</div>
                    <div style={{ fontWeight: 700, fontSize: "0.875rem", color: "var(--text-primary)" }}>{h.value}</div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Skills preview */}
          {previewTab === "skills" && (
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(220px, 1fr))", gap: 12 }}>
              {(portfolio.skills?.categories || []).map((cat, i) => (
                <div key={i} className="card" style={{ borderRadius: 12, padding: "16px 18px" }}>
                  <div style={{ fontFamily: "Syne,sans-serif", fontWeight: 700, fontSize: "0.8rem", color: "var(--text-primary)", marginBottom: 11, display: "flex", alignItems: "center", gap: 6 }}><Code size={12} color="var(--accent-cyan)"/> {cat.name}</div>
                  <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
                    {(cat.items || []).map(s => <Tag key={s} label={s} />)}
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Projects preview */}
          {previewTab === "projects" && (
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: 12 }}>
              {(portfolio.projects || []).map((p, i) => (
                <div key={i} className="card" style={{ borderRadius: 13, padding: "18px 20px", border: p.featured ? "1px solid rgba(59,142,255,0.3)" : undefined, position: "relative" }}>
                  {p.featured && <div style={{ position: "absolute", top: 12, right: 12, fontSize: "0.6rem", fontWeight: 800, padding: "2px 8px", borderRadius: 100, background: "var(--glow-blue)", border: "1px solid var(--border-strong)", color: "var(--accent-blue)", textTransform: "uppercase", letterSpacing: "0.06em" }}>Featured</div>}
                  <div style={{ fontFamily: "Syne,sans-serif", fontWeight: 800, fontSize: "0.95rem", color: "var(--text-primary)", marginBottom: 4 }}>{p.name}</div>
                  <div style={{ fontSize: "0.78rem", color: "var(--accent-blue)", fontWeight: 600, marginBottom: 9 }}>{p.tagline}</div>
                  <p style={{ fontSize: "0.82rem", color: "var(--text-secondary)", lineHeight: 1.65, marginBottom: 12 }}>{p.description}</p>
                  <div style={{ display: "flex", flexWrap: "wrap", gap: 5, marginBottom: 10 }}>
                    {(p.tech || []).map(t => <Tag key={t} label={t} />)}
                  </div>
                  {(p.highlights || []).length > 0 && (
                    <ul style={{ margin: "0 0 10px 16px", fontSize: "0.78rem", color: "var(--text-secondary)", lineHeight: 1.6 }}>
                      {p.highlights.map((h, j) => <li key={j}>{h}</li>)}
                    </ul>
                  )}
                  <div style={{ display: "flex", gap: 12, fontSize: "0.78rem", fontWeight: 600 }}>
                    {p.githubUrl && <a href={p.githubUrl} target="_blank" rel="noopener" style={{ display: "flex", alignItems: "center", gap: 4, color: "var(--text-muted)" }}><Github size={12}/> GitHub</a>}
                    {p.liveUrl  && <a href={p.liveUrl}  target="_blank" rel="noopener" style={{ display: "flex", alignItems: "center", gap: 4, color: "var(--accent-green)" }}><Globe size={12}/> Live</a>}
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Contact preview */}
          {previewTab === "contact" && (
            <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
              <div className="card" style={{ borderRadius: 13, padding: "22px 26px", textAlign: "center" }}>
                <div style={{ fontFamily: "Syne,sans-serif", fontWeight: 800, fontSize: "1.3rem", color: "var(--text-primary)", marginBottom: 10 }}>Let's Work Together</div>
                <p style={{ color: "var(--text-secondary)", fontSize: "0.9rem", marginBottom: 22, lineHeight: 1.7 }}>{portfolio.contactSuggestions?.tagline}</p>
                <div style={{ display: "flex", gap: 10, justifyContent: "center", flexWrap: "wrap" }}>
                  {portfolio.contactSuggestions?.email && (
                    <div style={{ display: "flex", alignItems: "center", gap: 7, padding: "9px 16px", borderRadius: 9, background: "var(--bg-primary)", border: "1px solid var(--border)", fontSize: "0.83rem", color: "var(--text-secondary)" }}><Mail size={13} color="var(--accent-blue)"/> {portfolio.contactSuggestions.email || "your@email.com"}</div>
                  )}
                  {portfolio.contactSuggestions?.linkedin && (
                    <div style={{ display: "flex", alignItems: "center", gap: 7, padding: "9px 16px", borderRadius: 9, background: "var(--bg-primary)", border: "1px solid var(--border)", fontSize: "0.83rem", color: "var(--text-secondary)" }}><Linkedin size={13} color="var(--accent-blue)"/> LinkedIn</div>
                  )}
                  {portfolio.contactSuggestions?.github && (
                    <div style={{ display: "flex", alignItems: "center", gap: 7, padding: "9px 16px", borderRadius: 9, background: "var(--bg-primary)", border: "1px solid var(--border)", fontSize: "0.83rem", color: "var(--text-secondary)" }}><Github size={13} color="var(--text-muted)"/> GitHub</div>
                  )}
                </div>
              </div>
              <div className="card" style={{ borderRadius: 13, padding: "14px 18px" }}>
                <div style={{ fontFamily: "Syne,sans-serif", fontWeight: 700, fontSize: "0.82rem", color: "var(--text-primary)", marginBottom: 8, display: "flex", alignItems: "center", gap: 6 }}><Star size={12} color="#f59e0b"/> SEO Meta</div>
                <div style={{ fontSize: "0.78rem", color: "var(--text-muted)", marginBottom: 4 }}>Title: <span style={{ color: "var(--text-secondary)" }}>{portfolio.seoMeta?.title}</span></div>
                <div style={{ fontSize: "0.78rem", color: "var(--text-muted)" }}>Description: <span style={{ color: "var(--text-secondary)" }}>{portfolio.seoMeta?.description}</span></div>
              </div>
            </div>
          )}

          {/* Export panel */}
          {stage === "export" && exportedHtml && (
            <div className="card" style={{ borderRadius: 13, padding: "18px 22px", border: "1px solid rgba(0,229,160,0.25)" }}>
              <div style={{ fontFamily: "Syne,sans-serif", fontWeight: 700, fontSize: "0.9rem", color: "var(--text-primary)", marginBottom: 12, display: "flex", alignItems: "center", gap: 7 }}><CheckCircle size={14} color="var(--accent-green)"/> Portfolio HTML Ready</div>
              <p style={{ fontSize: "0.82rem", color: "var(--text-secondary)", marginBottom: 16, lineHeight: 1.65 }}>
                Your portfolio is a single self-contained HTML file. Host it on GitHub Pages, Netlify, Vercel, or any static host — no framework needed.
              </p>
              <div style={{ display: "flex", gap: 9, flexWrap: "wrap" }}>
                <button onClick={downloadHtml} className="btn-primary" style={{ padding: "9px 20px", borderRadius: 9, fontSize: "0.84rem", display: "flex", alignItems: "center", gap: 6 }}>
                  <span style={{ position: "relative", zIndex: 1, display: "flex", alignItems: "center", gap: 6 }}><Download size={13}/> Download portfolio.html</span>
                </button>
                <button onClick={copyHtml} className="btn-ghost" style={{ padding: "9px 16px", borderRadius: 9, fontSize: "0.82rem", display: "flex", alignItems: "center", gap: 6 }}>
                  {copied ? <><Check size={12} color="var(--accent-green)"/> Copied!</> : <><Copy size={12}/> Copy HTML</>}
                </button>
              </div>
              <div style={{ marginTop: 14, padding: "10px 14px", borderRadius: 8, background: "var(--bg-primary)", border: "1px solid var(--border)", fontSize: "0.75rem", color: "var(--text-muted)", lineHeight: 1.65 }}>
                💡 <strong style={{ color: "var(--text-secondary)" }}>Deploy tip:</strong> Drag & drop the HTML file to <a href="https://netlify.com/drop" target="_blank" rel="noopener" style={{ color: "var(--accent-blue)" }}>netlify.com/drop</a> for instant free hosting in 30 seconds.
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
