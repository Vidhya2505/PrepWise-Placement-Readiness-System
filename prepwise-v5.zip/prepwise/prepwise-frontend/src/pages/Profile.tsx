import { useState, useEffect } from "react";
import { User, Mail, Target, Briefcase, Code, Edit3, Save, X, Award, TrendingUp, Clock, CheckCircle } from "lucide-react";
import { useAuth } from "../context/AuthContext";

const ROLES   = ["Software Developer (SDE)","Full Stack Developer","Backend Engineer","Frontend Engineer","Data Analyst","ML Engineer"];
const CO_TYPES= ["Product Company","Service Company","Startup","Open to All"];
const EXP     = ["Fresher (0–1 yr)","Beginner (1–2 yr)","Intermediate (2–4 yr)","Experienced (4+ yr)"];
const SKILLS  = ["DSA","System Design","DBMS","OS","CN","Java","Python","React","Node.js","SQL","Spring Boot","AWS","Docker","MongoDB","TypeScript","Git"];

const Skel = ({ h = 14, w = "100%" }: { h?: number; w?: string }) => <div className="skeleton" style={{ width:w, height:h, borderRadius:5 }} />;

export default function Profile() {
  const { user, setUser } = useAuth();
  const [editing, setEditing]   = useState(false);
  const [saving, setSaving]     = useState(false);
  const [saveMsg, setSaveMsg]   = useState("");
  const [loading, setLoading]   = useState(true);
  const [stats, setStats]       = useState({ total:0, avgScore:0, streak:0, readiness:0 });

  const [draft, setDraft] = useState({ name:"", targetRole:"", experience:"", companyType:"", college:"", graduationYear:"", skills:[] as string[] });

  useEffect(() => {
    const load = async () => {
      setLoading(true);
      try {
        const token = localStorage.getItem("token");
        const [meRes, statsRes] = await Promise.all([
          fetch("/auth/me", { headers:{ Authorization:`Bearer ${token}` } }),
          fetch("/interview/stats", { headers:{ Authorization:`Bearer ${token}` } }),
        ]);
        if (meRes.ok) { const u = await meRes.json(); setUser({ id:u._id, ...u }); setDraft({ name:u.name||"", targetRole:u.targetRole||"", experience:u.experience||"", companyType:u.companyType||"", college:u.college||"", graduationYear:u.graduationYear||"", skills:u.skills||[] }); }
        if (statsRes.ok) { const s = await statsRes.json(); setStats({ total:s.total||0, avgScore:s.avgScore||0, streak:s.streak||0, readiness:s.readiness||0 }); }
      } catch { /* keep defaults */ }
      finally { setLoading(false); }
    };
    load();
  }, []);

  const set = (k: keyof typeof draft, v: string) => setDraft(d => ({ ...d, [k]:v }));
  const toggleSkill = (s: string) => setDraft(d => ({ ...d, skills: d.skills.includes(s) ? d.skills.filter(x=>x!==s) : [...d.skills, s] }));

  const handleSave = async () => {
    setSaving(true);
    try {
      const token = localStorage.getItem("token");
      const res = await fetch("/auth/me", { method:"PUT", headers:{"Content-Type":"application/json",Authorization:`Bearer ${token}`}, body:JSON.stringify(draft) });
      if (res.ok) { const u = await res.json(); setUser({ id:u._id, ...u }); setSaveMsg("Profile saved!"); setTimeout(()=>setSaveMsg(""),3000); setEditing(false); }
    } catch { setSaveMsg("Save failed. Try again."); }
    finally { setSaving(false); }
  };

  const avatar = (user?.name || "U").split(" ").map(n=>n[0]).join("").toUpperCase().slice(0,2);

  return (
    <div style={{ maxWidth: 860, margin: "0 auto" }}>
      <div style={{ marginBottom: 24 }}>
        <div className="tag" style={{ display:"inline-flex",alignItems:"center",gap:6,borderRadius:100,padding:"5px 14px",marginBottom:10,fontSize:"0.75rem" }}><User size={11}/> Profile</div>
        <h1 style={{ fontFamily:"Syne,sans-serif",fontWeight:800,fontSize:"clamp(1.7rem,3vw,2.1rem)",letterSpacing:"-0.03em",color:"var(--text-primary)" }}>Your Profile</h1>
      </div>

      {/* Profile header */}
      <div className="card" style={{ borderRadius:16,padding:"24px 26px",marginBottom:16,display:"flex",gap:20,alignItems:"flex-start",flexWrap:"wrap" }}>
        <div style={{ width:72,height:72,borderRadius:"50%",background:"linear-gradient(135deg,var(--accent-blue),var(--accent-cyan))",display:"flex",alignItems:"center",justifyContent:"center",fontFamily:"Syne,sans-serif",fontWeight:800,fontSize:"1.5rem",color:"white",flexShrink:0 }}>{avatar}</div>
        <div style={{ flex:1,minWidth:200 }}>
          {loading ? <><Skel h={22} w="40%" /><div style={{marginTop:8}}><Skel h={14} w="60%" /></div></> : (
            <>
              <div style={{ fontFamily:"Syne,sans-serif",fontWeight:800,fontSize:"1.3rem",color:"var(--text-primary)",marginBottom:4 }}>{user?.name || "—"}</div>
              <div style={{ fontSize:"0.85rem",color:"var(--text-muted)",marginBottom:6 }}>{user?.email}</div>
              <div style={{ display:"flex",gap:8,flexWrap:"wrap" }}>
                {user?.targetRole && <span style={{padding:"3px 10px",borderRadius:100,fontSize:"0.75rem",fontWeight:600,background:"var(--glow-blue)",border:"1px solid var(--border-strong)",color:"var(--accent-blue)"}}>{user.targetRole}</span>}
                {user?.experience && <span style={{padding:"3px 10px",borderRadius:100,fontSize:"0.75rem",fontWeight:600,background:"var(--bg-primary)",border:"1px solid var(--border)",color:"var(--text-muted)"}}>{user.experience}</span>}
              </div>
            </>
          )}
        </div>
        <div style={{ display:"flex",gap:8 }}>
          {saveMsg && <div style={{ padding:"6px 12px",borderRadius:8,background:saveMsg.includes("failed")?"rgba(239,68,68,0.08)":"rgba(0,229,160,0.08)",border:`1px solid ${saveMsg.includes("failed")?"rgba(239,68,68,0.2)":"rgba(0,229,160,0.25)"}`,fontSize:"0.78rem",color:saveMsg.includes("failed")?"#ef4444":"var(--accent-green)",display:"flex",alignItems:"center",gap:5 }}><CheckCircle size={12}/>{saveMsg}</div>}
          {!editing ? (
            <button onClick={()=>setEditing(true)} className="btn-ghost" style={{ padding:"8px 16px",borderRadius:9,fontSize:"0.85rem",display:"flex",alignItems:"center",gap:6 }}><Edit3 size={13}/> Edit Profile</button>
          ) : (
            <div style={{display:"flex",gap:7"}}>
              <button onClick={()=>{setEditing(false);}} className="btn-ghost" style={{ padding:"8px 14px",borderRadius:9,fontSize:"0.85rem",display:"flex",alignItems:"center",gap:5 }}><X size={13}/> Cancel</button>
              <button onClick={handleSave} disabled={saving} className="btn-primary" style={{ padding:"8px 16px",borderRadius:9,fontSize:"0.85rem",display:"flex",alignItems:"center",gap:5,opacity:saving?0.7:1 }}><span style={{position:"relative",zIndex:1,display:"flex",alignItems:"center",gap:5}}><Save size={13}/>{saving?"Saving…":"Save"}</span></button>
            </div>
          )}
        </div>
      </div>

      {/* Stats row */}
      <div style={{ display:"grid",gridTemplateColumns:"1fr 1fr 1fr 1fr",gap:12,marginBottom:16 }}>
        {[
          { label:"Interviews",     value:loading?"—":String(stats.total),     icon:Award,     color:"var(--accent-blue)",   sub:"all-time" },
          { label:"Avg Score",      value:loading?"—":stats.avgScore>0?`${stats.avgScore}/100`:"—", icon:TrendingUp, color:stats.avgScore>=70?"var(--accent-green)":"#f59e0b", sub:"across rounds" },
          { label:"Day Streak",     value:loading?"—":stats.streak>0?`${stats.streak}🔥`:"0", icon:Clock, color:stats.streak>0?"#f59e0b":"var(--text-muted)", sub:"days in a row" },
          { label:"Readiness",      value:loading?"—":String(stats.readiness), icon:Target,    color:"var(--accent-cyan)",   sub:"/100" },
        ].map(s => (
          <div key={s.label} className="card" style={{ borderRadius:12,padding:"16px" }}>
            <div style={{ width:32,height:32,borderRadius:8,background:`${s.color}15`,border:`1px solid ${s.color}22`,display:"flex",alignItems:"center",justifyContent:"center",marginBottom:9 }}><s.icon size={14} color={s.color}/></div>
            <div style={{ fontFamily:"Syne,sans-serif",fontWeight:800,fontSize:"1.5rem",color:"var(--text-primary)",lineHeight:1,marginBottom:3 }}>{s.value}</div>
            <div style={{ fontWeight:600,fontSize:"0.78rem",color:"var(--text-secondary)",marginBottom:1 }}>{s.label}</div>
            <div style={{ fontSize:"0.68rem",color:"var(--text-muted)" }}>{s.sub}</div>
          </div>
        ))}
      </div>

      {/* Edit form */}
      <div className="card" style={{ borderRadius:16,padding:"22px 24px" }}>
        <div style={{ fontFamily:"Syne,sans-serif",fontWeight:700,fontSize:"0.88rem",color:"var(--text-primary)",marginBottom:18 }}>Profile Information</div>

        {editing ? (
          <div style={{ display:"flex",flexDirection:"column",gap:16 }}>
            {/* Name */}
            <div>
              <label style={{ display:"block",fontSize:"0.8rem",fontWeight:600,color:"var(--text-secondary)",marginBottom:6 }}>Full Name</label>
              <div style={{ position:"relative" }}><User size={13} style={{position:"absolute",left:11,top:"50%",transform:"translateY(-50%)",color:"var(--text-muted)"}}/><input type="text" value={draft.name} onChange={e=>set("name",e.target.value)} className="input-field" style={{width:"100%",padding:"10px 12px 10px 34px",borderRadius:9,fontSize:"0.875rem"}}/></div>
            </div>
            {/* Role */}
            <div>
              <label style={{ display:"block",fontSize:"0.8rem",fontWeight:600,color:"var(--text-secondary)",marginBottom:7 }}>Target Role</label>
              <div style={{ display:"flex",flexWrap:"wrap",gap:7 }}>{ROLES.map(r=><button key={r} type="button" onClick={()=>set("targetRole",r)} style={{padding:"6px 12px",borderRadius:8,cursor:"pointer",fontSize:"0.78rem",fontWeight:600,border:`1px solid ${draft.targetRole===r?"var(--accent-blue)":"var(--border)"}`,background:draft.targetRole===r?"var(--glow-blue)":"var(--bg-primary)",color:draft.targetRole===r?"var(--accent-blue)":"var(--text-secondary)",transition:"all 0.18s"}}>{r}</button>)}</div>
            </div>
            {/* Experience */}
            <div>
              <label style={{ display:"block",fontSize:"0.8rem",fontWeight:600,color:"var(--text-secondary)",marginBottom:7 }}>Experience Level</label>
              <div style={{ display:"flex",flexWrap:"wrap",gap:7 }}>{EXP.map(e=><button key={e} type="button" onClick={()=>set("experience",e)} style={{padding:"6px 12px",borderRadius:8,cursor:"pointer",fontSize:"0.78rem",fontWeight:600,border:`1px solid ${draft.experience===e?"var(--accent-blue)":"var(--border)"}`,background:draft.experience===e?"var(--glow-blue)":"var(--bg-primary)",color:draft.experience===e?"var(--accent-blue)":"var(--text-secondary)",transition:"all 0.18s"}}>{e}</button>)}</div>
            </div>
            {/* Company type */}
            <div>
              <label style={{ display:"block",fontSize:"0.8rem",fontWeight:600,color:"var(--text-secondary)",marginBottom:7 }}>Target Company Type</label>
              <div style={{ display:"flex",flexWrap:"wrap",gap:7 }}>{CO_TYPES.map(c=><button key={c} type="button" onClick={()=>set("companyType",c)} style={{padding:"6px 12px",borderRadius:8,cursor:"pointer",fontSize:"0.78rem",fontWeight:600,border:`1px solid ${draft.companyType===c?"var(--accent-blue)":"var(--border)"}`,background:draft.companyType===c?"var(--glow-blue)":"var(--bg-primary)",color:draft.companyType===c?"var(--accent-blue)":"var(--text-secondary)",transition:"all 0.18s"}}>{c}</button>)}</div>
            </div>
            {/* College + year */}
            <div style={{ display:"grid",gridTemplateColumns:"1fr 1fr",gap:12 }}>
              <div>
                <label style={{display:"block",fontSize:"0.8rem",fontWeight:600,color:"var(--text-secondary)",marginBottom:6}}>College / University</label>
                <input type="text" value={draft.college} onChange={e=>set("college",e.target.value)} placeholder="JNTU, VIT, NIT…" className="input-field" style={{width:"100%",padding:"10px 12px",borderRadius:9,fontSize:"0.875rem"}}/>
              </div>
              <div>
                <label style={{display:"block",fontSize:"0.8rem",fontWeight:600,color:"var(--text-secondary)",marginBottom:6}}>Graduation Year</label>
                <input type="text" value={draft.graduationYear} onChange={e=>set("graduationYear",e.target.value)} placeholder="2025" className="input-field" style={{width:"100%",padding:"10px 12px",borderRadius:9,fontSize:"0.875rem"}}/>
              </div>
            </div>
            {/* Skills */}
            <div>
              <label style={{ display:"block",fontSize:"0.8rem",fontWeight:600,color:"var(--text-secondary)",marginBottom:7 }}>Known Skills</label>
              <div style={{ display:"flex",flexWrap:"wrap",gap:7 }}>{SKILLS.map(s=><button key={s} type="button" onClick={()=>toggleSkill(s)} style={{padding:"5px 12px",borderRadius:100,cursor:"pointer",fontSize:"0.76rem",fontWeight:600,border:`1px solid ${draft.skills.includes(s)?"var(--accent-green)":"var(--border)"}`,background:draft.skills.includes(s)?"rgba(0,229,160,0.1)":"var(--bg-primary)",color:draft.skills.includes(s)?"var(--accent-green)":"var(--text-secondary)",transition:"all 0.18s"}}>{draft.skills.includes(s)?"✓ ":""}{s}</button>)}</div>
              <div style={{ marginTop:7,fontSize:"0.68rem",color:"var(--text-muted)" }}>{draft.skills.length} selected</div>
            </div>
          </div>
        ) : (
          /* Display mode */
          loading ? (
            <div style={{ display:"flex",flexDirection:"column",gap:12 }}>{[1,2,3,4,5].map(i=><Skel key={i} h={20}/>)}</div>
          ) : (
            <div style={{ display:"flex",flexDirection:"column",gap:14 }}>
              {[
                { icon:<User size={14}/>, label:"Name", value:user?.name },
                { icon:<Mail size={14}/>, label:"Email", value:user?.email },
                { icon:<Target size={14}/>, label:"Target Role", value:user?.targetRole },
                { icon:<Briefcase size={14}/>, label:"Experience", value:user?.experience },
                { icon:<Award size={14}/>, label:"Company Type", value:user?.companyType },
                { icon:<Code size={14}/>, label:"College", value:user?.college },
              ].map(f => f.value && (
                <div key={f.label} style={{ display:"flex",gap:12,alignItems:"flex-start",paddingBottom:12,borderBottom:"1px solid var(--border)" }}>
                  <div style={{ color:"var(--text-muted)",flexShrink:0,marginTop:2 }}>{f.icon}</div>
                  <div style={{ flex:1 }}>
                    <div style={{ fontSize:"0.72rem",color:"var(--text-muted)",fontWeight:600,marginBottom:3 }}>{f.label}</div>
                    <div style={{ fontSize:"0.88rem",color:"var(--text-primary)",fontWeight:500 }}>{f.value}</div>
                  </div>
                </div>
              ))}
              {/* Skills display */}
              {user?.skills && user.skills.length > 0 && (
                <div>
                  <div style={{ fontSize:"0.72rem",color:"var(--text-muted)",fontWeight:600,marginBottom:8,display:"flex",alignItems:"center",gap:5 }}><Code size={12}/> Known Skills ({user.skills.length})</div>
                  <div style={{ display:"flex",flexWrap:"wrap",gap:6 }}>{user.skills.map(s=><span key={s} style={{padding:"3px 10px",borderRadius:100,fontSize:"0.75rem",fontWeight:600,background:"rgba(0,229,160,0.08)",border:"1px solid rgba(0,229,160,0.2)",color:"var(--accent-green)"}}>{s}</span>)}</div>
                </div>
              )}
              {/* Resume data */}
              {user?.resumeData?.skills && user.resumeData.skills.length > 0 && (
                <div>
                  <div style={{ fontSize:"0.72rem",color:"var(--text-muted)",fontWeight:600,marginBottom:8,display:"flex",alignItems:"center",gap:5 }}><Target size={12}/> Resume Skills (from last analysis)</div>
                  <div style={{ display:"flex",flexWrap:"wrap",gap:6 }}>{user.resumeData.skills.slice(0,12).map(s=><span key={s} style={{padding:"3px 10px",borderRadius:100,fontSize:"0.75rem",fontWeight:600,background:"var(--glow-blue)",border:"1px solid var(--border-strong)",color:"var(--accent-blue)"}}>{s}</span>)}</div>
                </div>
              )}
              {!user?.targetRole && !user?.experience && (
                <div style={{ padding:"14px 16px",borderRadius:10,background:"rgba(59,142,255,0.06)",border:"1px solid rgba(59,142,255,0.18)",fontSize:"0.82rem",color:"var(--text-secondary)" }}>
                  Click <strong>Edit Profile</strong> to add your target role, experience level, and skills — this improves your mock interview questions.
                </div>
              )}
            </div>
          )
        )}
      </div>
    </div>
  );
}
