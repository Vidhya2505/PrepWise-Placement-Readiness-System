import { useState, useRef, type DragEvent } from "react";
import { Upload, FileText, CheckCircle, AlertCircle, XCircle, Zap, TrendingUp, BookOpen, Briefcase, GraduationCap, Target, ChevronRight, RefreshCw, Download, Star, ArrowRight, Lightbulb, BarChart2, Shield, Brain, TrendingDown, AlertTriangle, Activity, Layers, MessageSquare, Award } from "lucide-react";
import * as pdfjsLib from "pdfjs-dist";
import { useResume } from "../context/ResumeContext";
import { downloadResumePDF } from "../services/pdfUtils";

pdfjsLib.GlobalWorkerOptions.workerSrc = new URL("pdfjs-dist/build/pdf.worker.min.mjs", import.meta.url).toString();

type Stage = "upload" | "jd" | "analyzing" | "results";
type Tab = "overview" | "keywords" | "rewrite" | "sections" | "risk" | "action";

interface SectionFeedback { score: number; status: "strong"|"moderate"|"weak"; feedback: string; suggestions: string[]; }
interface Results {
  matchScore: number; alignmentScore: number; matchedSkills: string[]; missingSkills: string[]; summary: string;
  scoreBreakdown: { skillsMatch: { score: number; reason: string }; experienceStrength: { score: number; reason: string }; keywordCoverage: { score: number; reason: string } };
  keywordOptimization: { skill: string; placement: string; howToWrite: string }[];
  resumeRewrites: { section: string; original: string; improved: string }[];
  impactAnalysis: { hasMetrics: boolean; metricsFound: string[]; missingSections: string[]; suggestion: string };
  roleOptimization: { detectedRole: string; tailoredTips: string[] };
  interviewLinkage: { likelyTopics: string[]; projectsToHighlight: string[]; skillsToEmphasise: string[]; tip: string };
  riskAnalysis: { level: "high"|"medium"|"low"; risk: string }[];
  benchmarkComparison: { skills?: { rating: string; note: string }; projects?: { rating: string; note: string }; experience?: { rating: string; note: string }; overall?: { rating: string; note: string } };
  priorityActionPlan: { priority: "high"|"medium"|"low"; action: string }[];
  keywordDensity: { keyword: string; count: number; recommended: number; status: "good"|"low"|"missing" }[];
  contextAwareSuggestions: { experienceLevel: string; suggestions: string[] };
  sections: { skills: SectionFeedback; projects: SectionFeedback; experience: SectionFeedback; education?: SectionFeedback };
  suggestions: string[];
  resumeData?: { skills: string[]; projects: { name: string; tech: string[]; description: string }[]; experienceLevel: string; education: string };
}

const ScoreRing = ({ score, size = 110, label = "/100" }: { score: number; size?: number; label?: string }) => {
  const r = size * 0.38; const c = 2 * Math.PI * r; const d = (score / 100) * c;
  const col = score >= 75 ? "var(--accent-green)" : score >= 50 ? "#f59e0b" : "#ef4444";
  const cx = size / 2;
  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
      <circle cx={cx} cy={cx} r={r} fill="none" stroke="var(--border)" strokeWidth={size * 0.075} />
      <circle cx={cx} cy={cx} r={r} fill="none" stroke={col} strokeWidth={size * 0.075} strokeLinecap="round" strokeDasharray={`${d} ${c - d}`} strokeDashoffset={c / 4} style={{ transition: "stroke-dasharray 1.2s ease" }} />
      <text x={cx} y={cx - 5} textAnchor="middle" fontFamily="Syne" fontWeight={800} fontSize={size * 0.17} fill="var(--text-primary)">{score}</text>
      <text x={cx} y={cx + size * 0.12} textAnchor="middle" fontSize={size * 0.09} fill="var(--text-muted)">{label}</text>
    </svg>
  );
};
const ScoreBar = ({ value, color }: { value: number; color: string }) => (
  <div style={{ flex: 1, height: 4, borderRadius: 2, background: "var(--border)", overflow: "hidden" }}>
    <div style={{ width: `${value}%`, height: "100%", background: color, borderRadius: 2, transition: "width 1s ease" }} />
  </div>
);
const StatusChip = ({ status }: { status: "strong"|"moderate"|"weak" }) => {
  const m = { strong:{label:"Strong",color:"var(--accent-green)",bg:"rgba(0,229,160,0.1)",border:"rgba(0,229,160,0.25)"}, moderate:{label:"Moderate",color:"#f59e0b",bg:"rgba(245,158,11,0.1)",border:"rgba(245,158,11,0.25)"}, weak:{label:"Needs Work",color:"#ef4444",bg:"rgba(239,68,68,0.08)",border:"rgba(239,68,68,0.2)"} }[status];
  return <span style={{ padding:"2px 8px",borderRadius:100,fontSize:"0.66rem",fontWeight:700,background:m.bg,border:`1px solid ${m.border}`,color:m.color }}>{m.label}</span>;
};
const PBadge = ({ p }: { p: "high"|"medium"|"low" }) => {
  const m = { high:{label:"High",color:"#ef4444",bg:"rgba(239,68,68,0.08)",border:"rgba(239,68,68,0.2)"}, medium:{label:"Med",color:"#f59e0b",bg:"rgba(245,158,11,0.08)",border:"rgba(245,158,11,0.2)"}, low:{label:"Low",color:"var(--accent-blue)",bg:"var(--glow-blue)",border:"var(--border-strong)"} }[p];
  return <span style={{ padding:"2px 8px",borderRadius:100,fontSize:"0.62rem",fontWeight:800,background:m.bg,border:`1px solid ${m.border}`,color:m.color,textTransform:"uppercase",letterSpacing:"0.04em",flexShrink:0 }}>{m.label}</span>;
};
const Tag = ({ label, type }: { label: string; type: "matched"|"missing"|"neutral" }) => {
  const s = { matched:{bg:"rgba(0,229,160,0.1)",border:"rgba(0,229,160,0.3)",color:"var(--accent-green)"}, missing:{bg:"rgba(239,68,68,0.07)",border:"rgba(239,68,68,0.2)",color:"#ef4444"}, neutral:{bg:"var(--glow-blue)",border:"var(--border-strong)",color:"var(--accent-blue)"} }[type];
  return <span style={{ padding:"3px 10px",borderRadius:100,fontSize:"0.74rem",fontWeight:600,background:s.bg,border:`1px solid ${s.border}`,color:s.color }}>{label}</span>;
};

export default function ResumeAnalyzer() {
  const { setResumeData } = useResume();
  const [stage, setStage]           = useState<Stage>("upload");
  const [fileName, setFileName]     = useState("");
  const [resumeText, setResumeText] = useState("");
  const [jobDesc, setJobDesc]       = useState("");
  const [dragOver, setDragOver]     = useState(false);
  const [progress, setProgress]     = useState(0);
  const [progLabel, setProgLabel]   = useState("Starting…");
  const [results, setResults]       = useState<Results | null>(null);
  const [error, setError]           = useState("");
  const [fileError, setFileError]   = useState("");
  const [tab, setTab]               = useState<Tab>("overview");
  const fileRef = useRef<HTMLInputElement>(null);

  const extractPdf = async (file: File) => {
    const buf = await file.arrayBuffer();
    const pdf = await pdfjsLib.getDocument({ data: buf }).promise;
    const pages: string[] = [];
    for (let i = 1; i <= pdf.numPages; i++) {
      const page = await pdf.getPage(i);
      const content = await page.getTextContent();
      pages.push(content.items.map((item: unknown) => { const it = item as { str?: string }; return it.str || ""; }).join(" "));
    }
    return pages.join("\n");
  };

  const handleFile = async (file: File) => {
    setFileError(""); setFileName(file.name);
    const isPdf = file.type === "application/pdf" || file.name.endsWith(".pdf");
    const isTxt = file.type === "text/plain" || file.name.endsWith(".txt") || file.name.endsWith(".md");
    if (!isPdf && !isTxt) { setFileError("Unsupported file. Upload PDF, TXT, or MD."); return; }
    try {
      const text = isPdf ? await extractPdf(file) : await file.text();
      if (!text.trim()) { setFileError("Could not extract text. Try a different PDF or .txt file."); return; }
      setResumeText(text); setStage("jd");
    } catch { setFileError("Failed to read file. If it is a scanned PDF, convert to text first."); }
  };

  const handleDrop = (e: DragEvent<HTMLDivElement>) => { e.preventDefault(); setDragOver(false); const f = e.dataTransfer.files[0]; if (f) handleFile(f); };

  const runAnalysis = async () => {
    if (!jobDesc.trim()) { setError("Please paste a job description."); return; }
    setError(""); setStage("analyzing"); setProgress(0);
    const steps: [number, string][] = [[10,"Parsing resume structure…"],[25,"Extracting skills and projects…"],[42,"Comparing against job description…"],[58,"Scoring each section…"],[72,"Detecting keyword gaps…"],[85,"Writing improvement suggestions…"],[94,"Assessing risks and benchmarks…"]];
    steps.forEach(([p, label], i) => setTimeout(() => { setProgress(p); setProgLabel(label); }, i * 400));
    try {
      const token = localStorage.getItem("token");
      const res = await fetch("/ai/analyze", { method: "POST", headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` }, body: JSON.stringify({ resumeText, jobDescription: jobDesc }) });
      if (!res.ok) throw new Error(`Server ${res.status}`);
      const data: Results = await res.json();
      setTimeout(() => { setProgress(100); setProgLabel("Done!"); setTimeout(() => { setResults(data); if (data.resumeData) setResumeData(data.resumeData); setStage("results"); setTab("overview"); }, 400); }, 2900);
    } catch (err: unknown) { setStage("jd"); setError(err instanceof Error ? err.message : "Analysis failed. Check your connection."); }
  };

  const reset = () => { setStage("upload"); setFileName(""); setResumeText(""); setJobDesc(""); setResults(null); setError(""); setProgress(0); };

  const downloadReport = () => {
    if (!results) return;
    downloadResumePDF({
      matchScore: results.matchScore,
      alignmentScore: results.alignmentScore,
      summary: results.summary,
      matchedSkills: results.matchedSkills,
      missingSkills: results.missingSkills,
      priorityActionPlan: results.priorityActionPlan,
      riskAnalysis: results.riskAnalysis,
      keywordOptimization: results.keywordOptimization,
      scoreBreakdown: results.scoreBreakdown,
      sections: results.sections,
    });
  };

  const tabs: { id: Tab; label: string; icon: React.ReactNode }[] = [
    { id:"overview",  label:"Overview",       icon:<BarChart2 size={12}/> },
    { id:"keywords",  label:"Keyword Coach",  icon:<Target size={12}/> },
    { id:"rewrite",   label:"Rewrite",        icon:<Layers size={12}/> },
    { id:"sections",  label:"Sections",       icon:<BookOpen size={12}/> },
    { id:"risk",      label:"Risk & Bench",   icon:<Shield size={12}/> },
    { id:"action",    label:"Action Plan",    icon:<Award size={12}/> },
  ];

  return (
    <div style={{ maxWidth: 920, margin: "0 auto" }}>
      <div style={{ marginBottom: 22 }}>
        <div className="tag" style={{ display:"inline-flex",alignItems:"center",gap:6,borderRadius:100,padding:"5px 14px",marginBottom:10,fontSize:"0.75rem" }}><FileText size={11}/> AI Career Coach</div>
        <h1 style={{ fontFamily:"Syne,sans-serif",fontWeight:800,fontSize:"clamp(1.7rem,3vw,2.1rem)",letterSpacing:"-0.03em",color:"var(--text-primary)",marginBottom:7 }}>Resume <span className="gradient-text">Career Coach</span></h1>
        <p style={{ color:"var(--text-secondary)",fontSize:"0.9rem" }}>Not just an ATS checker — score breakdown, keyword placement guide, resume rewrites, risk analysis and interview prep.</p>
      </div>

      {/* Step indicator */}
      {stage !== "results" && (
        <div style={{ display:"flex",alignItems:"center",gap:6,marginBottom:22 }}>
          {[{n:1,label:"Upload Resume",active:stage==="upload"},{n:2,label:"Add Job Description",active:stage==="jd"},{n:3,label:"AI Analysis",active:stage==="analyzing"}].map((s,i) => (
            <div key={s.n} style={{ display:"flex",alignItems:"center",gap:6 }}>
              <div style={{ width:26,height:26,borderRadius:"50%",display:"flex",alignItems:"center",justifyContent:"center",fontSize:"0.7rem",fontWeight:800,background:s.active?"linear-gradient(135deg,var(--accent-blue),var(--accent-cyan))":"var(--bg-primary)",border:`2px solid ${s.active?"var(--accent-blue)":"var(--border)"}`,color:s.active?"#fff":"var(--text-muted)" }}>{s.n}</div>
              <span style={{ fontSize:"0.76rem",fontWeight:s.active?700:500,color:s.active?"var(--text-primary)":"var(--text-muted)" }}>{s.label}</span>
              {i < 2 && <ChevronRight size={12} color="var(--border)" />}
            </div>
          ))}
        </div>
      )}

      {/* Upload */}
      {stage === "upload" && (
        <div className="card" onClick={() => fileRef.current?.click()} onDragOver={e=>{e.preventDefault();setDragOver(true);}} onDragLeave={()=>setDragOver(false)} onDrop={handleDrop} style={{ borderRadius:16,padding:"56px 36px",textAlign:"center",cursor:"pointer",border:`2px dashed ${dragOver?"var(--accent-blue)":"var(--border)"}`,background:dragOver?"var(--glow-blue)":"var(--bg-card)",transition:"all 0.2s" }}>
          <div style={{ width:66,height:66,borderRadius:16,background:"var(--bg-primary)",border:"1px solid var(--border-strong)",display:"flex",alignItems:"center",justifyContent:"center",margin:"0 auto 18px" }}><Upload size={28} color="var(--accent-blue)" /></div>
          <h3 style={{ fontFamily:"Syne,sans-serif",fontWeight:700,fontSize:"1.1rem",color:"var(--text-primary)",marginBottom:7 }}>Drop your resume here</h3>
          <p style={{ color:"var(--text-muted)",fontSize:"0.85rem",marginBottom:18 }}>Supports PDF, .txt and .md — or click to browse</p>
          <div style={{ display:"flex",gap:7,justifyContent:"center",marginBottom:20 }}>
            {[".pdf",".txt",".md"].map(ext => <span key={ext} style={{ padding:"3px 11px",borderRadius:7,background:"var(--bg-primary)",border:"1px solid var(--border)",fontSize:"0.75rem",color:"var(--text-muted)",fontWeight:600 }}>{ext}</span>)}
          </div>
          <button className="btn-primary" style={{ padding:"9px 26px",borderRadius:10,fontSize:"0.87rem" }}><span style={{ position:"relative",zIndex:1 }}>Choose File</span></button>
          <input ref={fileRef} type="file" accept=".pdf,.txt,.md" style={{ display:"none" }} onChange={e=>{if(e.target.files?.[0])handleFile(e.target.files[0]);}} />
          {fileError && <div style={{ marginTop:14,padding:"8px 12px",borderRadius:7,background:"rgba(239,68,68,0.07)",border:"1px solid rgba(239,68,68,0.2)",fontSize:"0.78rem",color:"#ef4444" }}>⚠ {fileError}</div>}
        </div>
      )}

      {/* JD */}
      {stage === "jd" && (
        <div style={{ display:"grid",gap:12 }}>
          <div className="card" style={{ borderRadius:13,padding:"14px 18px",display:"flex",alignItems:"center",gap:11 }}>
            <div style={{ width:36,height:36,borderRadius:8,background:"rgba(0,229,160,0.1)",border:"1px solid rgba(0,229,160,0.25)",display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0 }}><FileText size={15} color="var(--accent-green)" /></div>
            <div style={{ flex:1 }}><div style={{ fontWeight:700,fontSize:"0.85rem",color:"var(--text-primary)",marginBottom:1 }}>{fileName}</div><div style={{ fontSize:"0.72rem",color:"var(--text-muted)" }}>{resumeText.length} characters · {resumeText.trim().split(/\s+/).length} words extracted</div></div>
            <CheckCircle size={15} color="var(--accent-green)" />
            <button onClick={reset} style={{ background:"none",border:"none",cursor:"pointer",color:"var(--text-muted)",fontSize:"0.73rem" }}>Change</button>
          </div>
          <div className="card" style={{ borderRadius:13,padding:"18px 22px" }}>
            <div style={{ fontFamily:"Syne,sans-serif",fontWeight:700,fontSize:"0.9rem",color:"var(--text-primary)",marginBottom:5 }}>Paste Job Description</div>
            <p style={{ fontSize:"0.76rem",color:"var(--text-muted)",marginBottom:11 }}>The more detailed the JD, the more accurate every insight.</p>
            <textarea value={jobDesc} onChange={e=>setJobDesc(e.target.value)} placeholder="Paste the full job description — requirements, responsibilities, tech stack, preferred skills…" style={{ width:"100%",minHeight:200,padding:"11px 13px",borderRadius:9,fontSize:"0.875rem",resize:"vertical",fontFamily:"inherit",background:"var(--input-bg)",border:"1px solid var(--border)",color:"var(--text-primary)",outline:"none",lineHeight:1.65,transition:"border-color 0.2s" }} onFocus={e=>(e.currentTarget.style.borderColor="var(--accent-blue)")} onBlur={e=>(e.currentTarget.style.borderColor="var(--border)")} />
            <div style={{ display:"flex",justifyContent:"space-between",marginTop:5,marginBottom:11 }}>
              <span style={{ fontSize:"0.7rem",color:"var(--text-muted)" }}>{jobDesc.trim().split(/\s+/).filter(Boolean).length} words</span>
              {jobDesc.length > 0 && jobDesc.length < 100 && <span style={{ fontSize:"0.7rem",color:"#f59e0b" }}>Tip: paste the full JD for best results</span>}
            </div>
            {error && <div style={{ padding:"8px 11px",borderRadius:7,background:"rgba(239,68,68,0.07)",border:"1px solid rgba(239,68,68,0.2)",marginBottom:11,fontSize:"0.78rem",color:"#ef4444" }}>⚠ {error}</div>}
            <div style={{ display:"flex",gap:9 }}>
              <button onClick={runAnalysis} className="btn-primary" style={{ padding:"10px 26px",borderRadius:10,fontSize:"0.875rem",flex:1 }}><span style={{ position:"relative",zIndex:1,display:"flex",alignItems:"center",gap:7,justifyContent:"center" }}><Brain size={14}/> Analyze with AI Career Coach</span></button>
              <button onClick={reset} className="btn-ghost" style={{ padding:"10px 18px",borderRadius:10,fontSize:"0.85rem" }}>Start Over</button>
            </div>
          </div>
        </div>
      )}

      {/* Analyzing */}
      {stage === "analyzing" && (
        <div className="card" style={{ borderRadius:16,padding:"56px 36px",textAlign:"center" }}>
          <div style={{ width:66,height:66,borderRadius:"50%",background:"var(--glow-blue)",border:"1px solid var(--border-strong)",display:"flex",alignItems:"center",justifyContent:"center",margin:"0 auto 22px" }}><Brain size={28} color="var(--accent-blue)" /></div>
          <h3 style={{ fontFamily:"Syne,sans-serif",fontWeight:700,fontSize:"1.1rem",color:"var(--text-primary)",marginBottom:7 }}>AI Career Coach is analysing…</h3>
          <p style={{ color:"var(--text-muted)",fontSize:"0.85rem",marginBottom:28 }}>{progLabel}</p>
          <div style={{ maxWidth:400,margin:"0 auto" }}>
            <div style={{ height:6,background:"var(--border)",borderRadius:4,overflow:"hidden" }}><div style={{ height:"100%",width:`${progress}%`,background:"linear-gradient(90deg,var(--accent-blue),var(--accent-cyan))",borderRadius:4,transition:"width 0.4s ease" }} /></div>
            <div style={{ display:"flex",justifyContent:"space-between",marginTop:7 }}><span style={{ fontSize:"0.7rem",color:"var(--text-muted)" }}>{progLabel}</span><span style={{ fontSize:"0.7rem",color:"var(--accent-blue)",fontWeight:700 }}>{progress}%</span></div>
          </div>
          <div style={{ display:"flex",justifyContent:"center",gap:14,marginTop:26,flexWrap:"wrap" }}>
            {["Parsing resume","Skill matching","Score breakdown","Risk analysis","Writing tips","Interview prep"].map((t,i) => (
              <div key={i} style={{ display:"flex",alignItems:"center",gap:4,fontSize:"0.72rem",color:progress>i*16?"var(--accent-green)":"var(--text-muted)" }}><CheckCircle size={10} color={progress>i*16?"var(--accent-green)":"var(--border)"}/> {t}</div>
            ))}
          </div>
        </div>
      )}

      {/* Results */}
      {stage === "results" && results && (
        <div style={{ display:"flex",flexDirection:"column",gap:14 }}>
          {/* Score hero */}
          <div className="card" style={{ borderRadius:16,padding:"22px 26px" }}>
            <div style={{ display:"flex",gap:18,alignItems:"center",flexWrap:"wrap" }}>
              <div style={{ display:"flex",flexDirection:"column",alignItems:"center",gap:3 }}><ScoreRing score={results.matchScore} size={108}/><div style={{ fontSize:"0.66rem",fontWeight:700,color:"var(--text-muted)",textTransform:"uppercase",letterSpacing:"0.06em" }}>ATS Match</div></div>
              <div style={{ display:"flex",flexDirection:"column",alignItems:"center",gap:3 }}><ScoreRing score={results.alignmentScore} size={84} label="%"/><div style={{ fontSize:"0.66rem",fontWeight:700,color:"var(--text-muted)",textTransform:"uppercase",letterSpacing:"0.06em" }}>Alignment</div></div>
              <div style={{ flex:1,minWidth:200 }}>
                <div style={{ fontFamily:"Syne,sans-serif",fontWeight:800,fontSize:"1.1rem",color:"var(--text-primary)",marginBottom:5 }}>
                  {results.matchScore >= 75 ? "Strong Match 🎉" : results.matchScore >= 50 ? "Moderate Match ⚠️" : "Needs Work ❌"}
                  {results.roleOptimization?.detectedRole && <span style={{ marginLeft:8,fontSize:"0.7rem",padding:"2px 9px",borderRadius:100,background:"var(--glow-blue)",border:"1px solid var(--border-strong)",color:"var(--accent-blue)",fontWeight:700 }}>{results.roleOptimization.detectedRole}</span>}
                </div>
                <p style={{ color:"var(--text-secondary)",fontSize:"0.83rem",lineHeight:1.65,marginBottom:12 }}>{results.summary}</p>
                {results.scoreBreakdown && (
                  <div style={{ display:"flex",flexDirection:"column",gap:5 }}>
                    {[{label:"Skills Match",val:results.scoreBreakdown.skillsMatch?.score,color:"var(--accent-blue)"},{label:"Experience",val:results.scoreBreakdown.experienceStrength?.score,color:"var(--accent-purple)"},{label:"Keywords",val:results.scoreBreakdown.keywordCoverage?.score,color:"var(--accent-cyan)"}].map(s => (
                      <div key={s.label} style={{ display:"flex",alignItems:"center",gap:7 }}>
                        <span style={{ fontSize:"0.68rem",color:"var(--text-muted)",width:88,flexShrink:0 }}>{s.label}</span>
                        <ScoreBar value={s.val||0} color={s.color}/>
                        <span style={{ fontSize:"0.68rem",fontWeight:700,color:s.color,width:24,textAlign:"right" }}>{s.val}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
              <div style={{ display:"flex",flexDirection:"column",gap:7 }}>
                <button onClick={downloadReport} className="btn-ghost" style={{ padding:"8px 14px",borderRadius:8,fontSize:"0.78rem",display:"flex",alignItems:"center",gap:5,whiteSpace:"nowrap" }}><Download size={12}/> PDF Report</button>
                <button onClick={reset} className="btn-ghost" style={{ padding:"8px 14px",borderRadius:8,fontSize:"0.78rem",display:"flex",alignItems:"center",gap:5,whiteSpace:"nowrap" }}><RefreshCw size={12}/> Try Again</button>
              </div>
            </div>
          </div>

          {/* Tabs */}
          <div style={{ display:"flex",gap:5,overflowX:"auto",paddingBottom:3 }}>
            {tabs.map(t => <button key={t.id} onClick={()=>setTab(t.id)} style={{ display:"flex",alignItems:"center",gap:5,padding:"7px 13px",borderRadius:8,cursor:"pointer",fontWeight:600,fontSize:"0.78rem",border:`1px solid ${tab===t.id?"var(--accent-blue)":"var(--border)"}`,background:tab===t.id?"var(--glow-blue)":"var(--bg-primary)",color:tab===t.id?"var(--accent-blue)":"var(--text-muted)",transition:"all 0.18s",whiteSpace:"nowrap",flexShrink:0 }}>{t.icon} {t.label}</button>)}
          </div>

          {/* Overview */}
          {tab === "overview" && (
            <div style={{ display:"flex",flexDirection:"column",gap:12 }}>
              {results.scoreBreakdown && (
                <div className="card" style={{ borderRadius:13,padding:"16px 18px" }}>
                  <div style={{ fontFamily:"Syne,sans-serif",fontWeight:700,fontSize:"0.85rem",color:"var(--text-primary)",marginBottom:12,display:"flex",alignItems:"center",gap:6 }}><Activity size={13} color="var(--accent-blue)"/> Why You Got This Score</div>
                  {[{label:"Skills Match",data:results.scoreBreakdown.skillsMatch,color:"var(--accent-blue)",icon:<Star size={12}/>},{label:"Experience",data:results.scoreBreakdown.experienceStrength,color:"var(--accent-purple)",icon:<Briefcase size={12}/>},{label:"Keywords",data:results.scoreBreakdown.keywordCoverage,color:"var(--accent-cyan)",icon:<MessageSquare size={12}/>}].map(s => s.data && (
                    <div key={s.label} style={{ padding:"10px 12px",borderRadius:9,background:"var(--bg-primary)",border:"1px solid var(--border)",marginBottom:8 }}>
                      <div style={{ display:"flex",alignItems:"center",gap:7,marginBottom:6 }}><span style={{color:s.color}}>{s.icon}</span><span style={{fontWeight:700,fontSize:"0.8rem",color:"var(--text-primary)",flex:1}}>{s.label}</span><span style={{fontFamily:"Syne,sans-serif",fontWeight:800,fontSize:"1.05rem",color:s.color}}>{s.data.score}</span><span style={{fontSize:"0.68rem",color:"var(--text-muted)"}}>/100</span></div>
                      <div style={{ height:3,borderRadius:2,background:"var(--border)",marginBottom:6,overflow:"hidden" }}><div style={{width:`${s.data.score}%`,height:"100%",background:s.color,borderRadius:2,transition:"width 0.8s ease"}}/></div>
                      <p style={{ fontSize:"0.75rem",color:"var(--text-secondary)",lineHeight:1.6,margin:0 }}>{s.data.reason}</p>
                    </div>
                  ))}
                </div>
              )}
              <div style={{ display:"grid",gridTemplateColumns:"1fr 1fr",gap:12 }}>
                <div className="card" style={{ borderRadius:13,padding:"16px 18px" }}>
                  <div style={{ display:"flex",alignItems:"center",gap:7,marginBottom:11 }}><CheckCircle size={13} color="var(--accent-green)"/><span style={{fontFamily:"Syne,sans-serif",fontWeight:700,fontSize:"0.85rem",color:"var(--text-primary)"}}>Matched Skills</span><span style={{marginLeft:"auto",fontSize:"0.68rem",fontWeight:700,color:"var(--accent-green)",padding:"1px 7px",borderRadius:100,background:"rgba(0,229,160,0.1)"}}>{results.matchedSkills.length}</span></div>
                  <div style={{ display:"flex",flexWrap:"wrap",gap:5 }}>{results.matchedSkills.length>0?results.matchedSkills.map(s=><Tag key={s} label={s} type="matched"/>):<p style={{fontSize:"0.76rem",color:"var(--text-muted)"}}>No matched skills found.</p>}</div>
                </div>
                <div className="card" style={{ borderRadius:13,padding:"16px 18px" }}>
                  <div style={{ display:"flex",alignItems:"center",gap:7,marginBottom:11 }}><XCircle size={13} color="#ef4444"/><span style={{fontFamily:"Syne,sans-serif",fontWeight:700,fontSize:"0.85rem",color:"var(--text-primary)"}}>Missing Skills</span><span style={{marginLeft:"auto",fontSize:"0.68rem",fontWeight:700,color:"#ef4444",padding:"1px 7px",borderRadius:100,background:"rgba(239,68,68,0.08)"}}>{results.missingSkills.length}</span></div>
                  <div style={{ display:"flex",flexWrap:"wrap",gap:5 }}>{results.missingSkills.length>0?results.missingSkills.map(s=><Tag key={s} label={s} type="missing"/>):<p style={{fontSize:"0.76rem",color:"var(--accent-green)"}}>All required skills present! 🎉</p>}</div>
                </div>
              </div>
              {results.impactAnalysis && (
                <div className="card" style={{ borderRadius:13,padding:"14px 16px",border:`1px solid ${results.impactAnalysis.hasMetrics?"rgba(0,229,160,0.2)":"rgba(245,158,11,0.2)"}` }}>
                  <div style={{ display:"flex",alignItems:"center",gap:7,marginBottom:8 }}><TrendingUp size={13} color={results.impactAnalysis.hasMetrics?"var(--accent-green)":"#f59e0b"}/><span style={{fontFamily:"Syne,sans-serif",fontWeight:700,fontSize:"0.82rem",color:"var(--text-primary)"}}>Impact & Metrics</span><span style={{marginLeft:"auto",fontSize:"0.7rem",padding:"2px 8px",borderRadius:100,fontWeight:700,background:results.impactAnalysis.hasMetrics?"rgba(0,229,160,0.1)":"rgba(245,158,11,0.1)",color:results.impactAnalysis.hasMetrics?"var(--accent-green)":"#f59e0b",border:`1px solid ${results.impactAnalysis.hasMetrics?"rgba(0,229,160,0.25)":"rgba(245,158,11,0.25)"}`}}>{results.impactAnalysis.hasMetrics?"Metrics Found ✓":"No Metrics ⚠"}</span></div>
                  {results.impactAnalysis.metricsFound?.length>0 && <div style={{display:"flex",flexWrap:"wrap",gap:5,marginBottom:8}}>{results.impactAnalysis.metricsFound.map((m,i)=><span key={i} style={{padding:"2px 9px",borderRadius:100,fontSize:"0.7rem",fontWeight:600,background:"rgba(0,229,160,0.08)",border:"1px solid rgba(0,229,160,0.2)",color:"var(--accent-green)"}}>{m}</span>)}</div>}
                  <p style={{ fontSize:"0.78rem",color:"var(--text-secondary)",lineHeight:1.6,margin:0 }}>{results.impactAnalysis.suggestion}</p>
                </div>
              )}
              {results.interviewLinkage && (
                <div className="card" style={{ borderRadius:13,padding:"14px 16px" }}>
                  <div style={{ fontFamily:"Syne,sans-serif",fontWeight:700,fontSize:"0.82rem",color:"var(--text-primary)",marginBottom:10,display:"flex",alignItems:"center",gap:6 }}><MessageSquare size={12} color="var(--accent-cyan)"/> Interview Prep — Likely Topics</div>
                  {results.interviewLinkage.likelyTopics?.length>0 && <div style={{display:"flex",flexWrap:"wrap",gap:5,marginBottom:9}}>{results.interviewLinkage.likelyTopics.map(t=><Tag key={t} label={t} type="neutral"/>)}</div>}
                  {results.interviewLinkage.tip && <div style={{padding:"8px 10px",borderRadius:7,background:"rgba(0,229,160,0.04)",border:"1px solid rgba(0,229,160,0.15)",fontSize:"0.75rem",color:"var(--text-secondary)",lineHeight:1.6}}>💡 {results.interviewLinkage.tip}</div>}
                </div>
              )}
            </div>
          )}

          {/* Keywords */}
          {tab === "keywords" && (
            <div style={{ display:"flex",flexDirection:"column",gap:12 }}>
              {results.keywordDensity?.length>0 && (
                <div className="card" style={{ borderRadius:13,padding:"16px 18px" }}>
                  <div style={{ fontFamily:"Syne,sans-serif",fontWeight:700,fontSize:"0.85rem",color:"var(--text-primary)",marginBottom:12,display:"flex",alignItems:"center",gap:6 }}><Activity size={13} color="var(--accent-blue)"/> Keyword Density</div>
                  {results.keywordDensity.map(k => (
                    <div key={k.keyword} style={{ display:"flex",alignItems:"center",gap:9,padding:"9px 11px",borderRadius:8,background:"var(--bg-primary)",border:`1px solid ${k.status==="missing"?"rgba(239,68,68,0.2)":k.status==="low"?"rgba(245,158,11,0.2)":"var(--border)"}`,marginBottom:7 }}>
                      <span style={{fontSize:"0.8rem",fontWeight:700,color:"var(--text-primary)",width:110,flexShrink:0}}>{k.keyword}</span>
                      <div style={{flex:1,display:"flex",gap:3}}>{Array.from({length:k.recommended}).map((_,i)=><div key={i} style={{width:18,height:5,borderRadius:2,background:i<k.count?(k.status==="good"?"var(--accent-green)":"#f59e0b"):"var(--border)"}}/>)}</div>
                      <span style={{fontSize:"0.7rem",color:"var(--text-muted)",flexShrink:0}}>{k.count}/{k.recommended}x</span>
                      <span style={{padding:"2px 7px",borderRadius:100,fontSize:"0.62rem",fontWeight:700,flexShrink:0,background:k.status==="good"?"rgba(0,229,160,0.1)":k.status==="missing"?"rgba(239,68,68,0.08)":"rgba(245,158,11,0.1)",color:k.status==="good"?"var(--accent-green)":k.status==="missing"?"#ef4444":"#f59e0b"}}>{k.status==="good"?"Good":k.status==="missing"?"Missing":"Low"}</span>
                    </div>
                  ))}
                </div>
              )}
              {results.keywordOptimization?.length>0 && (
                <div className="card" style={{ borderRadius:13,padding:"16px 18px" }}>
                  <div style={{ fontFamily:"Syne,sans-serif",fontWeight:700,fontSize:"0.85rem",color:"var(--text-primary)",marginBottom:5,display:"flex",alignItems:"center",gap:6 }}><Target size={13} color="var(--accent-cyan)"/> Smart Keyword Placement</div>
                  <p style={{ fontSize:"0.76rem",color:"var(--text-muted)",marginBottom:12 }}>Exactly where to add each missing skill and how to phrase it.</p>
                  {results.keywordOptimization.map((k,i) => (
                    <div key={i} style={{ borderRadius:9,border:"1px solid var(--border)",overflow:"hidden",marginBottom:9 }}>
                      <div style={{ display:"flex",alignItems:"center",gap:9,padding:"9px 12px",background:"var(--bg-primary)",borderBottom:"1px solid var(--border)" }}>
                        <XCircle size={12} color="#ef4444"/><span style={{fontWeight:700,fontSize:"0.82rem",color:"var(--text-primary)",flex:1}}>{k.skill}</span>
                        <span style={{fontSize:"0.7rem",padding:"2px 9px",borderRadius:100,fontWeight:700,background:"var(--glow-blue)",border:"1px solid var(--border-strong)",color:"var(--accent-blue)"}}>Add under: {k.placement}</span>
                      </div>
                      <div style={{ padding:"9px 12px" }}>
                        <div style={{ fontSize:"0.65rem",fontWeight:700,color:"var(--text-muted)",marginBottom:4,textTransform:"uppercase",letterSpacing:"0.05em" }}>Suggested phrasing</div>
                        <div style={{ fontSize:"0.78rem",color:"var(--accent-green)",fontStyle:"italic",padding:"7px 9px",borderRadius:6,background:"rgba(0,229,160,0.04)",border:"1px solid rgba(0,229,160,0.15)" }}>"{k.howToWrite}"</div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
              {results.roleOptimization?.tailoredTips?.length>0 && (
                <div className="card" style={{ borderRadius:13,padding:"14px 16px" }}>
                  <div style={{ fontFamily:"Syne,sans-serif",fontWeight:700,fontSize:"0.82rem",color:"var(--text-primary)",marginBottom:5,display:"flex",alignItems:"center",gap:6 }}><Lightbulb size={12} color="#f59e0b"/> Role Optimisation <span style={{fontSize:"0.7rem",padding:"2px 8px",borderRadius:100,fontWeight:700,background:"rgba(245,158,11,0.1)",color:"#f59e0b",border:"1px solid rgba(245,158,11,0.2)"}}>{results.roleOptimization.detectedRole}</span></div>
                  {results.roleOptimization.tailoredTips.map((tip,i) => <div key={i} style={{display:"flex",gap:7,marginBottom:7,alignItems:"flex-start"}}><ArrowRight size={10} color="#f59e0b" style={{flexShrink:0,marginTop:3}}/><span style={{fontSize:"0.77rem",color:"var(--text-secondary)",lineHeight:1.55}}>{tip}</span></div>)}
                </div>
              )}
            </div>
          )}

          {/* Rewrite */}
          {tab === "rewrite" && (
            <div style={{ display:"flex",flexDirection:"column",gap:11 }}>
              <div style={{ padding:"10px 14px",borderRadius:9,background:"rgba(59,142,255,0.06)",border:"1px solid rgba(59,142,255,0.15)",fontSize:"0.78rem",color:"var(--text-secondary)",display:"flex",gap:7,alignItems:"center" }}><Lightbulb size={13} color="var(--accent-blue)" style={{flexShrink:0}}/> Copy the improved versions into your resume to boost your ATS score.</div>
              {results.resumeRewrites?.length>0 ? results.resumeRewrites.map((r,i) => (
                <div key={i} className="card" style={{ borderRadius:13,padding:"16px 18px" }}>
                  <div style={{ fontSize:"0.7rem",fontWeight:700,color:"var(--accent-purple)",textTransform:"uppercase",letterSpacing:"0.06em",marginBottom:12,display:"flex",alignItems:"center",gap:5 }}><Layers size={11}/> {r.section}</div>
                  <div style={{ display:"grid",gridTemplateColumns:"1fr 1fr",gap:10 }}>
                    <div><div style={{fontSize:"0.62rem",fontWeight:700,color:"#ef4444",marginBottom:6,display:"flex",alignItems:"center",gap:3}}><TrendingDown size={9}/> BEFORE</div><div style={{padding:"10px 12px",borderRadius:8,background:"rgba(239,68,68,0.04)",border:"1px solid rgba(239,68,68,0.15)",fontSize:"0.78rem",color:"var(--text-muted)",lineHeight:1.65}}>{r.original}</div></div>
                    <div><div style={{fontSize:"0.62rem",fontWeight:700,color:"var(--accent-green)",marginBottom:6,display:"flex",alignItems:"center",gap:3}}><TrendingUp size={9}/> AFTER</div><div style={{padding:"10px 12px",borderRadius:8,background:"rgba(0,229,160,0.04)",border:"1px solid rgba(0,229,160,0.2)",fontSize:"0.78rem",color:"var(--text-secondary)",lineHeight:1.65}}>{r.improved}</div></div>
                  </div>
                </div>
              )) : <div className="card" style={{borderRadius:13,padding:"28px",textAlign:"center",color:"var(--text-muted)",fontSize:"0.82rem"}}>No rewrites generated. Your content may already be strong.</div>}
            </div>
          )}

          {/* Sections */}
          {tab === "sections" && (
            <div style={{ display:"flex",flexDirection:"column",gap:11 }}>
              {([{key:"skills",icon:<Star size={14}/>,label:"Skills",color:"var(--accent-blue)"},{key:"projects",icon:<Briefcase size={14}/>,label:"Projects",color:"var(--accent-cyan)"},{key:"experience",icon:<TrendingUp size={14}/>,label:"Experience",color:"var(--accent-purple)"},{key:"education",icon:<GraduationCap size={14}/>,label:"Education",color:"#f59e0b"}] as const).map(({key,icon,label,color}) => {
                const sec = results.sections[key]; if (!sec) return null;
                return (
                  <div key={key} className="card" style={{ borderRadius:13,padding:"16px 18px" }}>
                    <div style={{ display:"flex",alignItems:"center",gap:9,marginBottom:12 }}>
                      <div style={{ width:34,height:34,borderRadius:8,background:`${color}14`,border:`1px solid ${color}25`,display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0,color }}>{icon}</div>
                      <div style={{ flex:1 }}>
                        <div style={{ display:"flex",alignItems:"center",gap:7,marginBottom:3 }}><span style={{fontFamily:"Syne,sans-serif",fontWeight:700,fontSize:"0.85rem",color:"var(--text-primary)"}}>{label} Section</span><StatusChip status={sec.status}/></div>
                        <div style={{ display:"flex",alignItems:"center",gap:7 }}>
                          <div style={{ width:110,height:3,borderRadius:2,background:"var(--border)",overflow:"hidden" }}><div style={{width:`${sec.score}%`,height:"100%",background:color,borderRadius:2}}/></div>
                          <span style={{fontSize:"0.7rem",fontWeight:700,color}}>{sec.score}/100</span>
                        </div>
                      </div>
                    </div>
                    <p style={{ fontSize:"0.8rem",color:"var(--text-secondary)",lineHeight:1.65,marginBottom:10 }}>{sec.feedback}</p>
                    {sec.suggestions.length>0 && <div style={{padding:"9px 11px",borderRadius:8,background:"var(--bg-primary)",border:"1px solid var(--border)"}}>{sec.suggestions.map((s,i)=><div key={i} style={{display:"flex",gap:6,marginBottom:i<sec.suggestions.length-1?6:0,alignItems:"flex-start"}}><ArrowRight size={10} color={color} style={{flexShrink:0,marginTop:2}}/><span style={{fontSize:"0.76rem",color:"var(--text-secondary)",lineHeight:1.5}}>{s}</span></div>)}</div>}
                  </div>
                );
              })}
            </div>
          )}

          {/* Risk & Benchmark */}
          {tab === "risk" && (
            <div style={{ display:"flex",flexDirection:"column",gap:12 }}>
              {results.riskAnalysis?.length>0 && (
                <div className="card" style={{ borderRadius:13,padding:"16px 18px" }}>
                  <div style={{ fontFamily:"Syne,sans-serif",fontWeight:700,fontSize:"0.85rem",color:"var(--text-primary)",marginBottom:5,display:"flex",alignItems:"center",gap:6 }}><Shield size={13} color="#ef4444"/> Risk Factors</div>
                  <p style={{ fontSize:"0.75rem",color:"var(--text-muted)",marginBottom:12 }}>Potential rejection triggers based on your resume vs the JD.</p>
                  {results.riskAnalysis.map((r,i) => (
                    <div key={i} style={{ display:"flex",gap:10,padding:"10px 12px",borderRadius:9,background:"var(--bg-primary)",border:`1px solid ${r.level==="high"?"rgba(239,68,68,0.2)":r.level==="medium"?"rgba(245,158,11,0.2)":"var(--border)"}`,marginBottom:7,alignItems:"flex-start" }}>
                      <AlertTriangle size={12} color={r.level==="high"?"#ef4444":r.level==="medium"?"#f59e0b":"var(--accent-blue)"} style={{flexShrink:0,marginTop:2}}/>
                      <span style={{fontSize:"0.78rem",color:"var(--text-secondary)",lineHeight:1.55,flex:1}}>{r.risk}</span>
                      <span style={{padding:"2px 7px",borderRadius:100,fontSize:"0.6rem",fontWeight:800,flexShrink:0,background:r.level==="high"?"rgba(239,68,68,0.08)":r.level==="medium"?"rgba(245,158,11,0.08)":"var(--glow-blue)",color:r.level==="high"?"#ef4444":r.level==="medium"?"#f59e0b":"var(--accent-blue)",textTransform:"uppercase"}}>{r.level}</span>
                    </div>
                  ))}
                </div>
              )}
              {results.benchmarkComparison && Object.keys(results.benchmarkComparison).length>0 && (
                <div className="card" style={{ borderRadius:13,padding:"16px 18px" }}>
                  <div style={{ fontFamily:"Syne,sans-serif",fontWeight:700,fontSize:"0.85rem",color:"var(--text-primary)",marginBottom:5,display:"flex",alignItems:"center",gap:6 }}><BarChart2 size={13} color="var(--accent-blue)"/> Industry Benchmark</div>
                  <p style={{ fontSize:"0.75rem",color:"var(--text-muted)",marginBottom:12 }}>How you compare to typical candidates for this role.</p>
                  {(["overall","skills","projects","experience"] as const).map(key => {
                    const b = results.benchmarkComparison[key]; if (!b) return null;
                    const rc = b.rating==="strong"||b.rating==="above average"?"var(--accent-green)":b.rating==="average"?"#f59e0b":"#ef4444";
                    return (
                      <div key={key} style={{ display:"flex",gap:11,padding:"10px 12px",borderRadius:9,background:"var(--bg-primary)",border:"1px solid var(--border)",marginBottom:7,alignItems:"flex-start" }}>
                        <div style={{ width:70,flexShrink:0 }}><div style={{fontSize:"0.66rem",fontWeight:700,color:"var(--text-muted)",textTransform:"capitalize",marginBottom:3}}>{key}</div><span style={{padding:"2px 7px",borderRadius:100,fontSize:"0.68rem",fontWeight:700,background:`${rc}15`,color:rc,textTransform:"capitalize"}}>{b.rating}</span></div>
                        <span style={{ fontSize:"0.76rem",color:"var(--text-secondary)",lineHeight:1.55 }}>{b.note}</span>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* Action Plan */}
          {tab === "action" && (
            <div style={{ display:"flex",flexDirection:"column",gap:12 }}>
              {results.priorityActionPlan?.length>0 && (
                <div className="card" style={{ borderRadius:13,padding:"16px 18px" }}>
                  <div style={{ fontFamily:"Syne,sans-serif",fontWeight:700,fontSize:"0.85rem",color:"var(--text-primary)",marginBottom:5,display:"flex",alignItems:"center",gap:6 }}><Award size={13} color="var(--accent-blue)"/> Priority Action Plan</div>
                  <p style={{ fontSize:"0.75rem",color:"var(--text-muted)",marginBottom:14 }}>Fix in this order for maximum ATS score improvement.</p>
                  {(["high","medium","low"] as const).map(level => {
                    const items = results.priorityActionPlan.filter(p => p.priority === level); if (!items.length) return null;
                    return (
                      <div key={level} style={{ marginBottom:14 }}>
                        <div style={{ display:"flex",alignItems:"center",gap:6,marginBottom:8 }}><PBadge p={level}/><span style={{fontSize:"0.7rem",color:"var(--text-muted)"}}>{items.length} action{items.length>1?"s":""}</span></div>
                        {items.map((item,i) => (
                          <div key={i} style={{ display:"flex",gap:9,padding:"10px 12px",borderRadius:8,background:"var(--bg-primary)",border:`1px solid ${level==="high"?"rgba(239,68,68,0.15)":level==="medium"?"rgba(245,158,11,0.15)":"var(--border)"}`,marginBottom:7,alignItems:"flex-start" }}>
                            <div style={{ width:20,height:20,borderRadius:5,background:level==="high"?"rgba(239,68,68,0.1)":level==="medium"?"rgba(245,158,11,0.1)":"var(--glow-blue)",display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0,fontSize:"0.58rem",fontWeight:800,color:level==="high"?"#ef4444":level==="medium"?"#f59e0b":"var(--accent-blue)" }}>{i+1}</div>
                            <span style={{fontSize:"0.78rem",color:"var(--text-secondary)",lineHeight:1.55}}>{item.action}</span>
                          </div>
                        ))}
                      </div>
                    );
                  })}
                </div>
              )}
              {results.contextAwareSuggestions?.suggestions?.length>0 && (
                <div className="card" style={{ borderRadius:13,padding:"14px 16px" }}>
                  <div style={{ fontFamily:"Syne,sans-serif",fontWeight:700,fontSize:"0.82rem",color:"var(--text-primary)",marginBottom:5,display:"flex",alignItems:"center",gap:6 }}><Brain size={12} color="var(--accent-purple)"/> Context-Aware Tips <span style={{fontSize:"0.7rem",padding:"2px 7px",borderRadius:100,fontWeight:700,background:"rgba(139,92,246,0.1)",color:"var(--accent-purple)",border:"1px solid rgba(139,92,246,0.2)",textTransform:"capitalize"}}>{results.contextAwareSuggestions.experienceLevel}</span></div>
                  {results.contextAwareSuggestions.suggestions.map((s,i) => <div key={i} style={{display:"flex",gap:7,marginBottom:8,alignItems:"flex-start"}}><ArrowRight size={10} color="var(--accent-purple)" style={{flexShrink:0,marginTop:3}}/><span style={{fontSize:"0.77rem",color:"var(--text-secondary)",lineHeight:1.55}}>{s}</span></div>)}
                </div>
              )}
              {results.resumeData && (
                <div style={{ padding:"11px 14px",borderRadius:9,background:"rgba(0,229,160,0.05)",border:"1px solid rgba(0,229,160,0.18)",display:"flex",alignItems:"center",gap:9 }}>
                  <CheckCircle size={13} color="var(--accent-green)"/>
                  <span style={{fontSize:"0.76rem",color:"var(--text-secondary)"}}><strong style={{color:"var(--accent-green)"}}>Resume profile saved</strong> — your Mock Interview questions will now be tailored to your skills and projects.</span>
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
