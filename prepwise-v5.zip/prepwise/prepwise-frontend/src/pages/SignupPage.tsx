import { useState, type FormEvent } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Brain, Mail, Lock, User, Eye, EyeOff, ArrowRight, CheckCircle } from "lucide-react";
import { useAuth } from "../context/AuthContext";

type Step = 1 | 2 | 3;
const ROLES    = ["Software Developer (SDE)","Full Stack Developer","Backend Engineer","Frontend Engineer","Data Analyst","ML Engineer"];
const EXP      = ["Fresher (0–1 yr)","Beginner (1–2 yr)","Intermediate (2–4 yr)","Experienced (4+ yr)"];
const CO_TYPES = ["Product Company","Service Company","Startup","Open to All"];
const SKILLS   = ["DSA","System Design","DBMS","OS","CN","Java","Python","React","Node.js","SQL","Spring Boot","AWS","Docker","MongoDB","TypeScript","Git"];

export default function SignupPage() {
  const [step, setStep]     = useState<Step>(1);
  const [showPw, setShowPw] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError]   = useState("");
  const { setUser }         = useAuth();
  const navigate            = useNavigate();

  const [form, setForm] = useState({ name: "", email: "", password: "", targetRole: "", experience: "", companyType: "", skills: [] as string[] });
  const set = (k: keyof typeof form, v: string) => setForm(f => ({ ...f, [k]: v }));
  const toggleSkill = (s: string) => setForm(f => ({ ...f, skills: f.skills.includes(s) ? f.skills.filter(x => x !== s) : [...f.skills, s] }));

  const next = () => {
    setError("");
    if (step === 1) {
      if (!form.name || !form.email || !form.password) { setError("Fill in all fields."); return; }
      if (form.password.length < 8) { setError("Password must be at least 8 characters."); return; }
    } else if (step === 2) {
      if (!form.targetRole || !form.experience || !form.companyType) { setError("Complete your profile."); return; }
    }
    setStep(s => (s + 1) as Step);
  };

  const submit = async (e: FormEvent) => {
    e.preventDefault(); setError(""); setLoading(true);
    try {
      const res  = await fetch("/auth/register", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(form) });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Registration failed");
      localStorage.setItem("token", data.token);
      setUser({ id: data.user?.id || data._id, name: form.name, email: form.email });
      navigate("/dashboard");
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : "Something went wrong");
    } finally { setLoading(false); }
  };

  const StepDot = ({ n }: { n: number }) => (
    <div style={{ width: 28, height: 28, borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "0.75rem", fontWeight: 700, background: step > n ? "var(--accent-green)" : step === n ? "linear-gradient(135deg,var(--accent-blue),var(--accent-cyan))" : "var(--bg-primary)", border: `2px solid ${step >= n ? "transparent" : "var(--border)"}`, color: step >= n ? "#fff" : "var(--text-muted)", transition: "all 0.3s" }}>
      {step > n ? <CheckCircle size={14} /> : n}
    </div>
  );

  return (
    <div style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", padding: "80px 24px 24px", background: "var(--bg-primary)", position: "relative", overflow: "hidden" }}>
      <div className="orb orb-blue" style={{ width: 500, height: 500, top: "-10%", right: "-5%" }} />
      <div className="orb orb-cyan" style={{ width: 400, height: 400, bottom: "10%", left: "-5%" }} />

      <div style={{ width: "100%", maxWidth: 460, position: "relative", zIndex: 1 }}>
        <div style={{ textAlign: "center", marginBottom: 28 }}>
          <Link to="/" style={{ display: "inline-flex", alignItems: "center", gap: 10, textDecoration: "none", marginBottom: 24 }}>
            <div style={{ width: 38, height: 38, borderRadius: 10, background: "linear-gradient(135deg,var(--accent-blue),var(--accent-cyan))", display: "flex", alignItems: "center", justifyContent: "center" }}>
              <Brain size={18} color="white" />
            </div>
            <span style={{ fontFamily: "Syne,sans-serif", fontWeight: 800, fontSize: "1.2rem", color: "var(--text-primary)" }}>Prep<span style={{ color: "var(--accent-blue)" }}>Wise</span></span>
          </Link>
          <h1 style={{ fontFamily: "Syne,sans-serif", fontWeight: 800, fontSize: "1.7rem", color: "var(--text-primary)", marginBottom: 6 }}>Create your account</h1>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 8, marginTop: 16 }}>
            {[1, 2, 3].map(n => (<div key={n} style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <StepDot n={n} />
              {n < 3 && <div style={{ width: 32, height: 2, background: step > n ? "var(--accent-green)" : "var(--border)", borderRadius: 1, transition: "background 0.3s" }} />}
            </div>))}
          </div>
          <p style={{ color: "var(--text-muted)", fontSize: "0.78rem", marginTop: 8 }}>
            {step === 1 ? "Create your account" : step === 2 ? "Tell us your goal" : "Select your skills"}
          </p>
        </div>

        <div className="card" style={{ borderRadius: 18, padding: 28 }}>
          {/* Step 1 */}
          {step === 1 && (
            <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
              {[
                { label: "Full Name", key: "name", type: "text", icon: <User size={14} />, placeholder: "Tejasree Komma" },
                { label: "Email Address", key: "email", type: "email", icon: <Mail size={14} />, placeholder: "you@example.com" },
              ].map(f => (
                <div key={f.key}>
                  <label style={{ display: "block", fontSize: "0.82rem", fontWeight: 600, color: "var(--text-secondary)", marginBottom: 6 }}>{f.label}</label>
                  <div style={{ position: "relative" }}>
                    <span style={{ position: "absolute", left: 12, top: "50%", transform: "translateY(-50%)", color: "var(--text-muted)" }}>{f.icon}</span>
                    <input type={f.type} value={(form as never)[f.key]} onChange={e => set(f.key as keyof typeof form, e.target.value)} placeholder={f.placeholder} className="input-field"
                      style={{ width: "100%", padding: "11px 12px 11px 36px", borderRadius: 10, fontSize: "0.9rem" }} />
                  </div>
                </div>
              ))}
              <div>
                <label style={{ display: "block", fontSize: "0.82rem", fontWeight: 600, color: "var(--text-secondary)", marginBottom: 6 }}>Password</label>
                <div style={{ position: "relative" }}>
                  <Lock size={14} style={{ position: "absolute", left: 12, top: "50%", transform: "translateY(-50%)", color: "var(--text-muted)" }} />
                  <input type={showPw ? "text" : "password"} value={form.password} onChange={e => set("password", e.target.value)} placeholder="Min 8 characters" className="input-field"
                    style={{ width: "100%", padding: "11px 36px 11px 36px", borderRadius: 10, fontSize: "0.9rem" }} />
                  <button type="button" onClick={() => setShowPw(v => !v)} style={{ position: "absolute", right: 12, top: "50%", transform: "translateY(-50%)", background: "none", border: "none", cursor: "pointer", color: "var(--text-muted)" }}>
                    {showPw ? <EyeOff size={14} /> : <Eye size={14} />}
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Step 2 */}
          {step === 2 && (
            <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
              {[
                { label: "Target Role", key: "targetRole", opts: ROLES },
                { label: "Experience Level", key: "experience", opts: EXP },
                { label: "Target Company Type", key: "companyType", opts: CO_TYPES },
              ].map(f => (
                <div key={f.key}>
                  <label style={{ display: "block", fontSize: "0.82rem", fontWeight: 600, color: "var(--text-secondary)", marginBottom: 7 }}>{f.label}</label>
                  <div style={{ display: "flex", flexWrap: "wrap", gap: 7 }}>
                    {f.opts.map(o => (
                      <button key={o} type="button" onClick={() => set(f.key as keyof typeof form, o)} style={{
                        padding: "7px 13px", borderRadius: 8, cursor: "pointer", fontSize: "0.8rem", fontWeight: 600,
                        border: `1px solid ${(form as never)[f.key] === o ? "var(--accent-blue)" : "var(--border)"}`,
                        background: (form as never)[f.key] === o ? "var(--glow-blue)" : "var(--bg-primary)",
                        color: (form as never)[f.key] === o ? "var(--accent-blue)" : "var(--text-secondary)",
                        transition: "all 0.18s",
                      }}>{o}</button>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Step 3 */}
          {step === 3 && (
            <form onSubmit={submit}>
              <div style={{ marginBottom: 16 }}>
                <div style={{ fontSize: "0.85rem", fontWeight: 700, color: "var(--text-primary)", marginBottom: 6 }}>Select your known skills</div>
                <p style={{ fontSize: "0.78rem", color: "var(--text-muted)", marginBottom: 12 }}>We'll use these to personalise your interview questions and skill gap report.</p>
                <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
                  {SKILLS.map(s => (
                    <button key={s} type="button" onClick={() => toggleSkill(s)} style={{
                      padding: "6px 13px", borderRadius: 100, cursor: "pointer", fontSize: "0.78rem", fontWeight: 600,
                      border: `1px solid ${form.skills.includes(s) ? "var(--accent-green)" : "var(--border)"}`,
                      background: form.skills.includes(s) ? "rgba(0,229,160,0.1)" : "var(--bg-primary)",
                      color: form.skills.includes(s) ? "var(--accent-green)" : "var(--text-secondary)",
                      transition: "all 0.18s",
                    }}>{form.skills.includes(s) ? "✓ " : ""}{s}</button>
                  ))}
                </div>
                <div style={{ marginTop: 8, fontSize: "0.72rem", color: "var(--text-muted)" }}>{form.skills.length} selected (you can update anytime in Profile)</div>
              </div>
            </form>
          )}

          {error && <div style={{ padding: "10px 14px", borderRadius: 9, background: "rgba(239,68,68,0.08)", border: "1px solid rgba(239,68,68,0.2)", fontSize: "0.82rem", color: "#ef4444", marginTop: 12 }}>{error}</div>}

          <div style={{ display: "flex", gap: 10, marginTop: 20 }}>
            {step > 1 && (
              <button type="button" onClick={() => setStep(s => (s - 1) as Step)} className="btn-ghost" style={{ padding: "11px 18px", borderRadius: 10, fontSize: "0.875rem" }}>Back</button>
            )}
            {step < 3 ? (
              <button type="button" onClick={next} className="btn-primary" style={{ flex: 1, padding: "11px", borderRadius: 10, fontSize: "0.9rem" }}>
                <span style={{ position: "relative", zIndex: 1, display: "flex", alignItems: "center", justifyContent: "center", gap: 8 }}>Continue <ArrowRight size={15} /></span>
              </button>
            ) : (
              <button type="button" onClick={submit} disabled={loading} className="btn-primary" style={{ flex: 1, padding: "11px", borderRadius: 10, fontSize: "0.9rem" }}>
                <span style={{ position: "relative", zIndex: 1 }}>{loading ? "Creating account…" : "Create Account 🚀"}</span>
              </button>
            )}
          </div>

          <p style={{ textAlign: "center", marginTop: 18, fontSize: "0.875rem", color: "var(--text-muted)" }}>
            Already have an account?{" "}
            <Link to="/login" style={{ color: "var(--accent-blue)", fontWeight: 600, textDecoration: "none" }}>Sign in</Link>
          </p>
        </div>
      </div>
    </div>
  );
}
