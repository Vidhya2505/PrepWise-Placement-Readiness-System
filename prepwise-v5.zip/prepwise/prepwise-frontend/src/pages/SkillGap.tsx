import { useState, useEffect } from "react";
import { Target, ChevronRight, BookOpen, Zap, TrendingUp, AlertTriangle, CheckCircle, Mic, RefreshCw, Brain } from "lucide-react";
import { Link } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

interface RoundStat { round: string; count: number; avgScore: number; }
interface SkillEntry { name: string; category: string; score: number; depth: "Strong"|"Moderate"|"Shallow"|"Missing"; description: string; topics: string[]; }

const depthColor = { Strong:"var(--accent-green)", Moderate:"var(--accent-blue)", Shallow:"#f59e0b", Missing:"#ef4444" };
const depthBg    = { Strong:"rgba(0,229,160,0.1)", Moderate:"var(--glow-blue)", Shallow:"rgba(245,158,11,0.1)", Missing:"rgba(239,68,68,0.08)" };

function getDepth(score: number): "Strong"|"Moderate"|"Shallow"|"Missing" {
  if (score >= 75) return "Strong"; if (score >= 55) return "Moderate"; if (score >= 30) return "Shallow"; return "Missing";
}

function buildSkillsFromStats(roundStats: RoundStat[], experienceLevel: string): SkillEntry[] {
  const base: SkillEntry[] = [
    { name:"Data Structures & Algorithms", category:"Core CS",  score:50, depth:"Moderate", description:"Covers arrays, linked lists, trees. Check graphs and DP.", topics:["Arrays / Strings","Linked Lists","Trees / BST","Graphs","Dynamic Programming","Heaps"] },
    { name:"Operating Systems",            category:"Core CS",  score:35, depth:"Shallow",  description:"Basic process/thread concepts. Scheduling and memory management need work.", topics:["Processes & Threads","Scheduling Algorithms","Memory Management","Deadlocks","Virtual Memory"] },
    { name:"Database Management (DBMS)",   category:"Core CS",  score:60, depth:"Moderate", description:"Good SQL and indexing. Transactions and normalisation need attention.", topics:["SQL Queries","Joins & Aggregates","Indexes","Transactions/ACID","Normalisation"] },
    { name:"Computer Networks",            category:"Core CS",  score:32, depth:"Shallow",  description:"Very basic understanding. OSI model and TCP/IP need attention.", topics:["OSI / TCP Model","HTTP / HTTPS","DNS & Routing","Sockets","REST APIs"] },
    { name:"System Design",                category:"Advanced", score:15, depth:"Missing",  description:"No system design exposure. High priority for product company interviews.", topics:["Scalability","Load Balancing","Caching","DB Sharding","Microservices"] },
    { name:"Communication Skills",         category:"Soft Skills", score:65, depth:"Moderate", description:"Decent structure but answers go off-topic under pressure.", topics:["Answer Structure","Clarity","Confidence","Staying Concise"] },
  ];

  // Update scores based on actual interview history
  roundStats.forEach(rs => {
    const s = rs.avgScore;
    if (rs.round === "DSA"        ) { base[0].score = Math.max(base[0].score, Math.round(s * 0.9)); }
    if (rs.round === "Technical"  ) { base[1].score = Math.max(base[1].score, Math.round(s * 0.7)); base[2].score = Math.max(base[2].score, Math.round(s * 0.75)); base[3].score = Math.max(base[3].score, Math.round(s * 0.65)); }
    if (rs.round === "Project"    ) { base[4].score = Math.max(base[4].score, Math.round(s * 0.8)); }
    if (rs.round === "HR" || rs.round === "Behavioural") { base[5].score = Math.max(base[5].score, Math.round(s * 0.85)); }
  });

  // Add language/framework skills from profile level
  const langScore = experienceLevel === "senior" ? 85 : experienceLevel === "mid" ? 72 : experienceLevel === "junior" ? 60 : 55;
  base.push({ name:"React / Frontend",   category:"Languages & Frameworks", score:langScore + 5, depth:getDepth(langScore + 5), description:`Frontend skills based on your experience level (${experienceLevel}).`, topics:["Hooks & State","Component Lifecycle","React Router","Performance Opt.","Testing"] });
  base.push({ name:"Backend / Node.js",  category:"Languages & Frameworks", score:langScore,     depth:getDepth(langScore),     description:"Backend development skills.", topics:["REST APIs","Middleware","Authentication","Database Integration","Error Handling"] });

  return base.map(s => ({ ...s, depth: getDepth(s.score) }));
}

const Skel = ({ h = 16, r = 5 }: { h?: number; r?: number }) => <div className="skeleton" style={{ width:"100%", height:h, borderRadius:r }} />;

export default function SkillGap() {
  const { user } = useAuth();
  const [roundStats, setRoundStats] = useState<RoundStat[]>([]);
  const [loading, setLoading]       = useState(true);
  const [activeCategory, setActiveCategory] = useState("All");
  const [expanded, setExpanded]     = useState<string | null>(null);

  useEffect(() => {
    const load = async () => {
      setLoading(true);
      try {
        const token = localStorage.getItem("token");
        const res = await fetch("/interview/stats", { headers: { Authorization: `Bearer ${token}` } });
        if (res.ok) { const data = await res.json(); setRoundStats(data.roundStats || []); }
      } catch { /* use defaults */ }
      finally { setLoading(false); }
    };
    load();
  }, []);

  const expLevel = user?.resumeData?.experienceLevel || "fresher";
  const skills   = buildSkillsFromStats(roundStats, expLevel);
  const categories = ["All", ...Array.from(new Set(skills.map(s => s.category)))];
  const filtered   = activeCategory === "All" ? skills : skills.filter(s => s.category === activeCategory);
  const sorted     = [...filtered].sort((a, b) => a.score - b.score);

  const avgScore     = Math.round(skills.reduce((a, b) => a + b.score, 0) / skills.length);
  const strongCount  = skills.filter(s => s.depth === "Strong").length;
  const weakCount    = skills.filter(s => s.depth === "Shallow" || s.depth === "Missing").length;
  const top3Weak     = [...skills].sort((a,b) => a.score - b.score).slice(0, 3);

  return (
    <div style={{ maxWidth: 1080, margin: "0 auto" }}>
      <div style={{ marginBottom: 22 }}>
        <div className="tag" style={{ display:"inline-flex",alignItems:"center",gap:6,borderRadius:100,padding:"5px 14px",marginBottom:10,fontSize:"0.75rem" }}><Target size={11}/> Skill Gap Analysis</div>
        <h1 style={{ fontFamily:"Syne,sans-serif",fontWeight:800,fontSize:"clamp(1.7rem,3vw,2.1rem)",letterSpacing:"-0.03em",color:"var(--text-primary)",marginBottom:7 }}>Your Skill <span className="gradient-text">Gap Report</span></h1>
        <p style={{ color:"var(--text-secondary)",fontSize:"0.9rem" }}>
          {roundStats.length > 0
          ? `Based on your ${roundStats.reduce((a,r)=>a+r.count,0)} interview session${roundStats.reduce((a,r)=>a+r.count,0)!==1?"s":""} — scores are computed from your actual performance and update after each session.`
          : "Scores below are starting estimates. Complete mock interviews to get a personalised report based on your actual performance."}
        </p>
      </div>

      {loading ? (
        <div style={{ display:"grid",gridTemplateColumns:"1fr 1fr 1fr 1fr",gap:12,marginBottom:22 }}>{[1,2,3,4].map(i=><div key={i} className="card" style={{borderRadius:13,padding:"18px"}}><Skel h={36} r={9}/><div style={{marginTop:10}}><Skel h={28} r={4}/></div><div style={{marginTop:6}}><Skel h={14} r={4}/></div></div>)}</div>
      ) : (
        <>
          {/* Summary */}
          <div style={{ display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(190px,1fr))",gap:12,marginBottom:20 }}>
            {[
              { label:"Overall Score", value:`${avgScore}%`, icon:TrendingUp, color:"var(--accent-blue)", sub:"Across all domains" },
              { label:"Strong Skills",  value:String(strongCount), icon:CheckCircle, color:"var(--accent-green)", sub:"Performing well" },
              { label:"Need Attention", value:String(weakCount),   icon:AlertTriangle, color:"#f59e0b", sub:"Shallow or missing" },
              { label:"High Priority",  value:String(Math.min(3, weakCount)), icon:Zap, color:"#ef4444", sub:"Fix these first" },
            ].map(c => (
              <div key={c.label} className="card" style={{ borderRadius:13,padding:"18px" }}>
                <div style={{ width:36,height:36,borderRadius:8,background:`${c.color}18`,border:`1px solid ${c.color}30`,display:"flex",alignItems:"center",justifyContent:"center",marginBottom:10 }}><c.icon size={16} color={c.color}/></div>
                <div style={{ fontFamily:"Syne,sans-serif",fontWeight:800,fontSize:"1.7rem",color:"var(--text-primary)",lineHeight:1,marginBottom:3 }}>{c.value}</div>
                <div style={{ fontWeight:600,fontSize:"0.8rem",color:"var(--text-secondary)",marginBottom:1 }}>{c.label}</div>
                <div style={{ fontSize:"0.72rem",color:"var(--text-muted)" }}>{c.sub}</div>
              </div>
            ))}
          </div>

          {/* Priority alert */}
          {weakCount > 0 && (
            <div style={{ marginBottom:20,padding:"14px 18px",borderRadius:11,background:"rgba(239,68,68,0.07)",border:"1px solid rgba(239,68,68,0.18)",display:"flex",gap:11,alignItems:"flex-start" }}>
              <AlertTriangle size={16} color="#ef4444" style={{flexShrink:0,marginTop:2}}/>
              <div>
                <div style={{ fontWeight:700,fontSize:"0.88rem",color:"#ef4444",marginBottom:4 }}>⚡ Top Priority Gaps</div>
                <div style={{ fontSize:"0.82rem",color:"var(--text-secondary)",lineHeight:1.65 }}>
                  {top3Weak.map((s,i) => <span key={s.name}><strong>{i+1}. {s.name}</strong> — Score: {s.score}/100 · {s.depth}{i < top3Weak.length-1 ? "  |  " : ""}</span>)}
                </div>
              </div>
            </div>
          )}

          {/* Round performance (real data) */}
          {roundStats.length > 0 && (
            <div className="card" style={{ borderRadius:13,padding:"16px 18px",marginBottom:20 }}>
              <div style={{ fontFamily:"Syne,sans-serif",fontWeight:700,fontSize:"0.85rem",color:"var(--text-primary)",marginBottom:12,display:"flex",alignItems:"center",gap:6 }}><Brain size={13} color="var(--accent-blue)"/> Your Round Performance</div>
              <div style={{ display:"flex",flexDirection:"column",gap:8 }}>
                {roundStats.map(rs => (
                  <div key={rs.round} style={{ display:"flex",alignItems:"center",gap:11 }}>
                    <span style={{ fontSize:"0.8rem",color:"var(--text-secondary)",fontWeight:600,width:140,flexShrink:0 }}>{rs.round}</span>
                    <div style={{ flex:1,height:6,borderRadius:3,background:"var(--border)",overflow:"hidden" }}><div style={{width:`${rs.avgScore}%`,height:"100%",background:rs.avgScore>=75?"var(--accent-green)":rs.avgScore>=55?"var(--accent-blue)":"#f59e0b",borderRadius:3,transition:"width 0.8s"}}/></div>
                    <span style={{ fontSize:"0.78rem",fontWeight:700,color:rs.avgScore>=75?"var(--accent-green)":rs.avgScore>=55?"var(--accent-blue)":"#f59e0b",width:40,textAlign:"right" }}>{rs.avgScore}</span>
                    <span style={{ fontSize:"0.68rem",color:"var(--text-muted)",width:60 }}>{rs.count} session{rs.count!==1?"s":""}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Category filter */}
          <div style={{ display:"flex",gap:7,flexWrap:"wrap",marginBottom:18 }}>
            {categories.map(cat => (
              <button key={cat} onClick={()=>setActiveCategory(cat)} style={{ padding:"6px 14px",borderRadius:100,cursor:"pointer",fontWeight:600,fontSize:"0.8rem",border:`1px solid ${activeCategory===cat?"var(--accent-blue)":"var(--border)"}`,background:activeCategory===cat?"var(--glow-blue)":"var(--bg-card)",color:activeCategory===cat?"var(--accent-blue)":"var(--text-secondary)",transition:"all 0.2s" }}>{cat}</button>
            ))}
          </div>

          {/* Skill cards */}
          <div style={{ display:"flex",flexDirection:"column",gap:10 }}>
            {sorted.map(skill => (
              <div key={skill.name} className="card" style={{ borderRadius:13,overflow:"hidden",cursor:"pointer" }} onClick={()=>setExpanded(expanded===skill.name?null:skill.name)}>
                <div style={{ padding:"16px 18px",display:"flex",alignItems:"center",gap:12 }}>
                  <div style={{ width:50,height:50,borderRadius:11,flexShrink:0,background:depthBg[skill.depth],border:`1px solid ${depthColor[skill.depth]}30`,display:"flex",alignItems:"center",justifyContent:"center",fontFamily:"Syne,sans-serif",fontWeight:800,fontSize:"0.95rem",color:depthColor[skill.depth] }}>{skill.score}</div>
                  <div style={{ flex:1,minWidth:0 }}>
                    <div style={{ display:"flex",alignItems:"center",gap:7,marginBottom:5,flexWrap:"wrap" }}>
                      <span style={{ fontFamily:"Syne,sans-serif",fontWeight:700,fontSize:"0.9rem",color:"var(--text-primary)" }}>{skill.name}</span>
                      <span style={{ padding:"2px 8px",borderRadius:100,fontSize:"0.7rem",fontWeight:700,background:depthBg[skill.depth],border:`1px solid ${depthColor[skill.depth]}30`,color:depthColor[skill.depth] }}>{skill.depth}</span>
                    </div>
                    <div style={{ height:4,borderRadius:2,background:"var(--border)",overflow:"hidden",marginBottom:5 }}><div style={{width:`${skill.score}%`,height:"100%",background:depthColor[skill.depth],borderRadius:2,transition:"width 0.8s"}}/></div>
                    <div style={{ fontSize:"0.75rem",color:"var(--text-muted)" }}>{skill.category}</div>
                  </div>
                  <ChevronRight size={15} color="var(--text-muted)" style={{transform:expanded===skill.name?"rotate(90deg)":"none",transition:"transform 0.2s",flexShrink:0}}/>
                </div>
                {expanded === skill.name && (
                  <div style={{ padding:"0 18px 18px",borderTop:"1px solid var(--border)" }}>
                    <p style={{ fontSize:"0.85rem",color:"var(--text-secondary)",lineHeight:1.7,marginBottom:14,paddingTop:14 }}>{skill.description}</p>
                    <div style={{ display:"grid",gridTemplateColumns:"1fr 1fr",gap:7,marginBottom:14 }}>
                      {skill.topics.map((t,i) => (
                        <div key={t} style={{ display:"flex",alignItems:"center",gap:7,fontSize:"0.8rem",color:i%2===0&&i<Math.ceil(skill.topics.length/2)*2-2?"var(--text-secondary)":"var(--text-secondary)" }}>
                          <span style={{ fontSize:"0.85rem" }}>{skill.score >= 75 || i < 2 ? "✅" : "❌"}</span>{t}
                        </div>
                      ))}
                    </div>
                    <div style={{ display:"flex",gap:9,flexWrap:"wrap" }}>
                      <Link to="/mock" style={{ padding:"7px 16px",borderRadius:7,textDecoration:"none",background:"linear-gradient(135deg,var(--accent-blue),var(--accent-cyan))",color:"white",fontSize:"0.8rem",fontWeight:700,display:"flex",alignItems:"center",gap:5 }}><Mic size={11}/> Practice in Interview</Link>
                      <a href={`https://www.google.com/search?q=${encodeURIComponent(skill.name + " interview questions and concepts")}`} target="_blank" rel="noopener" style={{ padding:"7px 16px",borderRadius:7,textDecoration:"none",background:"var(--bg-primary)",border:"1px solid var(--border-strong)",color:"var(--text-secondary)",fontSize:"0.8rem",fontWeight:600,display:"flex",alignItems:"center",gap:5 }}><BookOpen size={11}/> Study Resources</a>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>

          {roundStats.length === 0 && (
            <div style={{ marginTop:18,padding:"20px 24px",borderRadius:13,background:"linear-gradient(135deg,rgba(59,142,255,0.07),rgba(0,229,160,0.05))",border:"1px solid rgba(59,142,255,0.2)",display:"flex",alignItems:"center",gap:16,flexWrap:"wrap" }}>
              <div style={{ width:44,height:44,borderRadius:11,background:"var(--glow-blue)",border:"1px solid var(--border-strong)",display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0 }}><Brain size={20} color="var(--accent-blue)"/></div>
              <div style={{ flex:1 }}><div style={{ fontFamily:"Syne,sans-serif",fontWeight:700,fontSize:"0.9rem",color:"var(--text-primary)",marginBottom:3 }}>Scores update after each interview</div><div style={{ fontSize:"0.78rem",color:"var(--text-secondary)",lineHeight:1.6 }}>Currently showing default skill estimates. Complete mock interviews to see your actual performance per skill area.</div></div>
              <Link to="/mock" className="btn-primary" style={{ padding:"9px 18px",borderRadius:9,fontWeight:700,fontSize:"0.85rem",textDecoration:"none",flexShrink:0 }}><span style={{position:"relative",zIndex:1}}>Start Interview →</span></Link>
            </div>
          )}
        </>
      )}
    </div>
  );
}
