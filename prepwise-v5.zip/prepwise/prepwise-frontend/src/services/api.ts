// Centralized API client — all fetch calls go through here.
// Handles auth header injection and 401 token-expiry redirect.

const BASE = "";  // Vite proxy forwards to http://localhost:5000

function getToken(): string {
  return localStorage.getItem("token") || "";
}

function authHeaders(): Record<string, string> {
  return {
    "Content-Type": "application/json",
    Authorization: `Bearer ${getToken()}`,
  };
}

async function request<T>(
  path: string,
  options: RequestInit = {},
  authenticated = true
): Promise<T> {
  const headers = authenticated
    ? { ...authHeaders(), ...(options.headers as Record<string, string> || {}) }
    : { "Content-Type": "application/json", ...(options.headers as Record<string, string> || {}) };

  const res = await fetch(`${BASE}${path}`, { ...options, headers });

  if (res.status === 401) {
    // Token expired — clear storage and redirect to login
    localStorage.removeItem("token");
    localStorage.removeItem("user");
    window.location.href = "/login";
    throw new Error("Session expired. Please log in again.");
  }

  if (!res.ok) {
    let errMsg = `Server error ${res.status}`;
    try {
      const body = await res.json();
      errMsg = body.error || errMsg;
    } catch { /* ignore parse errors */ }
    throw new Error(errMsg);
  }

  return res.json() as Promise<T>;
}

// ── Auth ──────────────────────────────────────────────────────────────────────

export const authApi = {
  login:    (email: string, password: string) =>
    request("/auth/login",  { method: "POST", body: JSON.stringify({ email, password }) }, false),

  register: (data: Record<string, unknown>) =>
    request("/auth/register", { method: "POST", body: JSON.stringify(data) }, false),

  getMe:    () => request("/auth/me"),

  updateProfile: (data: Record<string, unknown>) =>
    request("/auth/update", { method: "PUT", body: JSON.stringify(data) }),
};

// ── AI ────────────────────────────────────────────────────────────────────────

export const aiApi = {
  analyze: (resumeText: string, jobDescription: string) =>
    request("/ai/analyze", {
      method: "POST",
      body: JSON.stringify({ resumeText, jobDescription }),
    }),

  generateQuestions: (interviewType: string, resumeData?: unknown) =>
    request("/ai/generate-questions", {
      method: "POST",
      body: JSON.stringify({ interviewType, resumeData }),
    }),

  feedbackAnswer: (question: string, answer: string, round: string, resumeData?: unknown) =>
    request("/ai/feedback-answer", {
      method: "POST",
      body: JSON.stringify({ question, answer, round, resumeData }),
    }),

  analyzeInterview: (answers: { question: string; answer: string }[], resumeData?: unknown) =>
    request("/ai/analyze-interview", {
      method: "POST",
      body: JSON.stringify({ answers, resumeData }),
    }),
};

// ── Interview ─────────────────────────────────────────────────────────────────

export const interviewApi = {
  save: (data: Record<string, unknown>) =>
    request("/interview/save", { method: "POST", body: JSON.stringify(data) }),

  getStats: () => request("/interview/stats"),

  getHistory: () => request("/interview/history"),
};


// ── Portfolio ─────────────────────────────────────────────────────────────────

export const portfolioApi = {
  generate: (resumeText: string, jobDescription?: string, style?: string) =>
    request("/portfolio/generate", {
      method: "POST",
      body: JSON.stringify({ resumeText, jobDescription, style }),
    }),

  exportHtml: (portfolio: unknown) =>
    request("/portfolio/export-html", {
      method: "POST",
      body: JSON.stringify({ portfolio }),
    }),
};

export default { authApi, aiApi, interviewApi, portfolioApi };

// ── Portfolio ─────────────────────────────────────────────────────────────────

export const portfolioApi = {
  generate: (resumeText: string, jobDescription?: string, userProfile?: Record<string, unknown>) =>
    request("/portfolio/generate", {
      method: "POST",
      body: JSON.stringify({ resumeText, jobDescription, userProfile }),
    }),

  exportHtml: (portfolioData: unknown, theme: "dark" | "light" = "dark") =>
    request("/portfolio/export-html", {
      method: "POST",
      body: JSON.stringify({ portfolioData, theme }),
    }),
};

// ── Chat ──────────────────────────────────────────────────────────────────────

export const chatApi = {
  message: (message: string, history: { role: "user" | "assistant"; content: string }[]) =>
    request("/chat/message", {
      method: "POST",
      body: JSON.stringify({ message, history }),
    }),

  suggestions: () => request<{ suggestions: string[] }>("/chat/suggestions", {}, true),
};
