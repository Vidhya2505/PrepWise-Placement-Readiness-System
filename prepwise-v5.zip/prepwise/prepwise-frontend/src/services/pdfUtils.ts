// Shared PDF generation utility — used by MockInterview, ResumeAnalyzer, CareerReport
// Dynamically loads jsPDF from CDN so it's not in the bundle

type jsPDFInstance = {
  internal: { pageSize: { getWidth(): number; getHeight(): number }; getNumberOfPages(): number };
  addPage(): void;
  setPage(n: number): void;
  setFillColor(r: number, g: number, b: number): void;
  setTextColor(r: number, g: number, b: number): void;
  setFont(family: string, style: string): void;
  setFontSize(size: number): void;
  setDrawColor(r: number, g: number, b: number): void;
  setLineWidth(w: number): void;
  rect(x: number, y: number, w: number, h: number, style?: string): void;
  roundedRect(x: number, y: number, w: number, h: number, rx: number, ry: number, style?: string): void;
  circle(x: number, y: number, r: number, style?: string): void;
  line(x1: number, y1: number, x2: number, y2: number): void;
  text(text: string | string[], x: number, y: number, options?: { align?: string }): void;
  splitTextToSize(text: string, maxWidth: number): string[];
  save(filename: string): void;
  getNumberOfPages(): number;
};

function loadJsPDF(): Promise<{ jsPDF: new (opts: object) => jsPDFInstance }> {
  return new Promise((resolve, reject) => {
    if ((window as unknown as Record<string, unknown>).jspdf) {
      resolve((window as unknown as Record<string, unknown>).jspdf as { jsPDF: new (opts: object) => jsPDFInstance });
      return;
    }
    const script = document.createElement("script");
    script.src = "https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js";
    script.onload = () => resolve((window as unknown as Record<string, unknown>).jspdf as { jsPDF: new (opts: object) => jsPDFInstance });
    script.onerror = () => reject(new Error("Failed to load jsPDF"));
    document.head.appendChild(script);
  });
}

function scoreColor(s: number): [number, number, number] {
  return s >= 75 ? [0, 200, 140] : s >= 50 ? [245, 158, 11] : [239, 68, 68];
}

function drawPageHeader(doc: jsPDFInstance, W: number, title: string, subtitle: string, date: string) {
  doc.setFillColor(15, 23, 42);
  doc.rect(0, 0, W, 38, "F");
  doc.setTextColor(255, 255, 255);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(18);
  doc.text("PrepWise", 18, 15);
  doc.setFontSize(10);
  doc.setTextColor(140, 190, 255);
  doc.text(title, 18, 24);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(7.5);
  doc.setTextColor(110, 135, 175);
  doc.text(subtitle + "  ·  " + date, 18, 32);
}

function drawPageFooter(doc: jsPDFInstance, W: number, H: number, pg: number, total: number) {
  doc.setFillColor(15, 23, 42);
  doc.rect(0, H - 9, W, 9, "F");
  doc.setTextColor(75, 100, 140);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(6.5);
  doc.text("PrepWise  ·  " + new Date().toLocaleString("en-IN"), 18, H - 3);
  doc.text("Page " + pg + " / " + total, W - 18, H - 3, { align: "right" });
}

function sectionHeader(doc: jsPDFInstance, margin: number, W: number, y: number, title: string): number {
  doc.setTextColor(190, 210, 240);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(9.5);
  doc.text(title, margin, y);
  doc.setDrawColor(50, 70, 110);
  doc.setLineWidth(0.3);
  doc.line(margin, y + 2, W - margin, y + 2);
  return y + 9;
}

// ─── MOCK INTERVIEW REPORT ──────────────────────────────────────────────────

export async function downloadMockInterviewPDF(opts: {
  round: string;
  avgScore: number;
  interpretation: string;
  strengths: string[];
  improvements: string[];
  feedbacks: {
    question: string;
    answer: string;
    feedback: {
      score: number;
      label: string;
      wordCount: number;
      improvedAnswer: string;
      realInterviewRisk: { verdict: string };
      recruiterView: { hireDecision: string };
      totalFillerOccurrences: number;
      scoreBreakdown: { content: number; clarity: number; structure: number; confidence: number };
    };
  }[];
}) {
  const { jsPDF } = await loadJsPDF();
  const doc = new jsPDF({ orientation: "portrait", unit: "mm", format: "a4" });
  const W = doc.internal.pageSize.getWidth();
  const H = doc.internal.pageSize.getHeight();
  const margin = 18;
  const colW = W - margin * 2;
  let y = 0;

  const newPage = () => { doc.addPage(); y = 46; };
  const checkY = (n = 10) => { if (y + n > H - 14) newPage(); };
  const dateStr = new Date().toLocaleDateString("en-IN", { day: "2-digit", month: "long", year: "numeric" });

  drawPageHeader(doc, W, "Mock Interview Report", `${opts.round} Round  ·  Score: ${opts.avgScore}/100`, dateStr);
  y = 46;

  // Score hero
  const [sr, sg, sb] = scoreColor(opts.avgScore);
  doc.setFillColor(22, 32, 52);
  doc.roundedRect(margin, y, colW, 22, 3, 3, "F");
  doc.setTextColor(sr, sg, sb);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(22);
  doc.text(`${opts.avgScore}`, margin + 16, y + 13, { align: "center" });
  doc.setFontSize(7);
  doc.setTextColor(110, 135, 175);
  doc.text("/100", margin + 24, y + 13);
  doc.setTextColor(sr, sg, sb);
  doc.setFontSize(11);
  doc.text(opts.interpretation, margin + 36, y + 9);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(7.5);
  doc.setTextColor(110, 135, 175);
  doc.text(`${opts.feedbacks.length} questions  ·  ${opts.round} Round`, margin + 36, y + 17);
  y += 28;

  // Strengths & Improvements
  const halfW = (colW - 5) / 2;
  const strH = 8 + Math.min(opts.strengths.length, 5) * 7 + 4;
  const impH = 8 + Math.min(opts.improvements.length, 5) * 7 + 4;
  const boxH = Math.max(strH, impH);

  doc.setFillColor(0, 30, 22);
  doc.roundedRect(margin, y, halfW, boxH, 3, 3, "F");
  doc.setTextColor(0, 200, 140);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(8);
  doc.text("✓  STRENGTHS", margin + 4, y + 6);
  doc.setTextColor(140, 210, 185);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(7.5);
  opts.strengths.slice(0, 5).forEach((s, i) => {
    const lines = doc.splitTextToSize("• " + s, halfW - 8);
    doc.text(lines, margin + 4, y + 13 + i * 7);
  });

  doc.setFillColor(28, 22, 0);
  doc.roundedRect(margin + halfW + 5, y, halfW, boxH, 3, 3, "F");
  doc.setTextColor(245, 158, 11);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(8);
  doc.text("△  TO IMPROVE", margin + halfW + 9, y + 6);
  doc.setTextColor(210, 185, 120);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(7.5);
  opts.improvements.slice(0, 5).forEach((s, i) => {
    const lines = doc.splitTextToSize("• " + s, halfW - 8);
    doc.text(lines, margin + halfW + 9, y + 13 + i * 7);
  });
  y += boxH + 10;

  // Question breakdown
  y = sectionHeader(doc, margin, W, y, "QUESTION-BY-QUESTION BREAKDOWN");
  opts.feedbacks.forEach((f, i) => {
    const fb = f.feedback;
    const [qr, qg, qb] = scoreColor(fb.score);
    const qLines = doc.splitTextToSize(`Q${i + 1}: ${f.question}`, colW - 30);
    const aLines = doc.splitTextToSize(f.answer.slice(0, 300) + (f.answer.length > 300 ? "…" : ""), colW - 8);
    const iaLines = fb.improvedAnswer ? doc.splitTextToSize(fb.improvedAnswer.slice(0, 300) + (fb.improvedAnswer.length > 300 ? "…" : ""), colW - 8) : [];
    const cardH = qLines.length * 5 + aLines.length * 4 + (iaLines.length ? iaLines.length * 4 + 10 : 0) + 32;
    checkY(cardH + 4);

    doc.setFillColor(22, 32, 52);
    doc.roundedRect(margin, y, colW, cardH, 3, 3, "F");

    // Q header
    doc.setTextColor(qr, qg, qb);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(11);
    doc.text(`${fb.score}`, W - margin - 4, y + 8, { align: "right" });
    doc.setFontSize(7);
    doc.setTextColor(110, 135, 175);
    doc.text("/100", W - margin - 4, y + 14, { align: "right" });

    doc.setTextColor(200, 215, 240);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(7.5);
    doc.text(qLines, margin + 4, y + 7);

    // Score bar
    const barY = y + qLines.length * 5 + 6;
    doc.setFillColor(40, 52, 75);
    doc.roundedRect(margin + 4, barY, colW - 8, 2.5, 1, 1, "F");
    doc.setFillColor(qr, qg, qb);
    doc.roundedRect(margin + 4, barY, (colW - 8) * fb.score / 100, 2.5, 1, 1, "F");

    // Breakdown row
    const bdY = barY + 7;
    const labels = [
      { l: "Content", v: fb.scoreBreakdown.content, max: 40 },
      { l: "Clarity",  v: fb.scoreBreakdown.clarity,  max: 20 },
      { l: "Structure",v: fb.scoreBreakdown.structure, max: 20 },
      { l: "Confidence",v:fb.scoreBreakdown.confidence,max: 20 },
    ];
    labels.forEach((bd, bi) => {
      const bx = margin + 4 + bi * ((colW - 8) / 4);
      const [br, bg, bb] = scoreColor((bd.v / bd.max) * 100);
      doc.setTextColor(br, bg, bb);
      doc.setFont("helvetica", "bold");
      doc.setFontSize(6.5);
      doc.text(`${bd.v}/${bd.max}`, bx, bdY);
      doc.setTextColor(90, 115, 155);
      doc.setFont("helvetica", "normal");
      doc.setFontSize(5.5);
      doc.text(bd.l, bx, bdY + 4);
    });

    // Tags
    const tagY = bdY + 10;
    const [rr, rg, rb] = scoreColor(fb.realInterviewRisk.verdict === "Good chance" ? 80 : fb.realInterviewRisk.verdict === "Borderline" ? 55 : 30);
    doc.setTextColor(rr, rg, rb);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(6.5);
    doc.text(`Risk: ${fb.realInterviewRisk.verdict}`, margin + 4, tagY);
    const [hr, hg, hb] = scoreColor(fb.recruiterView.hireDecision === "Strong Yes" ? 95 : fb.recruiterView.hireDecision === "Yes" ? 80 : fb.recruiterView.hireDecision === "Maybe" ? 55 : 20);
    doc.setTextColor(hr, hg, hb);
    doc.text(`Hire: ${fb.recruiterView.hireDecision}`, margin + 50, tagY);
    doc.setTextColor(fb.totalFillerOccurrences === 0 ? 0 : 245, fb.totalFillerOccurrences === 0 ? 200 : 158, fb.totalFillerOccurrences === 0 ? 140 : 11);
    doc.text(`Fillers: ${fb.totalFillerOccurrences}`, margin + 100, tagY);
    doc.text(`${fb.wordCount} words`, margin + 135, tagY);

    // Answer
    const ansY = tagY + 7;
    doc.setTextColor(80, 100, 140);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(6);
    doc.text("YOUR ANSWER:", margin + 4, ansY);
    doc.setTextColor(160, 180, 215);
    doc.setFont("helvetica", "normal");
    doc.setFontSize(7);
    doc.text(aLines, margin + 4, ansY + 5);

    // Model answer
    if (iaLines.length > 0) {
      const iaY = ansY + aLines.length * 4 + 8;
      doc.setTextColor(0, 200, 140);
      doc.setFont("helvetica", "bold");
      doc.setFontSize(6);
      doc.text("MODEL ANSWER:", margin + 4, iaY);
      doc.setTextColor(120, 200, 170);
      doc.setFont("helvetica", "normal");
      doc.setFontSize(7);
      doc.text(iaLines, margin + 4, iaY + 5);
    }

    y += cardH + 4;
  });

  // Footer on all pages
  const total = doc.internal.getNumberOfPages();
  for (let pg = 1; pg <= total; pg++) {
    doc.setPage(pg);
    drawPageFooter(doc, W, H, pg, total);
  }

  doc.save(`PrepWise-${opts.round}-${new Date().toLocaleDateString("en-IN").replace(/\//g, "-")}.pdf`);
}

// ─── RESUME ANALYSIS REPORT ─────────────────────────────────────────────────

export async function downloadResumePDF(opts: {
  matchScore: number;
  alignmentScore: number;
  summary: string;
  matchedSkills: string[];
  missingSkills: string[];
  priorityActionPlan: { priority: string; action: string }[];
  riskAnalysis: { level: string; risk: string }[];
  keywordOptimization: { skill: string; placement: string; howToWrite: string }[];
  scoreBreakdown: { skillsMatch?: { score: number; reason: string }; experienceStrength?: { score: number; reason: string }; keywordCoverage?: { score: number; reason: string } };
  sections: { skills?: { score: number; status: string; feedback: string }; projects?: { score: number; status: string; feedback: string }; experience?: { score: number; status: string; feedback: string }; education?: { score: number; status: string; feedback: string } };
}) {
  const { jsPDF } = await loadJsPDF();
  const doc = new jsPDF({ orientation: "portrait", unit: "mm", format: "a4" });
  const W = doc.internal.pageSize.getWidth();
  const H = doc.internal.pageSize.getHeight();
  const margin = 18;
  const colW = W - margin * 2;
  let y = 0;

  const newPage = () => { doc.addPage(); y = 46; };
  const checkY = (n = 10) => { if (y + n > H - 14) newPage(); };
  const dateStr = new Date().toLocaleDateString("en-IN", { day: "2-digit", month: "long", year: "numeric" });

  drawPageHeader(doc, W, "Resume ATS Analysis Report", `ATS Match: ${opts.matchScore}/100  ·  Alignment: ${opts.alignmentScore}%`, dateStr);
  y = 46;

  // Scores row
  const scoreBoxes = [
    { label: "ATS Match",     val: opts.matchScore },
    { label: "Alignment",     val: opts.alignmentScore },
    { label: "Skills Match",  val: opts.scoreBreakdown.skillsMatch?.score || 0 },
    { label: "Keywords",      val: opts.scoreBreakdown.keywordCoverage?.score || 0 },
  ];
  const sbW = (colW - 9) / 4;
  scoreBoxes.forEach((sb, i) => {
    const sx = margin + i * (sbW + 3);
    doc.setFillColor(25, 35, 55);
    doc.roundedRect(sx, y, sbW, 22, 3, 3, "F");
    const [r, g, b] = scoreColor(sb.val);
    doc.setTextColor(r, g, b);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(15);
    doc.text(`${sb.val}`, sx + sbW / 2, y + 12, { align: "center" });
    doc.setTextColor(100, 130, 165);
    doc.setFont("helvetica", "normal");
    doc.setFontSize(6.5);
    doc.text(sb.label, sx + sbW / 2, y + 19, { align: "center" });
  });
  y += 28;

  // Summary
  checkY(18);
  doc.setFillColor(22, 32, 52);
  doc.roundedRect(margin, y, colW, 14, 3, 3, "F");
  doc.setTextColor(170, 195, 230);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(7.5);
  const sumLines = doc.splitTextToSize(opts.summary, colW - 8);
  doc.text(sumLines.slice(0, 2), margin + 4, y + 6);
  y += 20;

  // Skills columns
  const halfW = (colW - 5) / 2;
  const mxH = 8 + opts.matchedSkills.slice(0,8).length * 6 + 4;
  const msH = 8 + opts.missingSkills.slice(0,8).length * 6 + 4;
  const skH = Math.max(mxH, msH, 24);

  doc.setFillColor(0, 30, 22);
  doc.roundedRect(margin, y, halfW, skH, 3, 3, "F");
  doc.setTextColor(0, 200, 140);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(7.5);
  doc.text(`✓ MATCHED SKILLS (${opts.matchedSkills.length})`, margin + 4, y + 6);
  doc.setTextColor(130, 200, 175);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(7);
  opts.matchedSkills.slice(0, 8).forEach((s, i) => doc.text("• " + s, margin + 4, y + 12 + i * 6));

  doc.setFillColor(30, 15, 15);
  doc.roundedRect(margin + halfW + 5, y, halfW, skH, 3, 3, "F");
  doc.setTextColor(239, 68, 68);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(7.5);
  doc.text(`✗ MISSING SKILLS (${opts.missingSkills.length})`, margin + halfW + 9, y + 6);
  doc.setTextColor(210, 150, 150);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(7);
  opts.missingSkills.slice(0, 8).forEach((s, i) => doc.text("• " + s, margin + halfW + 9, y + 12 + i * 6));
  y += skH + 10;

  // Section scores
  checkY(16);
  y = sectionHeader(doc, margin, W, y, "SECTION SCORES");
  const secs = [
    { label: "Skills",     data: opts.sections.skills },
    { label: "Projects",   data: opts.sections.projects },
    { label: "Experience", data: opts.sections.experience },
    { label: "Education",  data: opts.sections.education },
  ].filter(s => s.data);
  const secW = (colW - 9) / 4;
  secs.forEach((sec, i) => {
    if (!sec.data) return;
    const sx = margin + i * (secW + 3);
    const [r, g, b] = scoreColor(sec.data.score);
    doc.setFillColor(22, 32, 52);
    doc.roundedRect(sx, y, secW, 20, 3, 3, "F");
    doc.setTextColor(r, g, b);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(13);
    doc.text(`${sec.data.score}`, sx + secW / 2, y + 11, { align: "center" });
    doc.setTextColor(100, 130, 165);
    doc.setFont("helvetica", "normal");
    doc.setFontSize(6);
    doc.text(sec.label, sx + secW / 2, y + 18, { align: "center" });
  });
  y += 26;

  // Priority Action Plan
  checkY(16);
  y = sectionHeader(doc, margin, W, y, "PRIORITY ACTION PLAN");
  opts.priorityActionPlan.forEach(a => {
    const priMap: Record<string, [number,number,number]> = { high: [239,68,68], medium: [245,158,11], low: [59,142,255] };
    const pCol = priMap[a.priority] || [100,130,165];
    const aLines = doc.splitTextToSize(a.action, colW - 28);
    const bH = aLines.length * 5 + 10;
    checkY(bH + 3);
    doc.setFillColor(22, 32, 52);
    doc.roundedRect(margin, y, colW, bH, 3, 3, "F");
    doc.setFillColor(...pCol);
    doc.roundedRect(margin + 3, y + 3, 18, 5, 2, 2, "F");
    doc.setTextColor(255, 255, 255);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(5.5);
    doc.text(a.priority.toUpperCase(), margin + 12, y + 7, { align: "center" });
    doc.setTextColor(200, 215, 240);
    doc.setFont("helvetica", "normal");
    doc.setFontSize(7.5);
    doc.text(aLines, margin + 25, y + 7);
    y += bH + 3;
  });

  // Risk Analysis
  if (opts.riskAnalysis.length) {
    y += 4; checkY(16);
    y = sectionHeader(doc, margin, W, y, "RISK ANALYSIS");
    opts.riskAnalysis.slice(0, 6).forEach(r => {
      const [rr, rg, rb] = r.level === "high" ? [239,68,68] : r.level === "medium" ? [245,158,11] : [59,142,255];
      const rLines = doc.splitTextToSize(r.risk, colW - 22);
      const bH = rLines.length * 5 + 8;
      checkY(bH + 3);
      doc.setFillColor(22, 32, 52);
      doc.roundedRect(margin, y, colW, bH, 3, 3, "F");
      doc.setFillColor(rr, rg, rb);
      doc.circle(margin + 6, y + bH / 2, 2, "F");
      doc.setTextColor(200, 215, 240);
      doc.setFont("helvetica", "normal");
      doc.setFontSize(7.5);
      doc.text(rLines, margin + 12, y + 6);
      y += bH + 3;
    });
  }

  // Keyword placement guide
  if (opts.keywordOptimization.length) {
    y += 4; checkY(16);
    y = sectionHeader(doc, margin, W, y, "KEYWORD PLACEMENT GUIDE");
    opts.keywordOptimization.slice(0, 8).forEach(k => {
      const phLines = doc.splitTextToSize(`"${k.howToWrite}"`, colW - 40);
      const bH = phLines.length * 5 + 12;
      checkY(bH + 3);
      doc.setFillColor(22, 32, 52);
      doc.roundedRect(margin, y, colW, bH, 3, 3, "F");
      doc.setTextColor(59, 142, 255);
      doc.setFont("helvetica", "bold");
      doc.setFontSize(7.5);
      doc.text(k.skill, margin + 4, y + 6);
      doc.setTextColor(100, 130, 165);
      doc.setFont("helvetica", "normal");
      doc.setFontSize(6.5);
      doc.text(`→ Add to: ${k.placement}`, margin + 4, y + 11);
      doc.setTextColor(130, 200, 170);
      doc.setFontSize(7);
      doc.text(phLines, margin + 4, y + 16);
      y += bH + 3;
    });
  }

  const total = doc.internal.getNumberOfPages();
  for (let pg = 1; pg <= total; pg++) {
    doc.setPage(pg);
    drawPageFooter(doc, W, H, pg, total);
  }

  doc.save(`PrepWise-Resume-Report-${new Date().toLocaleDateString("en-IN").replace(/\//g, "-")}.pdf`);
}


// ─── CAREER REPORT PDF ──────────────────────────────────────────────────────
export { loadJsPDF };

export async function loadJsPDFAndGenerate(report: {
  overallScore: number; atsScore: number; interviewAvg: number; readiness: number;
  strengths: string[]; weaknesses: string[];
  actionPlan: { priority: string; action: string; timeframe: string }[];
  careerRoles: { role: string; match: number; reason: string; salaryRange: string }[];
  certifications: { name: string; provider: string; priority: string; relevance: string }[];
  weeklyPlan: { day: string; tasks: string[] }[];
  nextSteps: string[];
}, candidateName: string, _stats: { total: number; avgScore: number; readiness: number }) {
  const { jsPDF } = await loadJsPDF();
  const doc = new jsPDF({ orientation: "portrait", unit: "mm", format: "a4" });
  const W = doc.internal.pageSize.getWidth();
  const H = doc.internal.pageSize.getHeight();
  const margin = 18;
  const colW = W - margin * 2;
  let y = 0;

  const newPage = () => { doc.addPage(); y = 46; };
  const checkY = (n = 10) => { if (y + n > H - 14) newPage(); };
  const dateStr = new Date().toLocaleDateString("en-IN", { day: "2-digit", month: "long", year: "numeric" });

  drawPageHeader(doc, W, "Career Intelligence Report", candidateName + "  -  Overall: " + report.overallScore + "/100", dateStr);
  y = 46;

  // Score boxes
  const boxes = [
    { label: "Overall Score",  val: report.overallScore },
    { label: "ATS Score",      val: report.atsScore },
    { label: "Interview Avg",  val: report.interviewAvg },
    { label: "Readiness",      val: report.readiness },
  ];
  const sbW = (colW - 9) / 4;
  boxes.forEach((sb, i) => {
    const sx = margin + i * (sbW + 3);
    doc.setFillColor(25, 35, 55);
    doc.roundedRect(sx, y, sbW, 24, 3, 3, "F");
    const [r, g, b] = scoreColor(sb.val);
    doc.setTextColor(r, g, b); doc.setFont("helvetica", "bold"); doc.setFontSize(16);
    doc.text(String(sb.val), sx + sbW / 2, y + 13, { align: "center" });
    doc.setTextColor(100, 130, 165); doc.setFont("helvetica", "normal"); doc.setFontSize(6.5);
    doc.text(sb.label, sx + sbW / 2, y + 21, { align: "center" });
  });
  y += 32;

  // Strengths & Weaknesses side by side
  const halfW = (colW - 6) / 2;
  const strItems = report.strengths.slice(0, 4);
  const wkItems  = report.weaknesses.slice(0, 4);
  const strH = 8 + strItems.length * 7 + 4;
  const wkH  = 8 + wkItems.length * 7 + 4;
  const swH  = Math.max(strH, wkH);

  doc.setFillColor(0, 25, 18);
  doc.roundedRect(margin, y, halfW, swH, 3, 3, "F");
  doc.setTextColor(0, 200, 140); doc.setFont("helvetica", "bold"); doc.setFontSize(8);
  doc.text("STRENGTHS", margin + 4, y + 6);
  doc.setTextColor(140, 210, 185); doc.setFont("helvetica", "normal"); doc.setFontSize(7.5);
  strItems.forEach((s, i) => {
    const lines = doc.splitTextToSize("- " + s, halfW - 8);
    doc.text(lines, margin + 4, y + 13 + i * 7);
  });

  doc.setFillColor(28, 20, 0);
  doc.roundedRect(margin + halfW + 6, y, halfW, swH, 3, 3, "F");
  doc.setTextColor(245, 158, 11); doc.setFont("helvetica", "bold"); doc.setFontSize(8);
  doc.text("AREAS TO IMPROVE", margin + halfW + 10, y + 6);
  doc.setTextColor(210, 185, 120); doc.setFont("helvetica", "normal"); doc.setFontSize(7.5);
  wkItems.forEach((s, i) => {
    const lines = doc.splitTextToSize("- " + s, halfW - 8);
    doc.text(lines, margin + halfW + 10, y + 13 + i * 7);
  });
  y += swH + 10;

  // Career roles
  y = sectionHeader(doc, margin, W, y, "CAREER ROLE MATCHES");
  report.careerRoles.forEach(role => {
    checkY(20);
    doc.setFillColor(22, 32, 52);
    doc.roundedRect(margin, y, colW, 16, 3, 3, "F");
    const [cr, cg, cb] = scoreColor(role.match);
    doc.setTextColor(cr, cg, cb); doc.setFont("helvetica", "bold"); doc.setFontSize(9);
    doc.text(role.match + "%", W - margin - 4, y + 9, { align: "right" });
    doc.setTextColor(200, 215, 240); doc.text(role.role, margin + 4, y + 7);
    doc.setFont("helvetica", "normal"); doc.setFontSize(7); doc.setTextColor(100, 130, 165);
    doc.text(role.salaryRange + "  -  " + role.reason.slice(0, 65), margin + 4, y + 13);
    y += 19;
  });

  // Action plan
  y += 4; checkY(16);
  y = sectionHeader(doc, margin, W, y, "PRIORITY ACTION PLAN");
  report.actionPlan.forEach(a => {
    const priColMap: Record<string, [number,number,number]> = { high:[239,68,68], medium:[245,158,11], low:[59,142,255] };
    const pCol = priColMap[a.priority] || [100,130,165] as [number,number,number];
    const aLines = doc.splitTextToSize(a.action, colW - 30);
    const bH = aLines.length * 5 + 10;
    checkY(bH + 4);
    doc.setFillColor(22, 32, 52);
    doc.roundedRect(margin, y, colW, bH, 3, 3, "F");
    doc.setFillColor(pCol[0], pCol[1], pCol[2]);
    doc.roundedRect(margin + 3, y + 3, 18, 5, 2, 2, "F");
    doc.setTextColor(255, 255, 255); doc.setFont("helvetica", "bold"); doc.setFontSize(5.5);
    doc.text(a.priority.toUpperCase(), margin + 12, y + 7, { align: "center" });
    doc.setTextColor(200, 215, 240); doc.setFont("helvetica", "normal"); doc.setFontSize(8);
    doc.text(aLines, margin + 25, y + 7);
    doc.setTextColor(100, 130, 165); doc.setFontSize(6.5);
    doc.text(a.timeframe, W - margin - 4, y + 7, { align: "right" });
    y += bH + 3;
  });

  // Certifications
  if (report.certifications.length) {
    y += 4; checkY(16);
    y = sectionHeader(doc, margin, W, y, "RECOMMENDED CERTIFICATIONS");
    report.certifications.forEach(c => {
      checkY(12);
      doc.setFillColor(20, 30, 50);
      doc.roundedRect(margin, y, colW, 10, 2, 2, "F");
      const pcColMap: Record<string, [number,number,number]> = { high:[239,68,68], medium:[245,158,11] };
      const pc = pcColMap[c.priority] || [100,130,165] as [number,number,number];
      doc.setFillColor(pc[0], pc[1], pc[2]);
      doc.circle(margin + 5, y + 5, 2, "F");
      doc.setTextColor(200, 215, 240); doc.setFont("helvetica", "bold"); doc.setFontSize(8);
      doc.text(c.name, margin + 10, y + 6);
      doc.setFont("helvetica", "normal"); doc.setTextColor(100, 130, 165); doc.setFontSize(7);
      doc.text("by " + c.provider + "  -  " + c.relevance.slice(0, 60), margin + 10, y + 10);
      y += 13;
    });
  }

  // Next steps
  y += 4; checkY(16);
  y = sectionHeader(doc, margin, W, y, "NEXT STEPS");
  report.nextSteps.forEach((s, i) => {
    checkY(8);
    const lines = doc.splitTextToSize((i + 1) + ".  " + s, colW - 4);
    doc.setTextColor(170, 190, 220); doc.setFont("helvetica", "normal"); doc.setFontSize(8);
    doc.text(lines, margin, y);
    y += lines.length * 5 + 3;
  });

  const total = doc.internal.getNumberOfPages();
  for (let pg = 1; pg <= total; pg++) {
    doc.setPage(pg);
    drawPageFooter(doc, W, H, pg, total);
  }

  doc.save("PrepWise-Career-Report-" + new Date().toLocaleDateString("en-IN").replace(/\//g, "-") + ".pdf");
}
